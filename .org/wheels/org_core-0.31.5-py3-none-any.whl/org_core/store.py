"""The org store — a local index over what the sources already hold (SPEC §9, §13; Appendix A rows 54, 62).

**Derived, never authoritative.** The sources of truth stay where they are: git (`.org/runs/<role>.jsonl` and
the committed `.org/tempo/facts-*.json`), GitHub (pull requests), and the board (the present). This module is
a SQLite projection of what those emitted, so that:

  - a board record survives the wake that overwrites it — the board keeps one record per key (row 62), and
    that is the one loss no live read can repair;
  - a reading is a query instead of the 1 + 3N `gh api` calls a live gather costs;
  - the *same* pure functions run over it: `facts_since` returns the shape `tempo.report` and `status.status`
    already take, so nothing downstream learns that a store exists.

Because it is derived it is **not committed and never merged**: delete it and `rebuild` reconstructs it from
the committed facts files. That keeps SPEC §16 decision 2 intact — git is still the store, there is no second
source to drift from, and check 7's drift question is answerable by rebuilding into a second file and diffing.

SQLite, one file, no daemon and no credential: a store that needs one dies exactly when the doctor does (row 54).
The DDL lives here rather than in a `.sql` file because, unlike `tickets/schema.sql`, no org ever ships it.
"""

from __future__ import annotations

import datetime as dt
import json
import sqlite3
from pathlib import Path
from typing import Any

from . import tempo as tp

DB_NAME = "status.db"

SCHEMA = """
create table if not exists ingest (
  id integer primary key autoincrement,
  at text not null, org text, gathered_at text, since text,
  board_rows integer not null default 0, pr_rows integer not null default 0,
  new_snapshots integer not null default 0, new_verdicts integer not null default 0
);

-- a board record as it stood at one ingest. The board keeps ONE row per key and overwrites it every wake
-- (row 62); this table is the history that makes a board-ended edge measurable at all.
create table if not exists record_snapshot (
  key text not null, record_at text not null, observed_at text not null, value text not null,
  primary key (key, record_at)
);
create index if not exists record_snapshot_at_idx on record_snapshot (record_at);

create table if not exists pr (
  repo text not null, number integer not null, title text, state text, draft integer,
  kind text, author_role text, head_ref text, head_sha text,
  opened_at text, updated_at text, merged_at text, closed_at text, observed_at text not null,
  primary key (repo, number)
);
create index if not exists pr_updated_idx on pr (updated_at);

-- append-only: a verdict is a comment and comments are never edited away, so the same (at, verdict) is one row
create table if not exists pr_verdict (
  repo text not null, number integer not null, at text not null, verdict text not null, sha text, via text,
  primary key (repo, number, at, verdict)
);
"""


def db_path(repo: Path, override: str | None = None) -> Path:
    return Path(override) if override else Path(repo) / ".org" / DB_NAME


def ensure_ignored(path: Path) -> bool:
    """Keep the store out of the org's commits. A tool that writes into a repository owns its own dirt: the
    install path has no gitignore mechanism, and a binary SQLite file riding along in a role's PR is exactly
    the accident row 42 is about. Written only inside `.org/`, which org-core owns; a `--db` pointed anywhere
    else is the caller's to manage."""
    d = Path(path).parent
    if d.name != ".org":
        return False
    ign = d / ".gitignore"
    lines = ign.read_text().splitlines() if ign.exists() else []
    if Path(path).name in lines:
        return False
    ign.write_text("\n".join([*lines, Path(path).name]) + "\n")
    return True


def connect(path: Path) -> sqlite3.Connection:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    ensure_ignored(Path(path))
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def counts(conn: sqlite3.Connection) -> dict[str, int]:
    out = {}
    for t in ("ingest", "record_snapshot", "pr", "pr_verdict"):
        out[t] = conn.execute(f"select count(*) as n from {t}").fetchone()["n"]
    return out


def _snapshot_at(row: dict[str, Any]) -> str | None:
    """A record's own `at` is its identity; the board's `updated_at` is the fallback. Without either the row
    cannot be keyed, so it is not stored — and `ingest` counts it as skipped rather than dropping it silently."""
    v = tp._value(row) if row else {}
    return (v.get("at") if isinstance(v, dict) else None) or row.get("updated_at")


def ingest(conn: sqlite3.Connection, facts: dict[str, Any], *, observed_at: str | None = None) -> dict[str, int]:
    """Fold one facts file (live or committed) into the store. Idempotent on natural keys: re-ingesting the
    same facts adds nothing, and a later wake's record adds a row because its `at` differs."""
    obs = observed_at or facts.get("gathered_at") or dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    board, prs = facts.get("board") or [], facts.get("prs") or []
    new_snap = new_verd = skipped = 0
    for row in board:
        at = _snapshot_at(row)
        if not at:
            skipped += 1
            continue
        cur = conn.execute("insert or ignore into record_snapshot (key, record_at, observed_at, value) values (?,?,?,?)",
                           (row["key"], str(at), obs, json.dumps(row.get("value"), ensure_ascii=False, sort_keys=True)))
        new_snap += cur.rowcount if cur.rowcount > 0 else 0
    for p in prs:
        repo = p.get("repo") or ""
        conn.execute(
            """insert into pr (repo, number, title, state, draft, kind, author_role, head_ref, head_sha,
                               opened_at, updated_at, merged_at, closed_at, observed_at)
               values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
               on conflict(repo, number) do update set
                 title=excluded.title, state=excluded.state, draft=excluded.draft, kind=excluded.kind,
                 author_role=excluded.author_role, head_ref=excluded.head_ref, head_sha=excluded.head_sha,
                 opened_at=excluded.opened_at, updated_at=excluded.updated_at, merged_at=excluded.merged_at,
                 closed_at=excluded.closed_at, observed_at=excluded.observed_at
               where excluded.updated_at >= pr.updated_at""",
            (repo, p["number"], p.get("title"), p.get("state"), int(bool(p.get("draft"))), p.get("kind"),
             p.get("author_role"), p.get("head_ref"), p.get("head_sha"), p.get("opened_at"), p.get("updated_at"),
             p.get("merged_at"), p.get("closed_at"), obs))
        for v in p.get("verdicts") or []:
            if not v.get("at") or not v.get("verdict"):
                continue
            cur = conn.execute("insert or ignore into pr_verdict (repo, number, at, verdict, sha, via) values (?,?,?,?,?,?)",
                               (repo, p["number"], v["at"], v["verdict"], v.get("sha"), v.get("via")))
            new_verd += cur.rowcount if cur.rowcount > 0 else 0
    conn.execute("""insert into ingest (at, org, gathered_at, since, board_rows, pr_rows, new_snapshots, new_verdicts)
                    values (?,?,?,?,?,?,?,?)""",
                 (obs, facts.get("org"), facts.get("gathered_at"), facts.get("since"), len(board), len(prs), new_snap, new_verd))
    conn.commit()
    return {"board_rows": len(board), "pr_rows": len(prs), "new_snapshots": new_snap,
            "new_verdicts": new_verd, "unkeyable_board_rows": skipped}


def facts_since(conn: sqlite3.Connection, manifest: dict[str, Any], *, since: str, now: dt.datetime,
                repo: Path | None = None) -> dict[str, Any]:
    """Replay the store into the shape `tempo.gather` produces, so `report` and `status` run unchanged.

    The board tier widens here and only here: every snapshot since `since` is replayed as its own row, so an
    item whose stages fell in different wakes has both ends again. The roster is NOT stored (it is a live
    read with no durable meaning), so a replayed reading leaves the listeners tile dark and says so."""
    rows = conn.execute("select key, record_at, value from record_snapshot where record_at >= ? order by record_at, key",
                        (since,)).fetchall()
    board = [{"key": r["key"], "updated_at": r["record_at"], "expires_at": None, "value": json.loads(r["value"])} for r in rows]
    verdicts: dict[tuple[str, int], list[dict[str, Any]]] = {}
    for v in conn.execute("select repo, number, at, verdict, sha, via from pr_verdict order by number, at, verdict").fetchall():
        verdicts.setdefault((v["repo"], v["number"]), []).append({"at": v["at"], "verdict": v["verdict"], "sha": v["sha"], "via": v["via"]})
    prs = []
    for p in conn.execute("select * from pr where updated_at >= ? order by number", (since,)).fetchall():
        vs = verdicts.get((p["repo"], p["number"]), [])
        prs.append({"repo": p["repo"], "number": p["number"], "title": p["title"], "state": p["state"],
                    "draft": bool(p["draft"]), "kind": p["kind"], "author_role": p["author_role"],
                    "head_ref": p["head_ref"], "head_sha": p["head_sha"], "opened_at": p["opened_at"],
                    "updated_at": p["updated_at"], "merged_at": p["merged_at"], "closed_at": p["closed_at"],
                    "first_verdict_at": vs[0]["at"] if vs else None, "first_verdict": vs[0]["verdict"] if vs else None,
                    "verdicts": vs, "files": [], "comments": []})
    # The whole table, not the window: this is the answer to "never ran" vs "ran and stopped", which the board
    # alone cannot give and which row 65 is entirely about. A key the store has never held has never reported.
    first_seen = {r["key"]: {"first_record_at": r["first_record_at"], "last_record_at": r["last_record_at"],
                             "first_observed_at": r["first_observed_at"], "records": r["records"]}
                  for r in conn.execute("select key, min(record_at) as first_record_at, max(record_at) as last_record_at, "
                                        "min(observed_at) as first_observed_at, count(*) as records "
                                        "from record_snapshot group by key").fetchall()}
    return {
        "kind": "tempo-facts", "org": manifest["org"]["id"], "gathered_at": now.isoformat(timespec="seconds"),
        "since": since, "from_store": True, "first_seen": first_seen,
        "roles": {r: {"name": e.get("name"), "cadence": e.get("cadence") or tp._default(r, "cadence"),
                      "runtime": e.get("runtime") or tp._default(r, "runtime"),
                      "report_key": e.get("report_key") or f"roles/{r}/last-run", "tempo": tp.role_tempo(manifest).get(r),
                      "tolerance": e.get("tolerance", 1.5), "period_hours": e.get("period_hours")}
                  for r, e in manifest["roles"].items() if e.get("enabled", True)},
        "targets": tp.targets(manifest, now),
        "board": board, "prs": prs, "agents": None, "runs": tp.gather_runs(Path(repo)) if repo else [],
        "triggers": [], "sessions": [],
        "could_not_read": ["agents: the roster is a live read and is not stored — listeners cannot be judged from the store"],
    }


def rebuild(conn: sqlite3.Connection, repo: Path) -> dict[str, int]:
    """Reconstruct from the committed facts files, oldest first. This is what makes the store safe to delete —
    and what makes check 7's drift question answerable: rebuild into a second file and compare the counts."""
    files = sorted((Path(repo) / tp.FACTS_DIR).glob("facts-*.json"))
    total = {"files": 0, "new_snapshots": 0, "new_verdicts": 0, "unkeyable_board_rows": 0}
    for f in files:
        try:
            facts = json.loads(f.read_text())
        except json.JSONDecodeError:
            continue
        got = ingest(conn, facts)
        total["files"] += 1
        for k in ("new_snapshots", "new_verdicts", "unkeyable_board_rows"):
            total[k] += got[k]
    return total
