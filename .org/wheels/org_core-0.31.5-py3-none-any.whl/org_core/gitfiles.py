"""Whether git can carry a managed file (SPEC §7, row 93).

`org apply` writes a file and `org verify` checked that it exists; neither asked whether git would carry it. Lucille's
`.gitignore` ignores `.claude/*` and whitelists three paths, so `.claude/hooks/org-setup.sh` was written twice (#1606
merged 06:49Z, #1614 at 08:03Z on 2026-09-20), committed by nobody, and every fresh session ran
`bash …/org-setup.sh || true` over a file that was not there. The tool's own PASS covered it both times.

git is the oracle here: `check-ignore -v` names the pattern, its file and its line, and the ancestor walk in
`unignore` finds the entry git actually excluded (`.claude/*` excludes the directory `.claude/hooks`, and a file under
an excluded directory cannot be re-included — the directory must be), so the negation written is the one git honours.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Ignore:
    source: str     # the file holding the pattern: repo-relative for a .gitignore, else as git prints it
    line: int
    pattern: str

    def __str__(self) -> str:
        return f"{self.source}:{self.line} `{self.pattern}`"


def _git(repo: Path, *args: str) -> subprocess.CompletedProcess | None:
    try:
        return subprocess.run(["git", *args], cwd=repo, capture_output=True, text=True, timeout=30)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def is_git_repo(repo: Path) -> bool:
    """True when `repo` is inside a work tree AND is its top level — a parent's repo must not adopt an org's files."""
    p = _git(repo, "rev-parse", "--show-toplevel")
    if p is None or p.returncode != 0:
        return False
    try:
        return Path(p.stdout.strip()).resolve() == repo.resolve()
    except OSError:
        return False


def tracked(repo: Path, rel: str) -> bool:
    p = _git(repo, "ls-files", "--error-unmatch", "--", rel)
    return p is not None and p.returncode == 0


def ignored(repo: Path, rel: str) -> Ignore | None:
    """The pattern git would ignore `rel` by (an untracked or not-yet-written path), or None. A tracked path is never
    reported: git does not ignore what it already carries."""
    p = _git(repo, "check-ignore", "-v", "--", rel)
    if p is None or p.returncode != 0 or not p.stdout.strip():
        return None
    head = p.stdout.strip().splitlines()[0].split("\t", 1)[0]
    try:
        source, line, pattern = head.split(":", 2)
    except ValueError:
        return Ignore(head, 0, "?")
    if pattern.startswith("!"):
        return None   # measured on git 2.43: `-v` also prints the negation that un-ignored a path, exit 0 — that is "carried", not "ignored"
    return Ignore(source, int(line), pattern)


def _excluded_entry(repo: Path, rel: str) -> str:
    """The shallowest ancestor of `rel` (or `rel` itself) that git excludes — the thing the negation must name."""
    parts = Path(rel).parts
    for i in range(1, len(parts) + 1):
        cand = "/".join(parts[:i])
        if ignored(repo, cand) is not None:
            return cand + ("/" if i < len(parts) else "")
    return rel


def unignore(repo: Path, rel: str, max_rounds: int = 6) -> list[str]:
    """Append the negations that make git carry `rel`; returns them as `<file>: <line>`. Empty when nothing was needed.
    A pattern from a nested .gitignore is negated in that file (a root negation cannot override a deeper file); one from
    `.git/info/exclude` or a global excludes file is negated in the root `.gitignore`, which outranks both."""
    written: list[str] = []
    for _ in range(max_rounds):
        ig = ignored(repo, rel)
        if ig is None:
            break
        entry = _excluded_entry(repo, rel)
        src = Path(ig.source)
        in_repo = not src.is_absolute() and src.name == ".gitignore" and (repo / src).exists()
        target = (repo / src) if in_repo else (repo / ".gitignore")
        base = src.parent.as_posix() if in_repo else "."
        rel_entry = entry if base in (".", "") else entry[len(base) + 1:] if entry.startswith(base + "/") else entry
        line = "!" + rel_entry
        existing = target.read_text() if target.exists() else ""
        if line in existing.splitlines():
            break   # already there and still ignored: another pattern wins; report it rather than loop
        with target.open("a") as fh:
            if existing and not existing.endswith("\n"):
                fh.write("\n")
            fh.write(f"# org-core: managed file, must reach a fresh container (row 93)\n{line}\n")
        written.append(f"{target.relative_to(repo).as_posix()}: {line}")
    return written
