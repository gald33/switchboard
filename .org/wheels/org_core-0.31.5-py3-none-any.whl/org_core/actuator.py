"""The actuator — the variable half of tempo, executed (SPEC §13.1).

`plan` is a pure function of the facts and the manifest: the events past target, the acts a session holding
the sessions port should perform now — spawn a one-shot, fire a sourced fresh routine, forward a blocked
field, ask a human, hold — with every one-shot prompt fully rendered, and when to wake next. `record_wake`
turns the plan and the port's answers into the ledger row, the heartbeat and the lease. The CLI writes those
to the board; this module writes nothing, so a plan can be tested from a facts file.

Measured 2026-09-19 (fidelity/tempo-design-2026-09-19): the actuator's working channels are `create_session`
(24 spawns read, fire→spawn 76–95 s), `send_later` to itself (delivery within a minute), and `fire_trigger`
on a *sourced fresh* routine. `fire_trigger` on a session-bound routine mints a sourceless fresh session and
never reaches the bound session, so no plan ever fires one. A persistent session's wake grows with its
context ($2.34 → $16.67 → $42.09 a fire), so the plan refuses to arm past `rotate_at_tokens`.
"""

from __future__ import annotations

import datetime as dt
import json
import re
import uuid
from pathlib import Path
from typing import Any

from . import tempo as tp

ACTS = ("arm", "dm", "spawn", "fire_trigger", "forward", "ask", "hold")

#: org-level tempo defaults; `tempo.*` in the manifest overrides key by key
DEFAULTS: dict[str, Any] = {
    "actuator": "dispatcher",
    "wake_interval_minutes": {"busy": 20, "quiet": None},
    "after_spawn_minutes": {"builder": 30, "reviewer": 20, "ceo": 15, "registrar": 25, "account-manager": 25},
    "hold_if_cron_due_within_minutes": 15,
    "rotate_at_tokens": 250_000,
    "suppress_after_wake_lost": 2,
    "spawned_merge_proven": False,
    "listen_minutes": tp.DEFAULT_LISTEN_MINUTES,
    "ledger_key": "coord/tempo/wakes",
    "heartbeat_key": "coord/tempo/actuator",
    "lease_key": "coord/tempo/lease",
    "triggers_key": "coord/tempo/triggers",
    "operator_queue_key": "coord/tempo/operator-queue",
}
ONESHOT_PREFIXES = ("tempo:", "Re-check", "Check-in", "Peek", "reviewer —", "builder —", "ceo —", "registrar —", "account-manager —")

DEFAULT_ONESHOT = """{[ woken_by ]}

You are {[ role.name ]}, the {[ role_id ]} of the {[ org_id ]} org, woken for one thing: {[ what ]}{[ scope_line ]}
Read `.claude/agents/{[ role_id ]}.md`, invoke the `{[ role_id ]}` skill for that one thing, write your run record with the `woken_by` line above echoed verbatim, and end. Do not poll, do not re-arm, do not widen the scope.

Repository: {[ repo_url ]}, expected at `{[ checkout ]}`.
"""


def org_tempo(manifest: dict[str, Any]) -> dict[str, Any]:
    cfg = json.loads(json.dumps(DEFAULTS))
    for k, v in (manifest.get("tempo") or {}).items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict):
            cfg[k].update(v)
        elif k != "targets":
            cfg[k] = v
    return cfg


def _sid(x: Any) -> str:
    """Session ids arrive as `session_01…` from the sessions port and `cse_01…` from a trigger's last_run; compare the tail."""
    s = str(x or "")
    return s.split("_", 1)[-1] if "_" in s else s


def session_facts(session_json: Any) -> dict[str, Any]:
    """{id, context_tokens, cost_usd} from a get_session answer (wrapped in `ccr` or not) — or an already-flat dict."""
    s = session_json or {}
    if isinstance(s, dict) and "ccr" in s:
        s = s["ccr"]
    em = s.get("external_metadata") or {}
    return {
        "id": s.get("id") or s.get("session_id"),
        "context_tokens": s.get("context_tokens") or (em.get("context_usage") or {}).get("used_tokens"),
        "cost_usd": s.get("cost_usd") or (em.get("usage") or {}).get("cost_usd"),
    }


# --- the ledger on the board -------------------------------------------------------

def ledger_rows(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Every actuator wake row under coord/tempo/wakes-<date>, oldest first (a key holds {"rows": [...]})."""
    prefix = (cfg or DEFAULTS)["ledger_key"] + "-"
    rows: dict[str, dict[str, Any]] = {}
    for r in board:
        if not r["key"].startswith(prefix):
            continue
        v = r.get("value")
        for row in (v.get("rows") if isinstance(v, dict) else v) or []:
            if isinstance(row, dict) and row.get("run_id"):
                rows[row["run_id"]] = row
    return sorted(rows.values(), key=lambda x: x.get("at") or "")


def _key(board: list[dict[str, Any]], key: str) -> dict[str, Any] | None:
    return tp._latest_records(board).get(key)


def heartbeat(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> dict[str, Any] | None:
    row = _key(board, (cfg or DEFAULTS)["heartbeat_key"])
    return tp._value(row) if row else None


def lease(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> dict[str, Any] | None:
    row = _key(board, (cfg or DEFAULTS)["lease_key"])
    return tp._value(row) if row else None


def operator_queue(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    row = _key(board, (cfg or DEFAULTS)["operator_queue_key"])
    v = row.get("value") if row else None
    if isinstance(v, dict):
        v = v.get("items") or v.get("queue") or []
    return [x for x in (v or []) if isinstance(x, dict)]


def compact_triggers(triggers: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """The fields a plan reads, from a full list_triggers dump (56 KB for 14 triggers, measured) — what the actuator
    writes to `coord/tempo/triggers` once a day instead of dumping per wake."""
    out = []
    for t in triggers or []:
        lr = t.get("last_run") or {}
        cfg = (t.get("session_request") or {}).get("config") or {}
        out.append({"id": t.get("id"), "name": t.get("name"), "cron_expression": t.get("cron_expression"), "enabled": t.get("enabled"),
                    "persistent_session_id": t.get("persistent_session_id"), "next_run_at": t.get("next_run_at"),
                    "sources": cfg.get("sources") if cfg else t.get("sources"),
                    "last_run": {"fired_at": lr.get("fired_at") or t.get("last_fired_at"), "finished_at": lr.get("finished_at"), "status": lr.get("status"), "session_id": lr.get("session_id")},
                    "mcp_connections": [c.get("name") if isinstance(c, dict) else c for c in (t.get("mcp_connections") or [])]})
    return out


def receiver_echoes(board: list[dict[str, Any]], runs: list[dict[str, Any]]) -> dict[str, str]:
    """run_id -> the earliest `at` of a receiver record whose `woken_by` line names it."""
    out: dict[str, str] = {}
    for row in board:
        v = tp._value(row)
        wb = v.get("woken_by") if v else None
        if isinstance(wb, str) and wb.startswith("woken_by:"):
            parts = wb.split()
            if len(parts) > 1:
                at = v.get("at") or row.get("updated_at") or ""
                out[parts[1]] = tp._min_ts(out.get(parts[1]), at) or at
    for r in runs:
        wb = r.get("woken_by")
        if isinstance(wb, str) and wb.startswith("woken_by:"):
            parts = wb.split()
            if len(parts) > 1:
                at = r.get("started_at") or r.get("ended_at") or ""
                out[parts[1]] = tp._min_ts(out.get(parts[1]), at) or at
    return out


def orphans(facts: dict[str, Any], now: dt.datetime, cfg: dict[str, Any] | None = None) -> dict[str, Any]:
    """What the ledger shows went wrong: a fire nobody answered, a role that lost two wakes, a blocked field nobody
    forwarded, an event past target with no fired row since it happened."""
    cfg = cfg or org_tempo({})
    board, runs = facts.get("board", []), facts.get("runs", [])
    rows = ledger_rows(board, cfg)
    echoes = receiver_echoes(board, runs)
    fired_no_receiver: list[dict[str, Any]] = []
    losses: dict[str, int] = {}
    for row in rows:
        for f in row.get("fired") or []:
            if f.get("kind") not in ("spawn", "fire_trigger", "dm") or f.get("could_not"):
                continue
            rid = f.get("run_id") or row.get("run_id")
            wait = 3 * float(cfg["after_spawn_minutes"].get(f.get("role"), 30))
            age_min = (tp.hours(f.get("at") or row.get("at"), now.isoformat()) or 0) * 60
            if rid in echoes:
                continue
            if age_min > wait:
                fired_no_receiver.append({"role": f.get("role"), "run_id": rid, "what": f.get("what"), "at": f.get("at") or row.get("at"), "age_hours": round(age_min / 60, 2)})
                losses[f.get("role", "?")] = losses.get(f.get("role", "?"), 0) + 1
    suppressed = sorted(r for r, n in losses.items() if n >= int(cfg["suppress_after_wake_lost"]))
    queued = {(q.get("role"), q.get("at")) for q in operator_queue(board, cfg)}
    forwarded = {(f.get("role"), f.get("event_at")) for row in rows for f in (row.get("fired") or []) if f.get("kind") == "forward"}
    unforwarded = []
    for b in tp.blocked_now(board, facts.get("roles", {}), now):
        if b.get("blocked") and (b["role"], b.get("record_at")) not in queued and (b["role"], b.get("record_at")) not in forwarded:
            unforwarded.append({"role": b["role"], "at": b.get("record_at"), "age_hours": b.get("record_age_hours"), "text": tp._cut(b["blocked"], 160)})
    return {"fired_no_receiver": fired_no_receiver, "suppressed": suppressed, "unforwarded": unforwarded, "losses": losses}


# --- the plan ---------------------------------------------------------------------

SUBJECT_KEY_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,}$")


def subject_tags(what: str) -> list[str]:
    """`pr-<n>` for a PR, `item:<key>` for an item key: the census reads the subject from the tags, never from the
    title (NumeroTech 2026-09-21: 35 of 35 spawned sessions carried a role tag, 18 of 35 the documented title, and the
    title format has no slot for a PR)."""
    from .tempo import pr_numbers
    nums = pr_numbers(what)
    if nums:
        return [f"pr-{n}" for n in nums[:3]]
    key = (what or "").strip()
    return [f"item:{key}"] if SUBJECT_KEY_RE.match(key) and "#" not in key else []


def _trigger_for_role(role: str, facts: dict[str, Any]) -> dict[str, Any] | None:
    return tp._triggers_by_role(facts).get(role)


def _minutes_until(ts: str | None, now: dt.datetime) -> float | None:
    h = tp.hours(now.isoformat(), ts) if ts else None
    return None if h is None else h * 60


def render_oneshot(manifest: dict[str, Any], role: str, *, woken_by: str, what: str, scope: str = "",
                   packages: dict[str, Any] | None = None) -> str:
    """The receiver's whole prompt: the `woken_by:` line first, then one thing to do. Template `prompt.oneshot.md`
    in the role package when it has one, else DEFAULT_ONESHOT."""
    from .manifest import flat_vars
    from .render import render_base
    from .roles import discover
    pk = (packages or discover()).get(role)
    tpl = None
    if pk is not None:
        p = Path(pk.dir) / "prompt.oneshot.md"
        tpl = p.read_text() if p.exists() else None
    ctx = flat_vars(manifest)
    entry = manifest["roles"].get(role) or {"name": role}
    ctx.update({"role": entry, "role_id": role, "woken_by": woken_by, "what": what, "scope": scope,
                "scope_line": f" ({scope})." if scope else "."})
    return render_base(tpl or DEFAULT_ONESHOT, ctx)


def plan(facts: dict[str, Any], manifest: dict[str, Any], now: dt.datetime, *, session: Any = None, run_id: str | None = None,
         packages: dict[str, Any] | None = None, requests: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    """Events past target → acts, in the order the actuator performs them: `arm` first (a dead session still leaves a
    wake behind), then spawns oldest-first, fires, forwards, asks; holds are listed so the record says why nothing
    happened. `requests` are the routed DMs in this wake's inbox (row 75: a sender's DM to a spawned role lands here as
    `wake <role>: <event> <what>`): the event they name is acted on now, target or not, and one that matches nothing in the
    facts is held with the reason. Nothing here touches a port."""
    cfg = org_tempo(manifest)
    sess = session_facts(session)
    run_id = run_id or f"wake-{now:%Y%m%dT%H%M%S}-{uuid.uuid4().hex[:6]}"
    board = facts.get("board", [])
    rep = tp.report(facts, now)
    requests = [r for r in (requests or []) if r.get("role") and r.get("what")]
    if requests:
        rep["wake_now"] = tp.wake_now(facts, now, requested=requests)
    rows = ledger_rows(board, cfg)
    orph = orphans(facts, now, cfg)
    ws_url = manifest["org"]["repo"]
    source_url = f"https://github.com/{ws_url}"
    actions: list[dict[str, Any]] = []
    events: list[dict[str, Any]] = []
    in_flight: dict[str, int] = {}
    for row in rows:
        for f in row.get("fired") or []:
            if f.get("kind") == "spawn" and not f.get("could_not"):
                age_min = (tp.hours(f.get("at") or row.get("at"), now.isoformat()) or 0) * 60
                if age_min <= float(cfg["after_spawn_minutes"].get(f.get("role"), 30)) and (f.get("run_id") or row.get("run_id")) not in receiver_echoes(board, facts.get("runs", [])):
                    in_flight[f["role"]] = in_flight.get(f["role"], 0) + 1
    spawned_roles: list[str] = []
    fired_roles: set[str] = set()
    registry = tp.agents_registry(board)
    present = tp.roster_ids(facts.get("agents") or [])
    roster_read = facts.get("agents") is not None
    for w in rep["wake_now"]:
        role = w["role"]
        rcfg = dict(tp.DEFAULT_ROLE_TEMPO.get(role, {}))
        rcfg.update((manifest["roles"].get(role) or {}).get("tempo") or {})
        runtime = (facts.get("roles", {}).get(role) or {}).get("runtime") or (manifest["roles"].get(role) or {}).get("runtime")
        on_demand = tp.on_demand_act(rcfg, runtime)
        for e in w["events"]:
            events.append({"role": role, "event": e["event"], "what": e["what"], "waiting_hours": e["waiting_hours"], "event_at": e.get("event_at"),
                           **({"requested": True} if e.get("requested") else {})})
        if role == cfg["actuator"]:
            actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]),
                            "reason": "the actuator's own events — this wake is the actuator, and its dispatch is what answers them"})
            continue
        if not w["fire"]:
            actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "reason": w["why"]})
            continue
        if role in orph["suppressed"]:
            actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]),
                            "reason": f"suppressed: {orph['losses'].get(role)} wakes fired and no record came back — never pay a third time; the operator decides"})
            continue
        if on_demand == "none":
            continue
        if on_demand == "dm":
            e0 = w["events"][0]
            entry = registry.get(role) or {}
            aid = entry.get("agent_id")
            text = f"tempo {run_id}: " + "; ".join(f"{e['event']} {e['what']} waiting {e['waiting_hours']}h" for e in w["events"][:4])
            if not aid:
                actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "event": e0["event"], "event_at": e0.get("event_at"),
                                "reason": "a persistent role that never registered in coord/tempo/agents — no address to DM; its session has not run `org tempo register`"})
            elif roster_read and aid not in present:
                actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "event": e0["event"], "event_at": e0.get("event_at"),
                                "agent_id": aid, "reason": f"registered as {aid} but not on the roster — its listener lapsed (parked until {entry.get('listen_until')}); the DM would not be delivered; its cron is the floor"})
            else:
                actions.append({"act": "dm", "role": role, "agent_id": aid, "what": ", ".join(e["what"] for e in w["events"][:4]), "event": e0["event"], "event_at": e0.get("event_at"),
                                "run_id": run_id, "text": text, "reason": f"{len(w['events'])} event(s) past the {w['target_hours']}h target; the receiver is listening" + ("" if roster_read else " (roster unread — sent on the registry alone)")})
                fired_roles.add(role)
            continue
        if role == "ceo" and on_demand == "spawn" and not cfg.get("spawned_merge_proven"):
            actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:6]), "event": w["events"][0]["event"],
                            "reason": "a spawned CEO one-shot merging is unproven (tempo.spawned_merge_proven: false) — a human-started CEO session merges, or the operator says the grant covers a one-shot"})
            continue
        if on_demand == "spawn":
            cap = int(rcfg.get("max_concurrent", 1))
            room = max(0, cap - in_flight.get(role, 0))
            ordered = sorted(w["events"], key=lambda e: -(e["waiting_hours"] or 0)) if rcfg.get("order", "oldest_first") == "oldest_first" else sorted(w["events"], key=lambda e: (e["waiting_hours"] or 0))
            for e in ordered[:room]:
                expected = now + dt.timedelta(minutes=float(cfg["after_spawn_minutes"].get(role, 30)))
                woken_by = f"woken_by: {run_id} {e['event']} {e['what']} event_at={e.get('event_at') or '?'} fired_at={now.isoformat(timespec='seconds')} expected_by={expected.isoformat(timespec='seconds')}"
                scope = e.get("scope", "")
                actions.append({"act": "spawn", "role": role, "what": e["what"], "event": e["event"], "event_at": e.get("event_at"), "run_id": run_id,
                                "title": f"{role} — {e['what']}" + (f" ({scope})" if scope else ""), "source_url": source_url,
                                "tags": [f"org:{manifest['org']['id']}", f"role:{role}", f"woken-by:{run_id}", f"event:{e['event']}"] + subject_tags(e["what"]),
                                "prompt": render_oneshot(manifest, role, woken_by=woken_by, what=e["what"], scope=scope, packages=packages),
                                "reason": (f"requested by DM: {e['event']} {e['what']}" if e.get("requested") else f"{e['event']} {e['what']} waiting {e['waiting_hours']}h (target {w['target_hours']}h)")})
                spawned_roles.append(role)
            if len(ordered) > room:
                actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in ordered[room:][:4]),
                                "reason": f"max_concurrent {cap}: {in_flight.get(role, 0)} in flight, {min(room, len(ordered))} spawned this wake"})
            continue
        if on_demand == "fire_trigger":
            t = _trigger_for_role(role, facts)
            if not t:
                actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "reason": "no routine seen for this role in the triggers facts — nothing to fire"})
                continue
            if t.get("persistent_session_id"):
                actions.append({"act": "ask", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]),
                                "reason": f"routine {t.get('id')} is session-bound: a forced fire mints a sourceless fresh session and never reaches the bound session (measured 2026-09-17); never fire it"})
                continue
            due = _minutes_until(t.get("next_run_at"), now)
            if due is not None and 0 <= due <= float(cfg["hold_if_cron_due_within_minutes"]):
                actions.append({"act": "hold", "role": role, "what": ", ".join(e["what"] for e in w["events"][:4]), "reason": f"its own cron fires in {due:.0f} min — the wake is free"})
                continue
            text = "tempo: " + ", ".join(f"{e['event']} {e['what']} waiting {e['waiting_hours']}h" for e in w["events"][:4])
            actions.append({"act": "fire_trigger", "role": role, "trigger": t.get("id"), "what": ", ".join(e["what"] for e in w["events"][:4]),
                            "event": w["events"][0]["event"], "event_at": w["events"][0].get("event_at"), "run_id": run_id, "text": text,
                            "reason": f"{len(w['events'])} event(s) past the {w['target_hours']}h target; sourced fresh routine"})
            fired_roles.add(role)
    matched = {(e["role"], e["what"]) for e in events if e.get("requested")}
    for r in requests:
        if (r["role"], str(r["what"])) not in matched:
            actions.append({"act": "hold", "role": r["role"], "what": str(r["what"]), "event": r.get("event"),
                            "reason": f"requested by DM from {r.get('from') or '?'} ({r.get('event')} {r['what']}) but the facts show no such open event — already answered, not a role this plan wakes, or not yet visible to gh"})
    for u in orph["unforwarded"]:
        actions.append({"act": "forward", "role": u["role"], "what": u["text"], "event": "blocked_written", "event_at": u["at"], "run_id": run_id,
                        "reason": f"blocked field {u['age_hours']}h old and not in the operator queue"})
        events.append({"role": u["role"], "event": "blocked_written", "what": u["text"][:80], "waiting_hours": u["age_hours"], "event_at": u["at"]})
    ceo_cfg = dict(tp.DEFAULT_ROLE_TEMPO.get("ceo", {}))
    ceo_cfg.update((manifest["roles"].get("ceo") or {}).get("tempo") or {})
    ceo_rt = (facts.get("roles", {}).get("ceo") or {}).get("runtime") or (manifest["roles"].get("ceo") or {}).get("runtime")
    if orph["unforwarded"] and "blocked_written" in (ceo_cfg.get("wake_on") or []) and tp.on_demand_act(ceo_cfg, ceo_rt) == "dm" \
            and (manifest["roles"].get("ceo") or {}).get("enabled", True) and cfg["actuator"] != "ceo":
        # row 86: the CEO listens for blocked fields — the forward above puts them in the operator queue, the DM wakes the reader
        entry = registry.get("ceo") or {}
        aid = entry.get("agent_id")
        whats = ", ".join(u["role"] for u in orph["unforwarded"][:4])
        text = f"tempo {run_id}: " + "; ".join(f"blocked_written {u['role']} waiting {u['age_hours']}h" for u in orph["unforwarded"][:4])
        if not aid:
            actions.append({"act": "ask", "role": "ceo", "what": whats, "event": "blocked_written", "event_at": orph["unforwarded"][0]["at"],
                            "reason": "the CEO listens for blocked fields but never registered in coord/tempo/agents — no address to DM; the operator queue holds the forward"})
        elif roster_read and aid not in present:
            actions.append({"act": "ask", "role": "ceo", "what": whats, "event": "blocked_written", "event_at": orph["unforwarded"][0]["at"], "agent_id": aid,
                            "reason": f"registered as {aid} but not on the roster — its listener lapsed (parked until {entry.get('listen_until')}); the operator queue holds the forward; its cron is the floor"})
        else:
            actions.append({"act": "dm", "role": "ceo", "agent_id": aid, "what": whats, "event": "blocked_written", "event_at": orph["unforwarded"][0]["at"],
                            "run_id": run_id, "text": text, "reason": f"{len(orph['unforwarded'])} blocked field(s) forwarded; the CEO listens for them" + ("" if roster_read else " (roster unread — sent on the registry alone)")})
    for f in orph["fired_no_receiver"]:
        if f["role"] not in orph["suppressed"] and f["role"] not in spawned_roles:
            actions.append({"act": "ask", "role": f["role"], "what": f["what"], "event": "receiver_missing", "event_at": f["at"],
                            "reason": f"fired {f['run_id']} {f['age_hours']}h ago and no record echoed it — re-spawn is the next plan's call once; two losses suppress the role"})
    # when to wake next
    waits: list[float] = []
    for role in spawned_roles:
        waits.append(float(cfg["after_spawn_minutes"].get(role, 30)))
    for role in fired_roles:
        waits.append(float(cfg["after_spawn_minutes"].get(role, 25)))
    open_events = [e for e in events if e["event"] != "blocked_written"]
    if open_events and cfg["wake_interval_minutes"].get("busy"):
        waits.append(float(cfg["wake_interval_minutes"]["busy"]))
    next_wake = (now + dt.timedelta(minutes=min(waits))).replace(microsecond=0) if waits else None
    rotate = bool(sess.get("context_tokens") and int(sess["context_tokens"]) > int(cfg["rotate_at_tokens"]))
    lz = lease(board, cfg)
    lease_held = bool(lz and lz.get("session_id") and _sid(lz["session_id"]) != _sid(sess.get("id")) and (tp.parse_ts(lz.get("until")) or now) > now and sess.get("id"))
    arm = bool(next_wake) and not rotate and not lease_held
    if arm:
        actions.insert(0, {"act": "arm", "at": next_wake.isoformat(timespec="seconds"), "run_id": run_id,
                           "text": f"tempo wake (armed by {run_id} at {now.isoformat(timespec='seconds')}): run the four-call wake — plan, execute, record. Reason: " + "; ".join(f"{e['event']} {e['what']}" for e in open_events[:5]),
                           "reason": "the earliest of: after-spawn expectation, the busy interval"})
    real = [a for a in actions if a["act"] in ("spawn", "fire_trigger", "forward", "ask", "dm")]
    exit_code = 5 if lease_held else 4 if rotate else 3 if (real or arm) else 0
    return {
        "run_id": run_id, "at": now.isoformat(timespec="seconds"), "org": manifest["org"]["id"], "session_id": sess.get("id"),
        "context_tokens": sess.get("context_tokens"), "cost_usd": sess.get("cost_usd"),
        "events": events, "actions": actions, "next_wake_at": next_wake.isoformat(timespec="seconds") if next_wake else None,
        "arm": arm, "idle": not real and not arm, "rotate": rotate, "lease_held": lease_held,
        "orphans": {k: v for k, v in orph.items() if k != "losses"}, "slow": rep["slow"], "exit_code": exit_code,
        "could_not_read": facts.get("could_not_read", []),
    }


def render_plan(p: dict[str, Any]) -> str:
    L = [f"tempo wake plan {p['run_id']} — {p['org']} at {p['at']}" + (f", session {p['session_id']}" if p.get("session_id") else "")
         + (f", {p['context_tokens']} tokens" if p.get("context_tokens") else "")]
    if p["rotate"]:
        L.append(f"  ROTATE: context over the threshold — nothing is armed; spawns and fires below still run once, then the operator rebinds the floor routine to a fresh session")
    if p["lease_held"]:
        L.append("  LEASE: another live session holds coord/tempo/lease — do nothing this wake")
    for a in p["actions"]:
        if a["act"] == "arm":
            L.append(f"  ARM      send_later at {a['at']} — {a['reason']}")
        elif a["act"] == "spawn":
            L.append(f"  SPAWN    {a['role']:<16} {a['what']:<28} create_session(source_url, prompt, title={a['title']!r}) — {a['reason']}")
        elif a["act"] == "dm":
            L.append(f"  DM       {a['role']:<16} {a['what']:<28} switchboard dm {a['agent_id']} — {a['reason']}")
        elif a["act"] == "fire_trigger":
            L.append(f"  FIRE     {a['role']:<16} {a['what']:<28} fire_trigger({a['trigger']}, text) — {a['reason']}")
        elif a["act"] == "forward":
            L.append(f"  FORWARD  {a['role']:<16} blocked: {a['what'][:90]}")
        elif a["act"] == "ask":
            L.append(f"  ASK      {a['role']:<16} {a['what']:<28} — {a['reason']}")
        else:
            L.append(f"  HOLD     {a['role']:<16} {a['what']:<28} — {a['reason']}")
    if p["idle"]:
        L.append("  idle: nothing past target, nothing armed — the org waits on its cron floor")
    for k in ("fired_no_receiver", "suppressed", "unforwarded"):
        if p["orphans"].get(k):
            L.append(f"  orphans {k}: {json.dumps(p['orphans'][k], ensure_ascii=False)[:300]}")
    if p.get("could_not_read"):
        L.append("  could not read: " + "; ".join(p["could_not_read"]))
    L.append(f"  next wake {p['next_wake_at'] or 'none (cron floor)'}; exit {p['exit_code']}")
    return "\n".join(L) + "\n"


# --- the record -------------------------------------------------------------------

def record_wake(p: dict[str, Any], results: list[dict[str, Any]], now: dt.datetime, *, session: Any = None,
                previous: dict[str, Any] | None = None, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
    """The ledger row, the heartbeat and the lease from a plan and the port's answers. `results` is one entry per
    action index the session performed: {i, ok, id, readback, could_not}. A planned spawn/fire/arm with no result is
    a problem the row carries — a wake that says it fired and cannot show the id did not fire."""
    cfg = org_tempo(manifest or {})
    sess = session_facts(session) if session else {"id": p.get("session_id"), "context_tokens": p.get("context_tokens"), "cost_usd": p.get("cost_usd")}
    by_i = {int(r["i"]): r for r in results if "i" in r}
    fired: list[dict[str, Any]] = []
    problems: list[str] = []
    for i, a in enumerate(p["actions"]):
        r = by_i.get(i)
        entry = {"role": a.get("role"), "kind": a["act"], "what": a.get("what") or a.get("at"), "event": a.get("event"), "event_at": a.get("event_at"),
                 "run_id": a.get("run_id") or p["run_id"], "at": (r or {}).get("at") or now.isoformat(timespec="seconds")}
        if a["act"] in ("spawn", "fire_trigger", "arm", "dm"):
            if r is None:
                entry["could_not"] = "no result recorded for this action"
                problems.append(f"{a['act']} {a.get('role') or a.get('at')}: no result")
            elif r.get("could_not") or not r.get("ok", True):
                entry["could_not"] = r.get("could_not") or "refused"
                problems.append(f"{a['act']} {a.get('role') or a.get('at')}: {entry['could_not']}")
            else:
                entry[{"spawn": "session", "dm": "message"}.get(a["act"], "trigger")] = r.get("id") or a.get("trigger") or a.get("agent_id")
                entry["readback"] = r.get("readback")
        elif a["act"] == "ask":
            entry["readback"] = (r or {}).get("readback")
        fired.append(entry)
    cost_prev = (previous or {}).get("cost_usd")
    delta = round(float(sess["cost_usd"]) - float(cost_prev), 4) if sess.get("cost_usd") is not None and cost_prev is not None else None
    interval_min = _minutes_until(p.get("next_wake_at"), now) if p.get("next_wake_at") else None
    ttl = int(max(1800, 2 * 60 * (interval_min if interval_min and interval_min > 0 else 60)))
    row = {"run_id": p["run_id"], "at": p["at"], "recorded_at": now.isoformat(timespec="seconds"), "session_id": sess.get("id"),
           "context_tokens": sess.get("context_tokens"), "cost_usd": sess.get("cost_usd"), "cost_delta_usd": delta,
           "events": p["events"], "fired": fired, "next_wake_at": p.get("next_wake_at"), "idle": p["idle"], "rotate": p["rotate"], "problems": problems}
    hb = {"at": now.isoformat(timespec="seconds"), "run_id": p["run_id"], "next_wake_at": p.get("next_wake_at"), "session_id": sess.get("id"),
          "context_tokens": sess.get("context_tokens"), "cost_usd": sess.get("cost_usd"), "cost_delta_usd": delta,
          "wakes_today": int((previous or {}).get("wakes_today") or 0) + 1 if str((previous or {}).get("at", ""))[:10] == now.strftime("%Y-%m-%d") else 1,
          "rotate": p["rotate"], "ttl_seconds": ttl}
    lz = {"session_id": sess.get("id"), "until": (now + dt.timedelta(seconds=ttl)).isoformat(timespec="seconds"), "run_id": p["run_id"]}
    queue_add = [{"role": a.get("role"), "ask": a.get("what"), "event_at": a.get("event_at"), "from": p["run_id"], "forwarded_at": now.isoformat(timespec="seconds")}
                 for a in p["actions"] if a["act"] in ("forward", "ask")]
    return {"row": row, "heartbeat": hb, "lease": lz, "ledger_key": f"{cfg['ledger_key']}-{now:%Y-%m-%d}", "heartbeat_key": cfg["heartbeat_key"],
            "lease_key": cfg["lease_key"], "operator_queue_key": cfg["operator_queue_key"], "queue_add": queue_add, "ttl_seconds": ttl,
            "fired": fired, "problems": problems}


def wake_cost_series(board: list[dict[str, Any]], cfg: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """$ per wake from consecutive ledger rows' cost_usd (the session total read at each wake), not a total divided by a guess."""
    rows = ledger_rows(board, cfg)
    out = []
    prev = None
    for r in rows:
        c = r.get("cost_usd")
        if c is not None and prev is not None and r.get("session_id") == prev.get("session_id") and prev.get("cost_usd") is not None:
            out.append({"run_id": r["run_id"], "at": r.get("at"), "usd": round(float(c) - float(prev["cost_usd"]), 4), "context_tokens": r.get("context_tokens"), "idle": r.get("idle")})
        prev = r
    return out
