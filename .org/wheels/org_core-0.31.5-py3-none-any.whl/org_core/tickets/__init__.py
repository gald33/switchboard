"""The tickets port for a GitHub-issues org (SPEC §16 decision 4): labels, an issue form, and what proves them.

Measured 2026-09-17: NumeroTech declared `tickets: {tool: github-issues, label: ticket}` and the label did not
exist — nothing could be filed under it and nothing read from it, and the doctor was silent. The port is only real
once every label it names exists in the repo and a person has a form that files under it. `org tickets init`
creates both; `org doctor` check 6 reads them back.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

#: name -> (color, description). Colors are GitHub's six-hex, no '#'.
DEFAULT_LABELS: dict[str, tuple[str, str]] = {
    "ticket": ("0e8a16", "a report from a person or a role — the queue the account manager reads daily"),
    "ticket:needs-attention": ("d93f0b", "a ticket that needs a person's decision before a role can continue"),
    "ticket:needs-more-info": ("fbca04", "a ticket waiting on its reporter"),
    "severity:high": ("b60205", "filed by a production check (checks-core): high"),
    "severity:medium": ("e99695", "filed by a production check (checks-core): medium"),
    "severity:low": ("f9d0c4", "filed by a production check (checks-core): low"),
}
CHECK_LABEL_COLOR = "c5def5"   # check:<id> labels are minted per registry check by the checks adapter
OTHER_LABEL_COLOR = "ededed"

ISSUE_FORM = """name: Ticket
description: Report something broken, missing, or unclear. A role reads this queue every morning and answers here.
title: "[ticket] "
labels: ["{label}"]
body:
  - type: markdown
    attributes:
      value: |
        This is the org's ticket queue (see docs/TICKETS.md). Say what happened and where. The account manager
        reads every open ticket daily; when it is handled you are told here, on this issue.
  - type: dropdown
    id: kind
    attributes:
      label: What kind of report is this?
      options:
        - something is broken
        - something is missing
        - a question
    validations:
      required: true
  - type: textarea
    id: what
    attributes:
      label: What happened, and what did you expect instead?
    validations:
      required: true
  - type: input
    id: where
    attributes:
      label: Where and when (page, report id, time)
"""


def wanted_labels(port: dict[str, Any]) -> list[str]:
    """Every label the port needs to exist: the declared list, else the single `label`, else `ticket`."""
    return list(port.get("labels") or [port.get("label") or "ticket"])


def label_plan(existing: set[str] | list[str], wanted: list[str]) -> list[str]:
    have = set(existing)
    return [n for n in wanted if n not in have]


def _run(cmd: list[str], timeout: int = 60):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def gh_labels(repo: str, run=_run) -> set[str]:
    """Every label in the repo, over REST (GraphQL is not reachable from a Claude Code session)."""
    names: set[str] = set()
    page = 1
    while True:
        p = run(["gh", "api", f"repos/{repo}/labels?per_page=100&page={page}"])
        if p.returncode != 0:
            raise RuntimeError(f"gh api labels failed: {(p.stderr or p.stdout).strip()[:200]}")
        rows = json.loads(p.stdout or "[]")
        names |= {str(r.get("name")) for r in rows}
        if len(rows) < 100:
            return names
        page += 1


def gh_create_label(repo: str, name: str, color: str, description: str, run=_run) -> str:
    p = run(["gh", "api", "-X", "POST", f"repos/{repo}/labels", "-f", f"name={name}", "-f", f"color={color}", "-f", f"description={description}"])
    if p.returncode == 0:
        return "created"
    if "already_exists" in (p.stderr or "") + (p.stdout or ""):
        return "exists"
    raise RuntimeError(f"create label {name!r} failed: {(p.stderr or p.stdout).strip()[:200]}")


def ensure_labels(repo: str, names: list[str], run=_run) -> list[str]:
    """Create every named label that does not exist; idempotent. Returns one line per label created."""
    missing = label_plan(gh_labels(repo, run), names)
    out = []
    for n in missing:
        color, desc = DEFAULT_LABELS.get(n, (CHECK_LABEL_COLOR if n.startswith("check:") else OTHER_LABEL_COLOR, ""))
        out.append(f"{n}: {gh_create_label(repo, n, color, desc, run)}")
    return out


def render_template(label: str) -> str:
    return ISSUE_FORM.replace("{label}", label)


def write_template(repo_path: Path, rel: str, label: str) -> bool:
    """Write the issue form if it is not there; never overwrite an org's own form. Returns True if written."""
    p = repo_path / rel
    if p.exists():
        return False
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(render_template(label))
    return True
