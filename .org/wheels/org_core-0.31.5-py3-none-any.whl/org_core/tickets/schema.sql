-- tickets-core: the generic ticket store (SPEC §17). Reference DDL for Postgres; an org ships it as its own
-- migration (Supabase: apply-before-code, RLS on, no anon/authenticated privileges; Lucille: Alembic).
-- Extracted 2026-09-17 from Lucille's feedback_tickets / feedback_ticket_notes — the chat-specific columns
-- (chat_id, telegram ids, conversation/topic references, consent) are Lucille's and live in `refs` here.

create table if not exists feedback_tickets (
  id               uuid primary key default gen_random_uuid(),
  source           text not null,                      -- who filed: an org-declared set; user-channel vs internal is load-bearing
  reporter_ref     text,                               -- the org's own reference to the reporter (employee id, user id); null for internal sources
  feedback_text    text not null,
  status           text not null default 'open',       -- open | handled | needs_attention | needs_more_info | needs_followup | wontfix | closed
  kinds            text[] not null default '{}',       -- a SET: bug | feature_request | praise | question | unclear
  refs             jsonb not null default '{}'::jsonb, -- the org's references: route, report id, message id, ...
  metadata         jsonb not null default '{}'::jsonb, -- acknowledged_at, classifier output, anything tool-owned
  sentiment_score  double precision,
  deployed_version jsonb,                              -- the running build at filing: {app_version, modules|deployment, captured_at}
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);
create index if not exists feedback_tickets_status_idx on feedback_tickets (status);
create index if not exists feedback_tickets_created_idx on feedback_tickets (created_at desc);

-- append-only: a note is the only thing that outlives the session that concluded something (D4)
create table if not exists feedback_ticket_notes (
  id         uuid primary key default gen_random_uuid(),
  ticket_id  uuid not null references feedback_tickets (id) on delete cascade,
  author     text not null,                            -- a role name or a person
  note       text not null,
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists feedback_ticket_notes_ticket_idx on feedback_ticket_notes (ticket_id, created_at);

alter table feedback_tickets enable row level security;
alter table feedback_ticket_notes enable row level security;
-- no policies on purpose: the product's server (service role / Prisma credentials) is the only writer and reader;
-- the org's roles read through the org's prod_read port and write through the product's API.
