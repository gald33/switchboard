"""tickets-core: the lifecycle over rows (SPEC §17). Pure — no I/O, no extras — so every org's copy computes the same thing.

Extracted 2026-09-17 from Lucille's `scripts/ticket_flow.py` (`stage_of`, `find_open_loops`, `dangling_links`,
`prune_blockers`, the renderers) and `roadmap.py impact`. The one generalisation: which sources reach a person is an
org's declaration (`ports.tickets.person_sources`), not a constant — Lucille's is `telegram`.
"""

from __future__ import annotations

import datetime as dt
from typing import Any, Iterable

TERMINAL_TICKET_STATUSES: frozenset[str] = frozenset({"handled", "closed", "wontfix"})
WAITING_ON_REPORTER: frozenset[str] = frozenset({"needs_more_info"})
NOTIFYING_STATUS = "handled"
ITEM_PENDING_STATUSES: frozenset[str] = frozenset({"ready", "deferred", "blocked"})
STAGES: tuple[str, ...] = ("filed", "classified", "triaged", "scheduled", "in_flight", "verifying", "shipped", "closed")
KNOWN_STATUSES: frozenset[str] = frozenset({"open", "handled", "needs_attention", "needs_more_info", "needs_followup", "wontfix", "closed"})
KNOWN_KINDS: frozenset[str] = frozenset({"bug", "feature_request", "praise", "question", "unclear"})
UNOWNED_AFTER_DAYS = 14
ACK_GRACE_DAYS = 7
REPORTER_WAITING_AFTER_DAYS = 14
REPORTER_WAITING_STAGES: frozenset[str] = frozenset({"filed", "classified", "triaged", "scheduled", "in_flight", "verifying"})
DEFAULT_PERSON_SOURCES: frozenset[str] = frozenset({"telegram"})   # Lucille's; an org declares its own

FINDING_TITLES = {
    "unclosed_loop": "Shipped, reporter not told",
    "silent_close": "Shipped, then closed silently",
    "unowned": "Nobody picked it up",
    "reporter_waiting": "A real reporter is still waiting",
    "ack_missed": "Acknowledgement promised, never delivered",
    "regressed": "Reported again after the fix shipped",
    "dangling_link": "Item links a ticket that does not exist",
}


def parse_moment(value: Any) -> dt.datetime | None:
    """Accept a datetime or an ISO 8601 string; treat naive as UTC."""
    if isinstance(value, dt.datetime):
        return value if value.tzinfo else value.replace(tzinfo=dt.timezone.utc)
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = dt.datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=dt.timezone.utc)


def normalize_ticket(row: dict[str, Any]) -> dict[str, Any]:
    """One shape for every store: Lucille's `metadata_json` becomes `metadata`, ids are lower-case strings, kinds a list."""
    t = dict(row)
    if "metadata" not in t and "metadata_json" in t:
        t["metadata"] = t.get("metadata_json") or {}
    t["metadata"] = t.get("metadata") or {}
    t["id"] = str(t.get("id") or "").strip().lower()
    t["kinds"] = list(t.get("kinds") or [])
    t["status"] = (t.get("status") or "").strip()
    t["source"] = (t.get("source") or "").strip()
    return t


def item_key(item: dict[str, Any]) -> str | None:
    """An item's name from either loader: a served store says `key`, the files say `id`."""
    for field in ("key", "id"):
        value = item.get(field)
        if value:
            return str(value)
    return None


def index_by_ticket(items: Iterable[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    """ticket uuid -> the items claiming to answer it. A list: two items may each take part of one report."""
    index: dict[str, list[dict[str, Any]]] = {}
    for item in items:
        for raw in item.get("tickets") or []:
            key = str(raw).strip().lower()
            if key:
                index.setdefault(key, []).append(item)
    return index


def stage_of(ticket: dict[str, Any], items: list[dict[str, Any]]) -> str:
    """Which stage this ticket is at. The first true statement wins; the order is the pipeline's own, run backwards."""
    status = (ticket.get("status") or "").strip()
    if status in TERMINAL_TICKET_STATUSES:
        return "closed"
    if items:
        statuses = [(item.get("status") or "").strip() for item in items]
        if all(s == "done" for s in statuses):
            return "shipped"
        if any(s == "verifying" for s in statuses):
            return "verifying"
        if any(s == "claimed" for s in statuses):
            return "in_flight"
        return "scheduled"
    if status and status != "open":
        return "triaged"
    if ticket.get("kinds"):
        return "classified"
    return "filed"


def linked_done_at(items: list[dict[str, Any]]) -> dt.datetime | None:
    moments = [parse_moment(item.get("done_at")) for item in items]
    real = [m for m in moments if m is not None]
    return max(real) if real else None


def _ack_delivered(ticket: dict[str, Any]) -> bool:
    metadata = ticket.get("metadata") or ticket.get("metadata_json") or {}
    return bool(metadata.get("acknowledged_at"))


def _has_note(ticket: dict[str, Any]) -> bool:
    return bool(ticket.get("notes"))


def _finding(kind: str, *, ticket_id: str, status: str, source: str, stage: str, items: list[dict[str, Any]], why: str, person_sources: frozenset[str], **extra: Any) -> dict[str, Any]:
    return {
        "kind": kind, "ticket": ticket_id, "status": status, "source": source,
        "notifiable": source in person_sources,
        "stage": stage, "items": [item_key(item) for item in items], "why": why, **extra,
    }


def find_open_loops(tickets: Iterable[dict[str, Any]], index: dict[str, list[dict[str, Any]]], *, now: dt.datetime | None = None, person_sources: Iterable[str] | None = None) -> list[dict[str, Any]]:
    """Every place the pipeline stopped without finishing — one finding per ticket per kind, carrying the fact that produced it."""
    now = now or dt.datetime.now(dt.timezone.utc)
    people = frozenset(person_sources) if person_sources is not None else DEFAULT_PERSON_SOURCES
    findings: list[dict[str, Any]] = []
    for raw in tickets:
        ticket = normalize_ticket(raw)
        ticket_id = ticket["id"]
        if not ticket_id:
            continue
        items = index.get(ticket_id, [])
        status, source = ticket["status"], ticket["source"]
        created = parse_moment(ticket.get("created_at"))
        stage = stage_of(ticket, items)
        done_at = linked_done_at(items)
        common = {"ticket_id": ticket_id, "status": status, "source": source, "stage": stage, "items": items, "person_sources": people}
        if stage == "shipped":
            findings.append(_finding("unclosed_loop", why=f"every item answering this is done and the ticket is still {status!r} — nobody walked back", done_at=done_at.isoformat() if done_at else None, **common))
        if status in TERMINAL_TICKET_STATUSES and status != NOTIFYING_STATUS and source in people and items and all((item.get("status") or "") == "done" for item in items):
            findings.append(_finding("silent_close", why=f"shipped work, then closed as {status!r} — {NOTIFYING_STATUS!r} is the only status the reporter can see", done_at=done_at.isoformat() if done_at else None, **common))
        if status == "open" and not items and not _has_note(ticket) and created is not None and (now - created).days >= UNOWNED_AFTER_DAYS:
            findings.append(_finding("unowned", why=f"open and untouched for {(now - created).days}d — no note, no item, no triage decision", age_days=(now - created).days, **common))
        if status == NOTIFYING_STATUS and source in people and not _ack_delivered(ticket):
            metadata = ticket.get("metadata") or {}
            outcome = str((metadata.get("ack_delivery") or {}).get("outcome") or "")
            aged_out = created is not None and (now - created).days > ACK_GRACE_DAYS
            if outcome == "gave_up" or aged_out:
                findings.append(_finding("ack_missed", why=f"marked {NOTIFYING_STATUS!r} but never acknowledged (delivery outcome {outcome or 'unrecorded'!r})", ack_outcome=outcome or None, **common))
        if done_at is not None and created is not None and created > done_at:
            findings.append(_finding("regressed", why="filed after the item answering it was called done — the fix did not hold, or the item was mislinked", done_at=done_at.isoformat(), **common))
        if source in people and status not in TERMINAL_TICKET_STATUSES and status not in WAITING_ON_REPORTER and stage in REPORTER_WAITING_STAGES and created is not None and (now - created).days >= REPORTER_WAITING_AFTER_DAYS:
            age_days = (now - created).days
            if items:
                waiting_on = "waiting on " + ", ".join(f"{item_key(item)} ({(item.get('status') or '?').strip() or '?'})" for item in items)
            else:
                waiting_on = "waiting on nothing — a triage decision was taken and no roadmap item was filed off the back of it"
            findings.append(_finding("reporter_waiting", why=f"a real person has been at {status!r} for {age_days}d and has heard nothing — {waiting_on}", age_days=age_days, waiting_on=[{"item": item_key(item), "status": item.get("status")} for item in items], **common))
    findings.sort(key=lambda f: (f["kind"], not f["notifiable"], f["ticket"]))
    return findings


def dangling_links(index: dict[str, list[dict[str, Any]]], known_ticket_ids: Iterable[str]) -> list[dict[str, Any]]:
    """Items pointing at tickets that do not exist. Only meaningful over a COMPLETE ticket read."""
    known = {str(t).strip().lower() for t in known_ticket_ids}
    out: list[dict[str, Any]] = []
    for ticket_id, items in sorted(index.items()):
        if ticket_id not in known:
            out.append({"kind": "dangling_link", "ticket": ticket_id, "source": "", "notifiable": False, "items": [item_key(i) for i in items], "why": "no such ticket — `impact` silently counts one fewer than the file claims"})
    return out


def prune_blockers(index: dict[str, list[dict[str, Any]]], tickets: Iterable[dict[str, Any]]) -> list[str]:
    """Done items that must not be pruned yet, because a loop they carry is still open (D3)."""
    by_id = {str(t.get("id") or "").strip().lower(): t for t in tickets}
    blocked: set[str] = set()
    for ticket_id, items in index.items():
        ticket = by_id.get(ticket_id)
        if ticket is None or (ticket.get("status") or "").strip() in TERMINAL_TICKET_STATUSES:
            continue
        for item in items:
            if (item.get("status") or "") == "done":
                blocked.add(str(item_key(item)))
    return sorted(blocked)


def version_key(stamp: dict[str, Any] | None) -> str:
    """The comparable coordinate inside a version stamp: app_version (Lucille's `<deploy time>+<sha>`), else the
    capture time (`captured_at` / `created_at`) — a Vercel deployment stamp orders by when it was captured."""
    if not stamp:
        return ""
    app_version = str(stamp.get("app_version") or "")
    if app_version and app_version != "unknown":
        return app_version
    return str(stamp.get("captured_at") or stamp.get("created_at") or "")


def impact(item: dict[str, Any], tickets: Iterable[dict[str, Any]]) -> dict[str, Any]:
    """Every ticket the item links, marked before/after the item was called done — an `after` is the finding:
    somebody reported the same thing on a build at or past the one that was live when this was called finished."""
    linked = {str(t).strip().lower() for t in (item.get("tickets") or [])}
    done_at = parse_moment(item.get("done_at"))
    done_v = version_key(item.get("done_version"))
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    for raw in tickets:
        t = normalize_ticket(raw)
        if t["id"] not in linked:
            continue
        seen.add(t["id"])
        created = parse_moment(t.get("created_at"))
        filed_v = version_key(t.get("deployed_version"))
        if done_at is None and not done_v:
            verdict = "undated"
        else:
            after_time = done_at is not None and created is not None and created > done_at
            after_version = bool(done_v) and bool(filed_v) and filed_v >= done_v
            verdict = "after" if (after_time or after_version) else "before"
        rows.append({"ticket": t["id"], "status": t["status"], "source": t["source"], "created_at": t.get("created_at"), "deployed_version": filed_v or None, "verdict": verdict})
    missing = sorted(linked - seen)
    return {"item": item_key(item), "done_at": item.get("done_at"), "done_version": done_v or None, "tickets": rows, "missing": missing, "recurred": sum(1 for r in rows if r["verdict"] == "after")}


def render_findings(findings: list[dict[str, Any]]) -> str:
    if not findings:
        return "No open loops. Every ticket is either still in flight, or finished with its reporter told.\n"
    lines: list[str] = []
    by_kind: dict[str, list[dict[str, Any]]] = {}
    for f in findings:
        by_kind.setdefault(f["kind"], []).append(f)
    for kind in sorted(by_kind, key=lambda k: (-len(by_kind[k]), k)):
        group = by_kind[kind]
        people = [f for f in group if f.get("notifiable")]
        internal = [f for f in group if not f.get("notifiable")]
        lines += [f"## {FINDING_TITLES.get(kind, kind)} ({len(group)})", ""]
        for label, subset in ((f"A real reporter is waiting ({len(people)})", people), (f"Internal, auto-filed — nobody to tell ({len(internal)})", internal)):
            lines += [f"**{label}**", ""]
            if not subset:
                lines.append("- none")
            for f in subset:
                items = ", ".join(str(i) for i in f.get("items") or []) or "—"
                lines += [f"- `{f['ticket']}` [{f.get('source') or '?'}] → {items}", f"  {f['why']}"]
            lines.append("")
    return "\n".join(lines)


def render_stage(ticket: dict[str, Any], items: list[dict[str, Any]], stage: str, person_sources: Iterable[str] | None = None) -> str:
    people = frozenset(person_sources) if person_sources is not None else DEFAULT_PERSON_SOURCES
    t = normalize_ticket(ticket)
    lines = [f"ticket   {t.get('id')}", f"source   {t.get('source')}   kinds: {', '.join(t.get('kinds') or []) or '—'}", f"filed    {t.get('created_at')}", f"status   {t.get('status')}", f"stage    {stage}", "", "text     " + (str(t.get("feedback_text") or "").strip()[:300] or "—"), ""]
    if items:
        lines.append("roadmap")
        for item in items:
            lines.append(f"  {item_key(item)}  status={item.get('status')}  claim={item.get('claim') or item.get('claimed_by') or '—'}  done_at={item.get('done_at') or '—'}")
    else:
        lines.append("roadmap  no item links this ticket")
    lines.append("")
    if t["status"] == NOTIFYING_STATUS:
        stamp = (t.get("metadata") or {}).get("acknowledged_at")
        lines.append(f"reporter told at {stamp}" if stamp else "reporter NOT told — marked handled with no acknowledged_at stamp")
    elif t["source"] in people:
        lines.append(f"reporter not told (only {NOTIFYING_STATUS!r} speaks to a person)")
    else:
        lines.append(f"reporter internal source {t['source']!r} — nobody to tell")
    notes = t.get("notes") or []
    if notes:
        lines += ["", f"notes    {len(notes)}"] + [f"  {n.get('created_at')}  {str(n.get('note') or n.get('body') or '')[:160]}" for n in notes]
    return "\n".join(lines) + "\n"


def report_text(tickets: list[dict[str, Any]], items: list[dict[str, Any]], findings: list[dict[str, Any]], today: str) -> str:
    index = index_by_ticket(items)
    counts: dict[str, int] = {}
    for raw in tickets:
        t = normalize_ticket(raw)
        stage = stage_of(t, index.get(t["id"], []))
        counts[stage] = counts.get(stage, 0) + 1
    body = [f"# Ticket pipeline — {today}", "", f"{len(tickets)} tickets in view, {len(index)} of them linked to roadmap work.", "", "## Where they are", "", "| stage | tickets |", "|---|---|"]
    body += [f"| {stage} | {counts.get(stage, 0)} |" for stage in STAGES if counts.get(stage)]
    body += ["", "## Open loops", "", render_findings(findings)]
    return "\n".join(body)
