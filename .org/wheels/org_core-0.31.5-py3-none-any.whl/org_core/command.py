"""`org command` — the fleet, for the person the fleet waits on (SPEC §9, §11).

Every page before this one had the org as its subject and the operator as its reader. That is a report. A
command centre inverts it: **the operator is the subject**, because in this fleet they are the scarce
resource — measured on Lucille 2026-09-22, 25 items waiting on a person, the oldest 7 days, while every
role that named one of them sat blocked behind it.

So this reading answers three questions in order, and nothing else above the fold:

1. **What needs me?** Every org's operator queue, the sessions stopped on a permission prompt nobody
   unattended can answer, and the pull requests whose merge is the operator's — in one list, across the
   fleet, oldest first.
2. **What does it cost to keep not deciding?** Each item names the roles and sessions that are *stopped
   naming the same thing*. That is the number that makes a decision cheap, and no page here has shown it.
3. **Is the machinery running?** One row per org, one cell per signal. Dense, and read only when it is red.

**The cost link is evidence, not a causal claim.** An operator item and a role's blocker are matched when
they share a distinctive token — `LUCILLE_ADMIN_JWT`, `#1471`, a path — and the page prints the token it
matched on, so the reader judges the link rather than taking it. A heuristic that hid its evidence would be
the confident-window failure of rows 115 and 124 in a new costume.

An org that could not be read is a dark cell naming the reason. The fleet has three orgs and this session
can reach two of them; a command centre that quietly showed the two it had would be the worst lie available.
"""

from __future__ import annotations

import datetime as dt
import re
from typing import Any

from .brief import SECTION_ROWS, _sentence, ago
from .status import CLEAR, DARK, RED

#: a token worth matching on: backticked, or SCREAMING_SNAKE, or `#1234`, or a path. Anything shorter or
#: plainer matches by accident — two texts both containing `RESOLVED` are not two views of one thing.
TOKEN_RE = re.compile(r"`([^`\s]{3,60})`|\b([A-Z][A-Z0-9]*(?:_[A-Z0-9]+)+)\b|(#\d{2,6})\b|\b([\w.-]+/[\w./-]{3,})")


def tokens(text: str) -> set[str]:
    """The distinctive names a piece of text mentions. Lower-cased; a bare capitalised word is not one."""
    out: set[str] = set()
    for m in TOKEN_RE.finditer(str(text or "")):
        t = (m.group(1) or m.group(2) or m.group(3) or m.group(4) or "").strip("`.,;:()[]").lower()
        if len(t) < 4:
            continue
        if t.startswith("#") or "_" in t or "/" in t or "." in t or len(t) >= 8:
            out.add(t)
    return out


def costs(item_tokens: set[str], st: dict[str, Any]) -> dict[str, Any]:
    """Who is stopped naming the same thing this item names. Returns the roles, the sessions, and — always —
    the tokens the match was made on, because a link the reader cannot check is a link they have to trust."""
    s = st.get("subjects") or {}
    roles, sessions, shared = [], [], set()
    for g in s.get("blocked") or []:
        hit = item_tokens & tokens(g.get("text", ""))
        if hit:
            roles += list(g.get("roles") or [])
            shared |= hit
    for r in (s.get("spend") or {}).get("stopped") or []:
        hit = item_tokens & (tokens(r.get("needs", "")) | tokens(r.get("title", "")))
        if hit:
            sessions.append(r.get("title", "")[:60])
            shared |= hit
    return {"roles": sorted(set(roles)), "sessions": sessions, "on": sorted(shared)}


def _action(kind: str, org: dict[str, Any], **kw: Any) -> dict[str, Any]:
    repo, branch = org.get("repo"), org.get("default_branch") or "main"
    if kind == "file":
        return {"label": "open the item" if str(kw["path"]).endswith(".yaml") else "open the file",
                "href": f"https://github.com/{repo}/blob/{branch}/{kw['path']}"}
    if kind == "pr":
        return {"label": f"open #{kw['number']}", "href": f"https://github.com/{repo}/pull/{kw['number']}"}
    if kind == "session":
        return {"label": "answer it in that session", "href": ""}
    if kind == "roadmap":
        return {"label": f"roadmap show {kw['id']}", "href": ""}
    return {"label": "", "href": ""}


def needs_you(st: dict[str, Any], org: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """Everything in one org that only a person can clear, with what each one is holding up."""
    s = st.get("subjects") or {}
    out = []
    for q in s.get("queue") or []:
        head = str(q.get("head") or "").strip()
        days = q.get("age_days")
        tok = tokens(head) | tokens(q.get("body", ""))
        out.append({"org": org["id"], "what": _sentence(head), "why": str(q.get("body") or "").strip(),
                    "hours": (days or 0) * 24 if days is not None else None,
                    "ago": ago((days or 0) * 24) if days is not None else "", "at": q.get("since") or "",
                    "kind": "decision", "cost": costs(tok, st),
                    # a queue item from the repo links to the file it lives in: the operator file, or the roadmap
                    # item that carries the operator's arc; a board row has no page to open
                    "action": _action("file", org, path=q["source"]) if str(q.get("source", "")).endswith((".md", ".yaml"))
                              else _action("", org),
                    "source": f"{q.get('source')}"})
    for r in (s.get("spend") or {}).get("stopped") or []:
        out.append({"org": org["id"], "what": "A session is stopped waiting for permission",
                    "why": f"“{r.get('needs') or 'a permission prompt'}” in {r.get('title')} — nobody "
                           f"unattended can answer it, and it has cost ${r.get('cost', 0):.0f} so far.",
                    "hours": r.get("hours"), "ago": ago(r.get("hours")), "at": "",
                    "kind": "permission", "cost": {"roles": [], "sessions": [], "on": []},
                    "action": _action("session", org), "source": "BLOCKED ON A PROMPT"})
    ch = s.get("chair") or {}
    for x in ch.get("stale") or []:
        out.append({"org": org["id"], "what": f"Pull request #{x['number']} has been waiting on an act",
                    "why": "; ".join(x.get("why") or []) + ".", "hours": x.get("idle_hours"),
                    "ago": ago(x.get("idle_hours")), "at": x.get("updated_at") or "", "kind": "pr",
                    "cost": {"roles": [], "sessions": [], "on": []},
                    "action": _action("pr", org, number=x["number"]), "source": f"NEEDING ACTION #{x['number']}"})
    return out


#: one cell per signal, in the order a person triages: is it moving, is anyone home, is the plumbing up,
#: is it current. A cell is a state and a short reading, never a number alone.
SIGNALS = ("shipping", "roles", "scheduler", "reachable", "version", "spend")


def machinery(st: dict[str, Any], fleet_row: dict[str, Any] | None) -> dict[str, dict[str, str]]:
    s = st.get("subjects") or {}
    ch, ac, ls = s.get("chair") or {}, s.get("actuator") or {}, s.get("listeners") or {}
    v, sp = s.get("versions") or {}, s.get("spend") or {}
    h = ch.get("hours_since_last_merge")
    cells = {
        "shipping": ({"state": DARK, "read": "not checked"} if not ch.get("read") else
                     {"state": CLEAR, "read": f"{ago(h)} ago"} if h is not None and h < 24 else
                     {"state": RED, "read": f"{ago(h)} ago" if h is not None else "nothing in the window"}),
        "roles": ({"state": DARK, "read": "not checked"} if s.get("roles") is None else
                  {"state": RED, "read": f"{len(s['roles'])} not reporting"} if s.get("roles") else
                  {"state": CLEAR, "read": f"all {s.get('roles_total', 0)} reporting"}),
        "scheduler": ({"state": CLEAR, "read": "none needed"} if ac.get("needed") is False else
                      {"state": RED, "read": "switched off"} if ac.get("missing") else
                      {"state": DARK, "read": "not checked"} if not ac.get("read") else
                      {"state": CLEAR, "read": f"woke {ago(ac.get('age_hours'))} ago"} if ac.get("heartbeat") else
                      {"state": RED, "read": "not running"}),
        "reachable": ({"state": DARK, "read": "not checked"} if not ls.get("read") else
                      {"state": RED, "read": f"{len(ls.get('never') or []) + len(ls.get('lapsed') or [])} of "
                                             f"{ls.get('total', 0)} unreachable"}
                      if (ls.get("never") or ls.get("lapsed")) else
                      {"state": CLEAR, "read": f"all {ls.get('total', 0)} on the roster"}),
        "version": ({"state": DARK, "read": (fleet_row or {}).get("installed") and "records not read" or "not checked"}
                    if not v.get("read") else
                    {"state": RED, "read": f"{len(v['behind'])} of {len(v['behind']) + len(v['ok'])} behind"}
                    if v.get("behind") else {"state": CLEAR, "read": f"all on {v.get('lock')}"}),
        "spend": ({"state": DARK, "read": "not checked"} if not sp.get("read") else
                  {"state": RED, "read": f"${sp.get('total', 0):.0f}, one stopped"} if sp.get("stopped") else
                  {"state": CLEAR, "read": f"${sp.get('total', 0):.0f} cumulative"}),
    }
    return cells


def read(orgs: list[dict[str, Any]], now: dt.datetime | None = None) -> dict[str, Any]:
    """The fleet as one document. `orgs` is a list of `{org, status|None, why, fleet}`."""
    now = now or dt.datetime.now(dt.timezone.utc)
    rows, strip, dark = [], [], []
    for o in orgs:
        org, st = o["org"], o.get("status")
        if st is None:
            strip.append({"id": org["id"], "repo": org.get("repo"), "state": DARK,
                          "read": o.get("why") or "not read"})
            dark.append({"id": org["id"], "why": o.get("why") or "not read"})
            continue
        rows += needs_you(st, org, now)
        cells = machinery(st, o.get("fleet"))
        bad = [k for k, c in cells.items() if c["state"] == RED]
        strip.append({"id": org["id"], "repo": org.get("repo"), "cells": cells, "signals": list(SIGNALS),
                      "state": RED if bad else (DARK if any(c["state"] == DARK for c in cells.values()) else CLEAR),
                      "read": (", ".join(bad) if bad else "all clear")})
    rows.sort(key=lambda r: (-(len(r["cost"]["roles"]) + len(r["cost"]["sessions"])), -(r["hours"] or 0)))
    blocking = [r for r in rows if r["cost"]["roles"] or r["cost"]["sessions"]]
    live = [s for s in strip if s.get("cells")]
    return {"kind": "org-command", "at": now.isoformat(timespec="seconds"), "orgs": strip, "dark": dark,
            "state": RED if any(s["state"] == RED for s in live) or rows else (DARK if dark else CLEAR),
            "needs_you": rows, "shown": rows[:SECTION_ROWS * 2], "more": rows[SECTION_ROWS * 2:],
            "blocking": len(blocking), "signals": list(SIGNALS),
            "verdict": _verdict(rows, blocking, strip, dark)}


def _plural(n: int, one: str, many: str | None = None) -> str:
    """`1 org`, `2 orgs`. A verdict is the one sentence a person reads; `1 org(s)` reads as a machine's."""
    return f"{n} {one if n == 1 else (many or one + 's')}"


def _verdict(rows, blocking, strip, dark) -> str:
    live = [s for s in strip if s.get("cells")]
    red = [s for s in live if s["state"] == RED]
    if not rows:
        head = "Nothing is waiting on you"
    else:
        oldest = max(rows, key=lambda r: r["hours"] or 0)
        # across the orgs that are actually waiting, not the orgs that could be read — those differ the
        # moment one org is clear, and the reader is counting the places they have to go.
        spread = _plural(len({r["org"] for r in rows}), "org")
        head = (f"{_plural(len(rows), 'thing')} {'is' if len(rows) == 1 else 'are'} waiting on you "
                f"across {spread}, the oldest for {oldest['ago']}")
        if blocking:
            head += f", and {len(blocking)} of them name something a role is stopped on"
    tail = (f" {len(red)} of {_plural(len(live), 'org')} have something red in the machinery." if red else
            " The machinery is clear everywhere it could be read.")
    return _sentence(head) + tail + (
        f" {_plural(len(dark), 'org')} could not be read at all." if dark else "")


def render(d: dict[str, Any]) -> str:
    """The console in a terminal. Same reading, same order: the verdict, the matrix, then the work."""
    L = [f"command — the fleet at {d['at']}", f"  {d['verdict']}", ""]
    w = max((len(o["id"]) for o in d["orgs"]), default=8)
    L.append("  " + "org".ljust(w + 2) + "  ".join(s.ljust(22) for s in d["signals"]))
    for o in d["orgs"]:
        if not o.get("cells"):
            L.append("  " + o["id"].ljust(w + 2) + f"not read — {o['read']}")
            continue
        L.append("  " + o["id"].ljust(w + 2)
                 + "  ".join(f"{'●' if o['cells'][k]['state'] == 'RED' else ('○' if o['cells'][k]['state'] == 'CLEAR' else '—')} "
                             f"{o['cells'][k]['read']}".ljust(22) for k in d["signals"]))
    L.append("")
    L.append(f"waiting on you: {len(d['needs_you'])}" + (f", {d['blocking']} naming something a role is stopped on"
                                                         if d["blocking"] else ""))
    for r in d["needs_you"]:
        L.append(f"  [{r['org']}] {r['what']}  ({r['ago']})")
        c = r["cost"]
        if c["roles"] or c["sessions"]:
            L.append(f"      blocks {', '.join(c['roles'] + c['sessions'])} — both name {', '.join(c['on'])}")
    return "\n".join(L) + "\n"
