"""Tempo — the org's speed, measured, then made variable (SPEC §13).

Three halves. `gather` pulls the timestamped facts a tempo reading needs — the board
(records and handoff keys), the pull requests (opened, verdict, merged), the routines'
fires, the committed run ledgers — into one JSON so the reading is reproducible from a
file, and so a day's files can be merged into a week's. `report` turns those facts into
edge latencies (finding → dispatch → PR → verdict → merge → verified), the cycle per PR
kind, the handoffs nobody received, and the wakes. `wake_now` is the variable half: given
each role's declared events and targets, the roles a port-holding session should fire now
rather than at their next cron tick. Nothing here writes to the board, to GitHub or to the
routines: it reads, and it says.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any, Callable

from . import ROLE_IDS

Runner = Callable[[list[str], dict[str, str] | None], str]

VERDICT_RE = re.compile(r"\b(UNSOUND|SOUND|CANNOT TELL)\b")
ROLE_SIG_RE = re.compile(r"\b(Link|Marshal|Mason|Reed|Vera|Gus|Nora|Ruth|Ida|Doc)\b\s*\((ceo|dispatcher|builder|reviewer|verifier|checks-watch|registrar|account-manager|methods|doctor)\)")
PRODUCT_PREFIXES = ("src/", "prisma/", "supabase/migrations/", "backend/", "worker/", "web/", "modules/", "marketplace/")
ORG_PREFIXES = (".claude/", ".org/", "org.yaml", "docs/human/", "docs/ai/", "docs/AGENT_ORG.md", "CLAUDE.md", "checks/")
ROADMAP_PREFIXES = ("roadmap/", "ARCS.md")
PR_NUMBER_RE = re.compile(r"/pull/(\d+)|(?:^|[\s#])#?(\d{1,6})(?=$|[\s,;)])")

#: the events a role may declare in `tempo.wake_on`, and what each one reads (SPEC §13.1)
EVENTS = ("pr_opened", "correction_pushed", "verdict_sound", "handoff_written", "finding_refuted", "blocked_written", "receiver_missing")
#: hours; an edge slower than its target is what check 19 reports (targets from the 2026-09-19 design panel)
DEFAULT_TARGETS: dict[str, float] = {
    "finding_to_dispatch": 24, "dispatch_to_pr": 24, "open_to_verdict": 1, "verdict_to_merge": 1,
    "unsound_open": 24, "merge_to_verified": 72, "handoff_received": 1, "blocked_forwarded": 1,
    "pr_needing_action": 4,   # an open PR red, conflicted or changes-requested with nobody acting this long is unwatched (Lucille 2026-09-19: 66 unwatched PR-hours)
}
#: package defaults for the roles that have an event to wake on; the manifest's `roles.<r>.tempo` wins.
#: `on_demand` is the actuator's act: `spawn` a one-shot session, `fire_trigger` a sourced fresh routine, `none`.
#: `on_demand: auto` follows the role's runtime — `session` → `dm` (the receiver is listening; the operator's ruling of
#: 2026-09-19: every role but the builder is a persistent agent that parks a listener), `spawned` → `spawn`, `fresh` → `fire_trigger`.
#: The operator's three rulings on the wake graph, later the same day (rows 75–77): the reviewer is "a fresh spawn without
#: context" (`spawned` — a sender's DM to it is routed to the actuator, which spawns it on that wake, `wake_route`); the CEO is
#: "persistent and only the big picture" (`wake_on: []`, `on_demand: none` — nothing wakes it; SOUND verdicts and forwarded
#: blocks wait for its clock, and `targets()` derives `verdict_to_merge` from that clock); the dispatcher is a receiver
#: (`auto` → `dm`) because routed wakes land on it, while the plan never DMs the actuator it runs in.
DEFAULT_ROLE_TEMPO: dict[str, dict[str, Any]] = {
    "reviewer": {"wake_on": ["pr_opened", "correction_pushed"], "target_hours": 0.5, "min_interval_hours": 0, "on_demand": "auto", "max_concurrent": 3, "order": "oldest_first"},
    # the CEO is persistent and always listening (the operator, 2026-09-20, row 86; for one day before that, woken by nothing — row 77):
    # a SOUND verdict, a handoff to it and a role's blocked field DM it; its cron is the floor. An org opts out with `wake_on: []`, `on_demand: none`.
    "ceo": {"wake_on": ["verdict_sound", "handoff_written", "blocked_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "dispatcher": {"wake_on": ["finding_refuted"], "target_hours": 2, "min_interval_hours": 1, "on_demand": "auto"},
    "builder": {"on_demand": "spawn", "self_wake": {"after_pr_minutes": [45, 105], "floor_hours": 6, "max_polls": 3}},
    "registrar": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "account-manager": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "verifier": {"wake_on": ["handoff_written"], "target_hours": 1, "min_interval_hours": 0.5, "on_demand": "auto", "max_concurrent": 1},
    "checks-watch": {"on_demand": "none"}, "methods": {"on_demand": "none"}, "doctor": {"on_demand": "none"},
}
#: minutes a persistent role parks its listener for before re-parking — a day (the operator, 2026-09-19, superseding "120 is
#: better": "the 120 minute listeners could be 24 hours"). The hub's listener re-registers presence every 25 s under a 90 s TTL,
#: so a day-long park is a day of presence; an expiry is one turn a day, and a listener that died is noticed by check 4 or the
#: role's own cron, whichever reads first. One listener per session: `register` answers `listener_alive` from the hub's
#: `listener/<agent_id>` heartbeat key, and a turn that finds one running parks nothing.
DEFAULT_LISTEN_MINUTES = 1440
AGENTS_KEY = "coord/tempo/agents"
RUNTIME_ACT = {"session": "dm", "spawned": "spawn", "fresh": "fire_trigger"}


def on_demand_act(role_cfg: dict[str, Any], runtime: str | None) -> str:
    act = str(role_cfg.get("on_demand") or "auto")
    if act != "auto":
        return act
    return RUNTIME_ACT.get(str(runtime or ""), "none")


def actuator_of(manifest: dict[str, Any]) -> str:
    return str((manifest.get("tempo") or {}).get("actuator") or "dispatcher")


def wake_route(role: str, manifest: dict[str, Any]) -> tuple[str, str]:
    """Whom a sender's `org tempo dm --role <role>` reaches, and how (rows 75, 77): `("dm", role)` for a listening persistent
    role and for the actuator itself; `("route", <actuator>)` for a spawned or fresh role — the DM lands on the actuator's
    listener as `wake <role>: <text>` and its plan spawns or fires the role on that wake; `("clock", role)` for a role nothing
    wakes on demand (`on_demand: none` — the doctor, or an org that opts a role out; the board key is the handoff and its cron
    reads it. The CEO was that role for one day, row 77; since 0.15.0 it listens, row 86)."""
    entry = (manifest.get("roles") or {}).get(role) or {}
    runtime = entry.get("runtime") or _default(role, "runtime")
    if isinstance(runtime, dict):   # an unlayered manifest: role.yaml's `runtime: {allowed, default}`
        runtime = runtime.get("default")
    cfg = dict(DEFAULT_ROLE_TEMPO.get(role, {}))
    cfg.update(entry.get("tempo") or {})
    act = on_demand_act(cfg, runtime)
    if role == actuator_of(manifest) or act == "dm":
        return "dm", role
    if act in ("spawn", "fire_trigger"):
        return "route", actuator_of(manifest)
    return "clock", role


def actuator_duty(manifest: dict[str, Any]) -> dict[str, Any]:
    """What the actuator is for in this org: the role the manifest names for it, whether that role is enabled, and the
    enabled roles that are started only through it (`wake_route` answers `route` — spawned or fired, never listening).

    An org that enables neither the actuator nor any role routed to it has nothing for one to do, so a missing
    heartbeat there is not a death. Measured 2026-09-23 on org-core's own reading (0.31.3): one role, the CEO, which
    listens, and a page whose headline was "DEAD actuator … the four-call wake is not running" — red for a part the
    org was never meant to have. The converse is the real failure, and this names it too: a role routed to an
    actuator that is not enabled has nothing that will ever start it.

    Broken looks like: `routed` is empty for a manifest enabling the builder with the dispatcher disabled, or
    `enabled` is False for Lucille's manifest."""
    role = actuator_of(manifest)
    roles = manifest.get("roles") or {}
    on = [r for r, e in roles.items() if (e or {}).get("enabled", True)]
    routed = sorted(r for r in on if r != role and wake_route(r, manifest) == ("route", role))
    return {"role": role, "enabled": role in on, "routed": routed}


#: the machine form a routed DM carries: `wake reviewer: pr_opened #211`
REQUEST_RE = re.compile(r"\bwake\s+([a-z][a-z0-9-]*)\s*:\s*([a-z_]+)\s+(\S+)", re.I)


def requests_from_inbox(inbox: Any) -> list[dict[str, Any]]:
    """The routed wakes in an actuator's inbox (`switchboard --json inbox`, a list or `{messages: [...]}`): one request per
    `wake <role>: <event> <what>` line, with who sent it and when. A request names the thing to act on now, target or not."""
    msgs = inbox.get("messages") if isinstance(inbox, dict) else inbox
    out: list[dict[str, Any]] = []
    for m in msgs or []:
        if not isinstance(m, dict):
            continue
        body = m.get("body") if m.get("body") is not None else m.get("text")
        if isinstance(body, dict):
            body = body.get("text") or body.get("body") or json.dumps(body)
        for role, event, what in REQUEST_RE.findall(str(body or "")):
            out.append({"role": role.lower(), "event": event.lower(), "what": what.rstrip(".,;"), "from": m.get("from") or m.get("sender") or m.get("agent_id"),
                        "at": m.get("at") or m.get("ts") or m.get("created_at")})
    return out


def cron_period_hours(cadence: str, now: dt.datetime | None = None) -> float | None:
    """The gap between two consecutive fires of a cron, in hours; None when the cadence is not a cron."""
    now = now or dt.datetime.now(dt.timezone.utc)
    n1 = cron_next(cadence, now)
    n2 = cron_next(cadence, n1) if n1 else None
    return round((n2 - n1).total_seconds() / 3600, 2) if n1 and n2 else None


# --- cron: the next fire, for a listener's --until and the hold rule ------------------

def _cron_field(spec: str, lo: int, hi: int) -> set[int]:
    out: set[int] = set()
    for part in spec.split(","):
        part = part.strip()
        step = 1
        if "/" in part:
            part, st = part.split("/", 1)
            step = max(1, int(st))
        if part in ("*", ""):
            rng = range(lo, hi + 1)
        elif "-" in part:
            a, b = part.split("-", 1)
            rng = range(int(a), int(b) + 1)
        else:
            rng = range(int(part), int(part) + 1)
        out |= {x for x in rng if (x - rng.start) % step == 0}
    return out


def cron_next(cadence: str, now: dt.datetime, horizon_days: int = 8) -> dt.datetime | None:
    """The next fire of a 5-field UTC cron after `now`, minute by minute, or None when the shape is not a cron."""
    parts = (cadence or "").split()
    if len(parts) != 5:
        return None
    try:
        mins, hrs, doms, mons, dows = (_cron_field(parts[0], 0, 59), _cron_field(parts[1], 0, 23), _cron_field(parts[2], 1, 31),
                                       _cron_field(parts[3], 1, 12), {d % 7 for d in _cron_field(parts[4], 0, 7)})
    except ValueError:
        return None
    t = (now.astimezone(dt.timezone.utc) + dt.timedelta(minutes=1)).replace(second=0, microsecond=0)
    end = t + dt.timedelta(days=horizon_days)
    while t <= end:
        if t.minute in mins and t.hour in hrs and t.day in doms and t.month in mons and ((t.weekday() + 1) % 7) in dows:
            return t
        t += dt.timedelta(minutes=1)
    return None


# --- the agents registry: who is listening, and how to address them ------------------

def agents_registry(board: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """role -> {agent_id, name, session_id, registered_at, listen_until} from coord/tempo/agents."""
    row = _latest_records(board).get(AGENTS_KEY)
    v = _value(row) if row else {}
    roles = v.get("roles") if isinstance(v, dict) else None
    return {r: e for r, e in (roles or {}).items() if isinstance(e, dict)}


def roster_ids(agents: list[Any]) -> set[str]:
    """The agent ids present on the hub's roster (`switchboard --json agents`), whatever the row shape."""
    out: set[str] = set()
    for a in agents or []:
        if isinstance(a, str):
            out.add(a)
        elif isinstance(a, dict):
            for k in ("agent_id", "id", "agent"):
                if a.get(k):
                    out.add(str(a[k]))
    return out


def listeners(facts: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """Per persistent role: registered agent, on the roster now, listen_until, and the age of the registration."""
    reg = agents_registry(facts.get("board", []))
    present = roster_ids(facts.get("agents", []))
    out = []
    for role, meta in facts.get("roles", {}).items():
        if (meta.get("runtime") or "") != "session":
            continue
        e = reg.get(role) or {}
        aid = e.get("agent_id")
        out.append({"role": role, "agent_id": aid, "session_id": e.get("session_id"), "registered_at": e.get("registered_at"),
                    "registered_age_hours": hours(e.get("registered_at"), now.isoformat()) if e.get("registered_at") else None,
                    "listen_until": e.get("listen_until"),
                    "listening": bool(aid and aid in present), "roster_read": bool(facts.get("agents") is not None)})
    return out
#: a verdict is the first line of a reviewer's comment, or the machine line; an author's reply that quotes one is not
MACHINE_VERDICT_RE = re.compile(r"^\s*verdict:\s*(SOUND|UNSOUND|CANNOT TELL)\s+head:\s*([0-9a-f]{7,40})", re.I | re.M)
VERDICT_HEAD_STARTS = ("#", "**", "_", "verdict", "re-review", "reviewed", "review:", "review —", "review -")
SHA_RE = re.compile(r"(?:pinned to|pinned at|reviewed at|verdict at|at|head:?|@)\s*`?([0-9a-f]{7,40})`?", re.I)
AUTHOR_ROLES = ("ceo", "builder", "methods", "installer", "account-manager", "registrar", "verifier", "doctor", "checks-watch", "dispatcher")


def verdict_of(body: str, role: str = "unknown") -> tuple[str, str | None, str] | None:
    """(verdict, pinned sha, via) when a comment IS a verdict: the machine line `verdict: X head: <sha>`, or a first line
    that opens like a verdict headline. A comment signed by a non-reviewer role, or whose first line quotes
    `your <verdict>`, is an author's note (measured: #203 "your CANNOT TELL surfaced…", #208's own PR note)."""
    if not body or role in AUTHOR_ROLES:
        return None
    m = MACHINE_VERDICT_RE.search(body)
    if m:
        return m.group(1).upper(), m.group(2), "machine line"
    first = body.strip().splitlines()[0].strip() if body.strip() else ""
    low = first.lower()
    vm = VERDICT_RE.search(first[:200])
    if not vm or not low.startswith(VERDICT_HEAD_STARTS) or re.search(r"\byour\s+(?:sound|unsound|cannot tell)", low):
        return None
    sha = SHA_RE.search(first) or SHA_RE.search(body[:400])
    return vm.group(1), (sha.group(1) if sha else None), "headline"
FACTS_DIR = ".org/tempo"


def _run(cmd: list[str], env: dict[str, str] | None = None) -> str:
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=120, env={**os.environ, **(env or {})})
    if out.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd[:3])}: {(out.stderr or out.stdout).strip()[:300]}")
    return out.stdout


def parse_ts(s: Any) -> dt.datetime | None:
    if not s or not isinstance(s, str):
        return None
    s = s.strip().replace("Z", "+00:00")
    try:
        d = dt.datetime.fromisoformat(s)
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)


def hours(a: Any, b: Any) -> float | None:
    ta, tb = parse_ts(a), parse_ts(b)
    if ta is None or tb is None:
        return None
    return round((tb - ta).total_seconds() / 3600, 2)


def _min_ts(a: str | None, b: str | None) -> str | None:
    if not a:
        return b
    if not b:
        return a
    return a if (parse_ts(a) or dt.datetime.max.replace(tzinfo=dt.timezone.utc)) <= (parse_ts(b) or dt.datetime.max.replace(tzinfo=dt.timezone.utc)) else b


def pr_numbers(val: Any) -> list[int]:
    """Every PR number a record field names: an int, a URL, '#204', or a list of those."""
    if isinstance(val, bool):
        return []
    if isinstance(val, int):
        return [val]
    if isinstance(val, list):
        return [n for v in val for n in pr_numbers(v)]
    if isinstance(val, dict):
        return pr_numbers(val.get("number") or val.get("pr") or val.get("url"))
    if isinstance(val, str):
        return [int(m.group(1) or m.group(2)) for m in PR_NUMBER_RE.finditer(val)]
    return []


# --- gather ------------------------------------------------------------------

def gather_board(workspace: str, run: Runner = _run, prefixes: tuple[str, ...] = ("roles/", "coord/"),
                 url: str | None = None) -> list[dict[str, Any]]:
    """Every board row under the prefixes, with its value parsed. Records are JSON strings inside `value`.

    `url` is the manifest's `ports.coordination.url`. Without it the CLI dials whatever `SWITCHBOARD_URL`
    the ambient environment holds — which is not this org's hub, and on a fleet machine is another org's.
    Measured 2026-09-20 against switchboard 2.4.1: a hub prints "agents started here will dial
    https://switchboard.lucille-ai.com, not this hub" on startup for exactly this reason. Every other reader
    in the package already passes it (doctor.py:74-75, cli.py:238/251/275); these two did not.
    """
    env = {"SWITCHBOARD_WORKSPACE": workspace}
    if url:
        env["SWITCHBOARD_URL"] = url
    rows = json.loads(run(["switchboard", "--json", "board", "list"], env) or "[]")
    out: list[dict[str, Any]] = []
    for r in rows:
        key = str(r.get("key", ""))
        if not key.startswith(prefixes):
            continue
        try:
            got = json.loads(run(["switchboard", "--json", "board", "get", key], env) or "{}")
        except (RuntimeError, json.JSONDecodeError):
            got = {}
        value = got.get("value", r.get("value"))
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except json.JSONDecodeError:
                value = {"_raw": value[:400]}
        out.append({"key": key, "updated_at": got.get("updated_at") or r.get("updated_at"), "expires_at": r.get("expires_at"), "value": value})
    return out


def classify_paths(paths: list[str]) -> str:
    if any(p.startswith(PRODUCT_PREFIXES) for p in paths):
        return "product"
    if paths and all(p.startswith(ROADMAP_PREFIXES) for p in paths):
        return "roadmap"
    if paths and all(p.startswith(ORG_PREFIXES) or p.startswith(ROADMAP_PREFIXES) for p in paths):
        return "org"
    return "docs" if paths else "unknown"


def author_role(body: str, head_ref: str = "") -> str:
    m = ROLE_SIG_RE.search(body or "")
    if m:
        return m.group(2)
    if "org-core CEO session" in (body or ""):
        return "installer"
    if head_ref.startswith(("cursor/", "e2e/", "dependabot/")):
        return "human"
    return "unknown"


def gather_prs(slug: str, since: str, run: Runner = _run, limit: int = 80) -> list[dict[str, Any]]:
    """Pull requests updated since `since` with their files, comments and reviews — the timestamps a cycle time needs."""
    prs = json.loads(run(["gh", "api", f"repos/{slug}/pulls?state=all&sort=updated&direction=desc&per_page={limit}"], None) or "[]")
    out: list[dict[str, Any]] = []
    for pr in prs:
        if str(pr.get("updated_at", "")) < since:
            continue
        n = pr["number"]
        files = json.loads(run(["gh", "api", f"repos/{slug}/pulls/{n}/files?per_page=100"], None) or "[]")
        comments = json.loads(run(["gh", "api", f"repos/{slug}/issues/{n}/comments?per_page=100"], None) or "[]")
        reviews = json.loads(run(["gh", "api", f"repos/{slug}/pulls/{n}/reviews?per_page=50"], None) or "[]")
        paths = [f.get("filename", "") for f in files]
        events = [{"at": c.get("created_at"), "body": c.get("body") or ""} for c in comments]
        events += [{"at": r.get("submitted_at"), "body": r.get("body") or "", "state": r.get("state")} for r in reviews]
        verdicts = []
        for e in events:
            v = verdict_of(e["body"], author_role(e["body"])) if e.get("at") else None
            if v:
                verdicts.append({"at": e["at"], "verdict": v[0], "sha": v[1], "via": v[2]})
        verdicts.sort(key=lambda x: x["at"])
        head_sha = (pr.get("head") or {}).get("sha")
        latest_review: dict[str, str] = {}
        for r in sorted(reviews, key=lambda r: r.get("submitted_at") or ""):
            if r.get("state") in ("APPROVED", "CHANGES_REQUESTED", "DISMISSED"):
                latest_review[str((r.get("user") or {}).get("login") or "")] = str(r["state"])
        out.append({
            "repo": slug, "number": n, "title": pr.get("title"), "state": pr.get("state"), "draft": bool(pr.get("draft")),
            "head_ref": (pr.get("head") or {}).get("ref"), "head_sha": head_sha,
            "opened_at": pr.get("created_at"), "updated_at": pr.get("updated_at"),
            "merged_at": pr.get("merged_at"), "closed_at": pr.get("closed_at"),
            "head": head_state(slug, n, head_sha, run) if pr.get("state") == "open" and head_sha else None,
            "changes_requested": "CHANGES_REQUESTED" in latest_review.values(),
            "author_role": author_role(pr.get("body") or "", (pr.get("head") or {}).get("ref") or ""),
            "kind": classify_paths(paths), "files": paths[:200],
            "first_verdict_at": verdicts[0]["at"] if verdicts else None, "first_verdict": verdicts[0]["verdict"] if verdicts else None,
            "verdicts": verdicts,
            "comments": [{"at": e.get("at"), "role": author_role(e.get("body") or ""), "head": (e.get("body") or "")[:120]} for e in events],
        })
    return out


RED_CONCLUSIONS = ("failure", "timed_out", "startup_failure", "action_required")


def head_state(slug: str, n: int, sha: str, run: Runner = _run) -> dict[str, Any]:
    """What GitHub says about an open PR's head now: the check runs' conclusions, the commit's combined status — a
    status-API red (Vercel's) is not a check run and is absent from the check-runs list, so a chair reading that list
    alone reads green (Lucille 2026-09-21, row 112) — and `mergeable_state`, which GitHub recomputes after a push and
    reports `unknown` meanwhile. Each endpoint is read on its own; one that fails leaves `None`, never a green."""
    out: dict[str, Any] = {"sha": sha, "checks": None, "status": None, "mergeable_state": None, "mergeable": None}
    try:
        cr = (json.loads(run(["gh", "api", f"repos/{slug}/commits/{sha}/check-runs?per_page=100"], None) or "{}") or {}).get("check_runs") or []
        out["checks"] = {"total": len(cr), "red": sorted({str(c.get("name") or "?") for c in cr if c.get("conclusion") in RED_CONCLUSIONS}),
                         "pending": sorted({str(c.get("name") or "?") for c in cr if c.get("status") != "completed"})}
    except Exception as e:  # noqa: BLE001 — unread is unread; the row says so
        out["checks_error"] = str(e)[:120]
    try:
        st = json.loads(run(["gh", "api", f"repos/{slug}/commits/{sha}/status"], None) or "{}") or {}
        out["status"] = {"state": st.get("state"), "failing": sorted({str(x.get("context") or "?") for x in st.get("statuses") or [] if x.get("state") in ("failure", "error")}),
                         "pending": sorted({str(x.get("context") or "?") for x in st.get("statuses") or [] if x.get("state") == "pending"})}
    except Exception as e:  # noqa: BLE001
        out["status_error"] = str(e)[:120]
    try:
        pr = json.loads(run(["gh", "api", f"repos/{slug}/pulls/{n}"], None) or "{}") or {}
        out["mergeable_state"], out["mergeable"] = pr.get("mergeable_state"), pr.get("mergeable")
    except Exception as e:  # noqa: BLE001
        out["mergeable_error"] = str(e)[:120]
    return out


def needs_action(p: dict[str, Any]) -> list[str]:
    """Why an open PR waits on somebody's act: CI red, a status-API failure, a conflict, or changes requested."""
    h = p.get("head") or {}
    why: list[str] = []
    if (h.get("checks") or {}).get("red"):
        why.append("ci red: " + ", ".join(h["checks"]["red"][:4]))
    if (h.get("status") or {}).get("failing"):
        why.append("status failure: " + ", ".join(h["status"]["failing"][:4]))
    if h.get("mergeable_state") == "dirty":
        why.append("conflicted")
    if p.get("changes_requested"):
        why.append("changes requested")
    return why


def _default(role: str, attr: str) -> Any:
    """A role's package default for `attr` (`runtime`, `cadence`, …): the package attribute when it has one, else the
    contract's field, unwrapped from role.yaml's `{allowed, default}` / `{default, label}` shape to the default itself."""
    try:
        from .roles import discover
        pkg = discover().get(role)
        if not pkg:
            return None
        v = getattr(pkg, attr, None)
        if v is None and isinstance(getattr(pkg, "contract", None), dict):
            v = pkg.contract.get(attr)
        if isinstance(v, dict) and "default" in v:
            v = v["default"]
        return v
    except Exception:
        return None


def gather_runs(repo: Path) -> list[dict[str, Any]]:
    """The committed run ledgers, `.org/runs/<role>.jsonl`, one record per line."""
    out: list[dict[str, Any]] = []
    d = repo / ".org" / "runs"
    if not d.is_dir():
        return out
    for p in sorted(d.glob("*.jsonl")):
        for line in p.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            rec.setdefault("role", p.stem)
            out.append(rec)
    return out


def role_tempo(manifest: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Each enabled role's tempo: the package default under the manifest's `roles.<r>.tempo`."""
    out: dict[str, dict[str, Any]] = {}
    for r, e in manifest.get("roles", {}).items():
        if not e.get("enabled", True):
            continue
        cfg = dict(DEFAULT_ROLE_TEMPO.get(r, {}))
        cfg.update(e.get("tempo") or {})
        if cfg:
            out[r] = cfg
    return out


def targets(manifest: dict[str, Any], now: dt.datetime | None = None) -> dict[str, float]:
    """The edge targets: the package defaults, then — when nothing wakes the CEO on demand (row 77) and it has a cron — the
    CEO's own period as `verdict_to_merge`, since a SOUND verdict waits for that clock by design; the manifest's
    `tempo.targets` wins over both."""
    t = dict(DEFAULT_TARGETS)
    ceo = (manifest.get("roles") or {}).get("ceo") or {}
    if ceo.get("enabled", True) and not (role_tempo(manifest).get("ceo") or {}).get("wake_on"):
        period = cron_period_hours(str(ceo.get("cadence") or _default("ceo", "cadence") or ""), now)
        if period:
            t["verdict_to_merge"] = period
    t.update({k: float(v) for k, v in ((manifest.get("tempo") or {}).get("targets") or {}).items()})
    return t


#: bullets under the operator file's waiting heading, capped: each undated one costs a `git log -S` over the file's
#: whole history, and `org status` gathers live.
OPERATOR_BULLET_CAP = 40


def _lock_facts(repo: Path) -> dict[str, Any]:
    """The applied lock, carried in the facts so a reading can say which org-core wrote each record without reaching
    the disk again (SPEC §18, rows 87, 88). `{}` when the repo was never applied, which is itself the finding."""
    import yaml

    from .lock import read as read_lock
    try:
        return read_lock(repo) or {}
    except (OSError, ValueError, yaml.YAMLError):
        return {}


#: an operator arc's items that wait on the operator: startable, so nothing but a ruling stands between them and done.
#: `blocked` waits on another item, `deferred` was put off on purpose, `verifying` and `done` are past the ruling.
OPERATOR_ARC_STATUSES = ("ready",)


def _first_paragraph(text: Any, limit: int = 300) -> str:
    para = str(text or "").strip().split("\n\n", 1)[0]
    flat = " ".join(para.split())
    return flat if len(flat) <= limit else flat[:limit].rsplit(" ", 1)[0] + "…"


def _operator_arc(repo: Path, manifest: dict[str, Any]) -> dict[str, Any] | None:
    """The open items of the roadmap arc the manifest names as the operator's (`ports.work_store.operator_arc`),
    each dated by the commit that introduced its file — the repo half of the operator queue for an org that keeps it
    in its roadmap rather than in an operator file.

    Measured 2026-09-23 on org-core's own reading: "Waiting on you — not checked", because org-core has no operator
    file, while the decisions only the operator can rule sat in `roadmap/items/` under `org-core-decisions` — four
    `ready`, the oldest filed 2026-09-20. The queue existed; the reading had no way to be told where.

    `None` when no arc is declared or the items directory cannot be read — never an empty queue (row 65). An item
    that does not parse is named in `unparsed`, not skipped in silence."""
    import yaml

    from . import doctor as dr
    ws = (manifest.get("ports") or {}).get("work_store") or {}
    arc = ws.get("operator_arc")
    if not arc:
        return None
    base = str(ws.get("files") or "roadmap/").strip("/")
    d = repo / base / "items"
    if not d.is_dir():
        return None
    items, unparsed, carried = [], [], 0
    for path in sorted(d.glob("*.yaml")):
        try:
            doc = yaml.safe_load(path.read_text()) or {}
        except (OSError, yaml.YAMLError):
            unparsed.append(path.name)
            continue
        if not isinstance(doc, dict) or doc.get("arc") != arc:
            continue
        carried += 1
        if doc.get("status") not in OPERATOR_ARC_STATUSES:
            continue
        rel = f"{base}/items/{path.name}"
        since = dr._introduced_at(repo, rel, f"id: {doc.get('id')}") if doc.get("id") else None
        items.append({"head": str(doc.get("title") or doc.get("id") or path.stem), "body": _first_paragraph(doc.get("evidence")),
                      "since": since.isoformat() if since else None, "source": rel, "id": doc.get("id"),
                      "dated_by": "the commit that introduced it" if since else "nothing"})
    return {"arc": str(arc), "dir": f"{base}/items", "carried": carried, "items": items[:OPERATOR_BULLET_CAP],
            "unparsed": unparsed}


def _operator_waiting(repo: Path, manifest: dict[str, Any]) -> dict[str, Any] | None:
    """The repo half of the operator queue: the operator file's `Waiting on the operator` bullets, and — when the
    manifest names one — the open items of the operator's roadmap arc. Either is the half; both are read when both exist.

    `None`, never `{}`, when neither could be read: an unread half must not read as an empty one (row 65)."""
    arc = _operator_arc(repo, manifest)
    fq = _operator_file(repo, manifest)
    if arc is None:
        return fq
    label = f"the `{arc['arc']}` arc" + (" and the operator file" if fq else "")
    return {"file": fq["file"] if fq else arc["dir"], "label": label,
            # the arc IS a surface: the file's missing section is not a missing surface when the arc stands in for it
            "has_section": bool(arc["carried"]) or bool(fq and fq["has_section"]),
            "items": list(arc["items"]) + (fq["items"] if fq else []),
            "arc": arc["arc"], "arc_dir": arc["dir"], "arc_carried": arc["carried"], "arc_unparsed": arc["unparsed"],
            "file_read": fq is not None}


def _operator_file(repo: Path, manifest: dict[str, Any]) -> dict[str, Any] | None:
    """The operator file's `Waiting on the operator` bullets, each dated by the ISO date it carries, else by the commit
    that introduced it — the half of the operator queue that lives in the repo rather than on the board (doctor check 15).

    `None`, never `{}`, when the port or the file is missing: an unread half must not read as an empty one (row 65)."""
    from . import doctor as dr
    rel = (manifest.get("ports") or {}).get("operator_surface")
    if not rel:
        return None
    path = repo / str(rel)
    try:
        text = path.read_text()
    except OSError:
        return None
    items = []
    for b in dr._bullets_under(text, dr.WAITING_HEADING_RE)[:OPERATOR_BULLET_CAP]:
        m = dr.ISO_DATE_RE.search(b)
        raw = b[:48].rsplit(" ", 1)[0] if len(b) > 48 else b   # `git log -S` needs what the file says, markup included
        since = (dr.parse_ts(m.group(1) + ("T" + m.group(2) if m.group(2) else "T00:00") + "Z") if m
                 else dr._introduced_at(repo, str(rel), raw))
        items.append({"head": dr._bullet_head(b), "body": dr._bullet_body(b), "source": str(rel),
                      "since": since.isoformat() if since else None,
                      "dated_by": "its own date" if m else ("the commit that introduced it" if since else "nothing")})
    return {"file": str(rel), "label": "the operator file", "has_section": bool(dr.WAITING_HEADING_RE.search(text)),
            "items": items}


def gather(repo: Path, manifest: dict[str, Any], *, since: str, triggers: list[dict[str, Any]] | None = None,
           sessions: list[dict[str, Any]] | None = None, run: Runner = _run, now: dt.datetime | None = None) -> dict[str, Any]:
    """One facts file for a tempo reading. `triggers`/`sessions` come from a session holding the sessions port; the rest is read here."""
    ws = manifest["ports"]["coordination"]["workspace"]
    hub = (manifest["ports"]["coordination"] or {}).get("url")
    slug = manifest["org"]["repo"]
    now = now or dt.datetime.now(dt.timezone.utc)
    facts: dict[str, Any] = {
        "kind": "tempo-facts", "org": manifest["org"]["id"], "gathered_at": now.isoformat(timespec="seconds"), "since": since,
        "roles": {r: {"name": e.get("name"), "cadence": e.get("cadence") or _default(r, "cadence"), "runtime": e.get("runtime") or _default(r, "runtime"),
                      "report_key": e.get("report_key") or f"roles/{r}/last-run", "tempo": role_tempo(manifest).get(r),
                      "tolerance": e.get("tolerance", 1.5), "period_hours": e.get("period_hours")}
                  for r, e in manifest["roles"].items() if e.get("enabled", True)},
        "targets": targets(manifest),
        "board": [], "prs": [], "agents": None, "runs": gather_runs(repo), "triggers": triggers or [], "sessions": sessions or [], "could_not_read": [],
        # what a reading needs that is neither the board nor GitHub: which org-core was applied (rows 87, 88), the
        # ceiling the spend is read against, and the repo half of the operator queue
        "repo": slug, "budget": manifest.get("budget") or {}, "lock": _lock_facts(repo),
        "operator_waiting": _operator_waiting(repo, manifest),
        # whether a missing heartbeat is a death: an org that routes no role through an actuator has none to lose
        "actuator_duty": actuator_duty(manifest),
    }
    if not (repo / ".org" / "runs").is_dir():
        # A fire is echoed by the receiver's board record OR by its committed run file, so a reading taken
        # outside the org's checkout judges `fired_no_receiver` from half the evidence and reads the missing
        # half as silence — row 121's lesson, in the actuator tile. An EMPTY `.org/runs` is a real answer
        # (nothing ran); an ABSENT one means this is not the checkout, and that is not an answer.
        facts["could_not_read"].append(f"runs: no {repo}/.org/runs — the git tier of the wake ledger is not "
                                       "in this checkout, so a fire echoed only in a run file reads as unanswered")
    try:
        facts["board"] = gather_board(ws, run, url=hub)
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        facts["could_not_read"].append(f"board: {e}")
    try:
        agent_env = {"SWITCHBOARD_WORKSPACE": ws, **({"SWITCHBOARD_URL": hub} if hub else {})}
        facts["agents"] = json.loads(run(["switchboard", "--json", "agents"], agent_env) or "[]")
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        facts["agents"] = None
        facts["could_not_read"].append(f"agents: {e}")
    try:
        facts["prs"] = gather_prs(slug, since, run)
    except (RuntimeError, json.JSONDecodeError, OSError) as e:
        facts["could_not_read"].append(f"prs: {e}")
    return facts


def merge_facts(files: list[dict[str, Any]]) -> dict[str, Any]:
    """A week from a day's files: board rows by (key, updated_at), PRs by number (latest wins), runs by (role, run_id).
    The board keeps one record per key and overwrites it every wake, so history only exists in gathered files."""
    files = sorted((f for f in files if f), key=lambda f: f.get("gathered_at") or "")
    if not files:
        return {"kind": "tempo-facts", "board": [], "prs": [], "runs": [], "triggers": [], "sessions": [], "roles": {}, "could_not_read": []}
    out = dict(files[-1])
    board: dict[tuple[str, str], dict[str, Any]] = {}
    prs: dict[tuple[str, int], dict[str, Any]] = {}
    runs: dict[tuple[str, str], dict[str, Any]] = {}
    for f in files:
        for row in f.get("board", []):
            board[(row["key"], str(row.get("updated_at")))] = row
        for p in f.get("prs", []):
            k = (p.get("repo", ""), p["number"])
            if k not in prs or str(p.get("updated_at")) >= str(prs[k].get("updated_at")):
                prs[k] = p
        for r in f.get("runs", []):
            runs[(r.get("role", "?"), str(r.get("run_id") or r.get("started_at")))] = r
    out["board"] = sorted(board.values(), key=lambda r: (r["key"], str(r.get("updated_at"))))
    out["prs"] = sorted(prs.values(), key=lambda p: p["number"])
    out["runs"] = list(runs.values())
    out["since"] = min(f.get("since") or "" for f in files) or out.get("since")
    out["merged_from"] = [f.get("gathered_at") for f in files]
    out["could_not_read"] = sorted({c for f in files for c in f.get("could_not_read", [])})
    return out


def latest_facts(repo: Path, n: int = 14) -> dict[str, Any] | None:
    """The committed facts under .org/tempo, merged; None if there are none."""
    d = repo / FACTS_DIR
    if not d.is_dir():
        return None
    files = []
    for p in sorted(d.glob("facts-*.json"))[-n:]:
        try:
            files.append(json.loads(p.read_text()))
        except (OSError, json.JSONDecodeError):
            continue
    return merge_facts(files) if files else None


# --- report -------------------------------------------------------------------

HANDOFF_RE = re.compile(r"^coord/handoffs?/(?P<from>[a-z-]+)-to-(?P<to>[a-z-]+)-(?P<item>.+)$")
ACK_RE = re.compile(r"^coord/handoffs?/(?P<to>[a-z-]+)-ack-(?P<item>.+)$")
ROLE_KEY_RE = re.compile(r"^roles/(?P<role>[a-z-]+)/(?P<rest>.+)$")
HANDOFF_PREFIX_RE = re.compile(r"^coord/handoffs?/")


def _role_prefix(text: str, roles: tuple[str, ...]) -> str | None:
    """The longest known role id that `text` starts with, followed by a hyphen."""
    for r in sorted(roles, key=len, reverse=True):
        if text.startswith(r + "-"):
            return r
    return None


def parse_handoff(key: str, roles: tuple[str, ...] = ROLE_IDS) -> dict[str, str] | None:
    """`coord/handoffs/<from>-to-<to>-<item>` read with the roles known: the receiver is the longest known role id the
    text after `-to-` starts with, else its first word; the sender likewise before the first `-to-` that a known role
    precedes. HANDOFF_RE matched the receiver greedily, so `builder-to-reviewer-stated-appointment-check-cannot-fail`
    read as receiver `reviewer-stated-appointment-check-cannot` and item `fail`: 23 of Lucille's 46 handoff keys on
    2026-09-20 named a receiver no role has, and no ack, record or PR act could ever pair with them (row 105)."""
    if not HANDOFF_PREFIX_RE.match(key):
        return None
    rest = HANDOFF_PREFIX_RE.sub("", key, count=1)
    sender = _role_prefix(rest, roles)
    if sender and rest.startswith(sender + "-to-"):
        after = rest[len(sender) + 4:]
    else:
        head, sep, after = rest.partition("-to-")
        if not sep or not head:
            return None
        sender = head
    to = _role_prefix(after, roles)
    if to is None:
        to, sep, _ = after.partition("-")
        if not sep or not to:
            return None
    item = after[len(to) + 1:]
    if not item:
        return None
    return {"from": sender, "to": to, "item": item}


def _median(xs: list[float | None]) -> float | None:
    ys = sorted(x for x in xs if x is not None)
    if not ys:
        return None
    m = len(ys) // 2
    return round(ys[m] if len(ys) % 2 else (ys[m - 1] + ys[m]) / 2, 2)


def _value(row: dict[str, Any]) -> dict[str, Any]:
    v = row.get("value")
    return v if isinstance(v, dict) else {}


def _record_at(row: dict[str, Any]) -> str | None:
    return _value(row).get("at") or row.get("updated_at")


def _latest_records(board: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """key -> its newest row (merged facts carry several rows per key)."""
    out: dict[str, dict[str, Any]] = {}
    for row in board:
        k = row["key"]
        if k not in out or str(row.get("updated_at")) >= str(out[k].get("updated_at")):
            out[k] = row
    return out


def attribute_prs(prs: list[dict[str, Any]], board: list[dict[str, Any]], runs: list[dict[str, Any]]) -> None:
    """Fill author_role from what the roles themselves recorded (`pr` / `pr_url` in any roles/<role>/* record,
    `artifacts.pr` in a ledger); a PR body signature is the fallback, a branch prefix the last resort.
    A reviewer's record names the PR it reviewed, not one it wrote, so reviewer keys never attribute."""
    by_number: dict[int, str] = {}
    for row in board:
        m = ROLE_KEY_RE.match(row["key"])
        v = _value(row)
        if not m or not v or m["role"] == "reviewer":
            continue
        for field in ("pr", "pr_url", "prs", "url"):
            for num in pr_numbers(v.get(field)):
                by_number.setdefault(num, m["role"])
    for r in runs:
        for num in pr_numbers((r.get("artifacts") or {}).get("pr")):
            by_number.setdefault(num, r.get("role", "unknown"))
    for p in prs:
        if p.get("author_role") in (None, "unknown") and p["number"] in by_number:
            p["author_role"] = by_number[p["number"]]


def merge_board_verdicts(prs: list[dict[str, Any]], board: list[dict[str, Any]]) -> None:
    """A reviewer that records `roles/reviewer/pr-<n>` = {verdict, at} and never comments on the PR still gave a verdict."""
    by_number = {p["number"]: p for p in prs}
    for row in board:
        m = ROLE_KEY_RE.match(row["key"])
        v = _value(row)
        if not m or m["role"] != "reviewer" or not v.get("verdict"):
            continue
        vm = VERDICT_RE.search(str(v["verdict"]))
        nums = pr_numbers(v.get("pr")) or pr_numbers(m["rest"].replace("pr-", "#"))
        at = v.get("at") or row.get("updated_at")
        if not vm or not nums or not at:
            continue
        p = by_number.get(nums[0])
        if not p:
            continue
        if any(x.get("at") == at for x in p.get("verdicts", [])):
            continue
        p.setdefault("verdicts", []).append({"at": at, "verdict": vm.group(1), "sha": (str(v.get("head") or "")[:40] or None), "via": "board"})
        p["verdicts"].sort(key=lambda x: x["at"])
        p["first_verdict_at"], p["first_verdict"] = p["verdicts"][0]["at"], p["verdicts"][0]["verdict"]


def pr_cycle(prs: list[dict[str, Any]], now: dt.datetime) -> dict[str, Any]:
    """Opened → first verdict → merged, per kind and overall; what is open now and for how long."""
    by_kind: dict[str, dict[str, Any]] = {}
    for kind in ("product", "org", "roadmap", "docs", "unknown", "all"):
        rows = [p for p in prs if kind == "all" or p.get("kind") == kind]
        if not rows:
            continue
        merged = [p for p in rows if p.get("merged_at")]
        by_kind[kind] = {
            "opened": len(rows), "merged": len(merged), "open_now": len([p for p in rows if p.get("state") == "open"]),
            "median_hours_open_to_verdict": _median([hours(p["opened_at"], p["first_verdict_at"]) for p in rows if p.get("first_verdict_at")]),
            "median_hours_verdict_to_merge": _median([hours(p["first_verdict_at"], p["merged_at"]) for p in merged if p.get("first_verdict_at")]),
            "median_hours_open_to_merge": _median([hours(p["opened_at"], p["merged_at"]) for p in merged]),
        }
    open_prs = sorted((p for p in prs if p.get("state") == "open" and not p.get("draft")), key=lambda p: p.get("opened_at") or "")
    waiting = [{"number": p["number"], "kind": p.get("kind"), "author_role": p.get("author_role"), "age_hours": hours(p["opened_at"], now.isoformat()),
                "opened_at": p.get("opened_at"), "head_sha": p.get("head_sha"), "updated_at": p.get("updated_at"),
                "verdict": (p.get("verdicts") or [{}])[-1].get("verdict") if p.get("verdicts") else None,
                "verdict_at": p["verdicts"][-1]["at"] if p.get("verdicts") else None,
                "verdict_sha": (p["verdicts"][-1].get("sha") if p.get("verdicts") else None),
                "hours_since_verdict": hours(p["verdicts"][-1]["at"], now.isoformat()) if p.get("verdicts") else None}
               for p in open_prs]
    needing = [{"number": p["number"], "kind": p.get("kind"), "author_role": p.get("author_role"), "why": needs_action(p),
                "idle_hours": hours(p.get("updated_at"), now.isoformat()), "updated_at": p.get("updated_at"), "head_sha": p.get("head_sha")}
               for p in open_prs if needs_action(p)]
    last_merge = max((p["merged_at"] for p in prs if p.get("merged_at")), default=None)
    # The chair's contract is "only on a reviewer's verdict pinned to the head, never on green alone". Lucille 2026-09-20
    # (row 96): 66 of 76 merges since 09-17 carried no verdict at all and check 14 read PASS, because it only ever
    # looked at SOUND PRs still open. A merge with no verdict before it is the chair merging on green.
    merged_all = [p for p in prs if p.get("merged_at")]
    no_verdict = [{"number": p["number"], "kind": p.get("kind"), "merged_at": p["merged_at"], "author_role": p.get("author_role")}
                  for p in merged_all if not any(v.get("at") and v["at"] <= p["merged_at"] for v in (p.get("verdicts") or []))]
    unsound_last = [{"number": p["number"], "kind": p.get("kind"), "merged_at": p["merged_at"]} for p in merged_all
                    if (vs := [v for v in (p.get("verdicts") or []) if v.get("at") and v["at"] <= p["merged_at"]]) and vs[-1].get("verdict") == "UNSOUND"]
    return {"by_kind": by_kind, "open": waiting, "needing_action": needing, "last_merge_at": last_merge, "hours_since_last_merge": hours(last_merge, now.isoformat()) if last_merge else None,
            "merged": len(merged_all), "merged_without_verdict": no_verdict, "merged_on_unsound": unsound_last}


ITEM_PR_RE = re.compile(r"^pr-?(\d{1,6})$")


def _handoff_prs(value: dict[str, Any] | None, item: str) -> list[int]:
    """The PRs a handoff names: `pr` / `url` / `prs` / `pr_url` in its value, else an item spelled `pr1599`."""
    nums: list[int] = []
    for field in ("pr", "url", "prs", "pr_url"):
        nums += pr_numbers((value or {}).get(field))
    m = ITEM_PR_RE.match(item)
    if m:
        nums.append(int(m.group(1)))
    return sorted(set(nums))


def _received_on_pr(to: str, written: str, prs_by_number: dict[int, dict[str, Any]], nums: list[int]) -> tuple[str | None, str | None]:
    """The first thing the receiver did on a named PR after the handoff was written: a verdict (reviewer), a merge
    (ceo), or a comment by that role. Lucille 2026-09-20: 37 handoffs stood NOT RECEIVED while every PR they named was
    reviewed or merged — the receiver acted on the PR and wrote no ack key, and the truest signal went unread."""
    best: tuple[str, str] | None = None
    for n in nums:
        p = prs_by_number.get(n)
        if not p:
            continue
        cands: list[tuple[str, str]] = []
        if to == "reviewer":
            cands += [(v["at"], f"PR #{n}: verdict {v.get('verdict')}") for v in (p.get("verdicts") or []) if v.get("at")]
        if to == "ceo" and p.get("merged_at"):
            cands.append((p["merged_at"], f"PR #{n}: merged"))
        cands += [(c["at"], f"PR #{n}: comment by {to}") for c in (p.get("comments") or []) if c.get("at") and c.get("role") == to]
        for at, via in cands:
            if _ts(at) >= _ts(written) and (best is None or _ts(at) < _ts(best[0])):
                best = (at, via)
    return (best[0], best[1]) if best else (None, None)


def _ts(s: Any) -> dt.datetime:
    return parse_ts(s) or dt.datetime.min.replace(tzinfo=dt.timezone.utc)


def _overtaken_on_pr(written: str, prs_by_number: dict[int, dict[str, Any]], nums: list[int]) -> tuple[str | None, str | None, str | None]:
    """(closed_at, why, pr_state) when every PR a handoff names is closed and the receiver never acted on it: the wait
    is over, not by receipt. Lucille 2026-09-20 14:26Z: all 37 handoffs still unreceived after the PR path named a
    merged PR with no verdict — 17 merged after the builder's handoff to the reviewer, 20 written by the chair after
    its own merge (`ceo-to-reviewer-pr<n>`, "no verdict yet") to a role nothing wakes for a closed PR."""
    named = [prs_by_number[n] for n in nums if n in prs_by_number]
    if not named:
        return None, None, None
    if any(p.get("state") == "open" and not p.get("merged_at") for p in named):
        return None, None, "open"
    last = max(named, key=lambda p: _ts(p.get("merged_at") or p.get("closed_at")))
    at = last.get("merged_at") or last.get("closed_at")
    if not at:
        return None, None, "closed"
    n = last["number"]
    if last.get("merged_at"):
        why = f"PR #{n} merged before the handoff was written" if _ts(at) < _ts(written) else f"PR #{n} merged with no act by the receiver"
    else:
        why = f"PR #{n} closed unmerged"
    return at, why, "closed"


def handoff_edges(board: list[dict[str, Any]], now: dt.datetime, prs: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """coord/handoffs/<from>-to-<to>-<item> paired with <to>-ack-<item>, with the receiver's record naming the key, or
    with the receiver's own act on the PR the handoff names (verdict, merge, comment); else never received."""
    latest = _latest_records(board)
    prs_by_number = {p["number"]: p for p in (prs or []) if isinstance(p.get("number"), int)}
    acks: dict[tuple[str, str], str] = {}
    records: dict[str, list[dict[str, Any]]] = {}
    for row in board:
        m = ACK_RE.match(row["key"])
        if m:
            acks[(m["to"], m["item"])] = _min_ts(acks.get((m["to"], m["item"])), _record_at(row))
        m2 = ROLE_KEY_RE.match(row["key"])
        if m2:
            records.setdefault(m2["role"], []).append(row)
    edges = []
    for key, row in sorted(latest.items()):
        m = parse_handoff(key)
        if not m:
            continue
        written = min((_record_at(r) or "" for r in board if r["key"] == key), default=_record_at(row)) or _record_at(row)
        received = acks.get((m["to"], m["item"]))
        via = "ack key" if received else None
        if not received:
            for rec in sorted(records.get(m["to"], []), key=lambda r: str(r.get("updated_at"))):
                v = _value(rec)
                at = v.get("at") or rec.get("updated_at")
                if v and (key in json.dumps(v) or m["item"] in json.dumps(v)) and (parse_ts(at) or dt.datetime.min.replace(tzinfo=dt.timezone.utc)) >= (parse_ts(written) or dt.datetime.min.replace(tzinfo=dt.timezone.utc)):
                    received, via = at, "receiver's record"
                    break
        nums = _handoff_prs(_value(row), m["item"])
        overtaken, pr_state = None, None
        if not received and prs_by_number:
            received, via = _received_on_pr(m["to"], written or "", prs_by_number, nums)
            if not received:
                overtaken, via, pr_state = _overtaken_on_pr(written or "", prs_by_number, nums)
        waiting = None if received else (max(0.0, hours(written, overtaken) or 0.0) if overtaken else hours(written, now.isoformat()))
        edges.append({"key": key, "from": m["from"], "to": m["to"], "item": m["item"], "written_at": written,
                      "received_at": received, "overtaken_at": overtaken, "pr_state": pr_state, "via": via, "prs": nums,
                      "latency_hours": hours(written, received) if received else None,
                      "waiting_hours": waiting})
    return edges


def _item_names(v: dict[str, Any], field: str) -> list[str]:
    """Item keys a verifier record names under `<field>_items`, or under `<field>` when that is a list. The record
    schema declares `confirmed`/`refuted` as COUNTS, and this function iterated them as lists: the first run in which
    Vera confirmed anything (Lucille 2026-09-20 06:56Z, confirmed=5 refuted=1) raised TypeError inside `tp.report`,
    and both Docs' full `org doctor` runs produced a traceback and zero checks (row 94). A count carries no names."""
    for key in (f"{field}_items", field):
        val = v.get(key)
        if isinstance(val, list):
            return [x for x in val if isinstance(x, str) and x]
    return []


def _as_list(val: Any) -> list[Any]:
    """A record field read as a list whatever a role wrote there: Lucille's dispatcher wrote
    `spawned: "0 builders, 1 reviewer (pr-1616)"` (2026-09-20 09:26Z) and `list + str` crashed the whole report (row 95)."""
    if isinstance(val, list):
        return val
    if isinstance(val, dict):
        return [val]
    return []


def _stamp_from_record(items: dict[str, dict[str, Any]], role: str, v: dict[str, Any], at: Any) -> None:
    def it(name: str) -> dict[str, Any]:
        return items.setdefault(name, {"item": name})
    if role == "verifier":
        for name in _item_names(v, "refuted"):
            it(name)["refuted_at"] = _min_ts(it(name).get("refuted_at"), at)
        for name in _item_names(v, "confirmed"):
            it(name)["verified_at"] = _min_ts(it(name).get("verified_at"), at)
    elif role == "dispatcher":
        for s in _as_list(v.get("spawned")) + _as_list(v.get("spawned_builders")):
            name = s.get("item") if isinstance(s, dict) else (s if isinstance(s, str) else None)
            if name:
                it(name)["dispatched_at"] = _min_ts(it(name).get("dispatched_at"), at)
    elif role == "builder":
        name = v.get("item")
        if isinstance(name, str) and name:
            row_i = it(name)
            row_i["builder_at"] = _min_ts(row_i.get("builder_at"), at)
            nums = pr_numbers(v.get("pr")) or pr_numbers(v.get("pr_url"))
            if nums and not row_i.get("pr"):
                row_i["pr"] = nums[0]


def item_flow(board: list[dict[str, Any]], prs: list[dict[str, Any]], now: dt.datetime) -> dict[str, Any]:
    """The chain an item travels, stamped where each role recorded it: the verifier's `refuted_items`, the dispatcher's
    `spawned[].item`, the builder's `item`+`pr`, the PR's own timestamps, the verifier's `confirmed_items`. One record
    a role wrote in an unexpected shape is skipped and NAMED in `unreadable` — never a crash that takes the report with
    it (rows 94, 95: two shapes in two days, each aborting every check that reads the board)."""
    items: dict[str, dict[str, Any]] = {}
    unreadable: list[str] = []

    for row in sorted(board, key=lambda r: str(r.get("updated_at"))):
        m = ROLE_KEY_RE.match(str(row.get("key") or ""))
        v = _value(row)
        if not m or not isinstance(v, dict):
            continue
        at = v.get("at") or row.get("updated_at")
        try:
            _stamp_from_record(items, m["role"], v, at)
        except Exception as e:  # noqa: BLE001 — the record is the org's writing; the report says which one it could not read
            unreadable.append(f"{row.get('key')}: {type(e).__name__}: {str(e)[:80]}")
    by_number = {p["number"]: p for p in prs}
    for name, row in items.items():
        pr = by_number.get(row.get("pr")) if row.get("pr") else None
        if pr is None:
            pr = next((p for p in prs if name and (name in (p.get("head_ref") or "") or name in (p.get("title") or ""))), None)
        if pr:
            row.update({"pr": pr["number"], "pr_opened_at": pr.get("opened_at"), "verdict_at": pr.get("first_verdict_at"),
                        "verdict": pr.get("first_verdict"), "merged_at": pr.get("merged_at")})
    edge_defs = [("finding_to_dispatch", "refuted_at", "dispatched_at"), ("dispatch_to_pr", "dispatched_at", "pr_opened_at"),
                 ("open_to_verdict", "pr_opened_at", "verdict_at"), ("verdict_to_merge", "verdict_at", "merged_at"),
                 ("merge_to_verified", "merged_at", "verified_at")]
    edges: dict[str, dict[str, Any]] = {}
    for name, a, b in edge_defs:
        done = [hours(r[a], r[b]) for r in items.values() if r.get(a) and r.get(b)]
        waiting = [(r["item"], hours(r[a], now.isoformat())) for r in items.values() if r.get(a) and not r.get(b)]
        worst = max(waiting, key=lambda x: x[1] or 0, default=None)
        edges[name] = {"n": len(done), "median_hours": _median(done), "waiting": len(waiting),
                       "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    # open_to_verdict / verdict_to_merge are better measured over every PR, not only the ones an item names.
    # verdict_to_merge is the CEO's edge: from the latest SOUND verdict to the merge. A PR whose latest verdict is
    # UNSOUND waits on its builder, not on a merge — that is `unsound_open`.
    def latest_sound(p: dict[str, Any]) -> str | None:
        vs = [v["at"] for v in p.get("verdicts", []) if v.get("verdict") == "SOUND" and v.get("at")]
        return max(vs) if vs else None

    def latest_verdict(p: dict[str, Any]) -> str | None:
        return (p.get("verdicts") or [{}])[-1].get("verdict") if p.get("verdicts") else None

    open_prs = [p for p in prs if p.get("state") == "open" and not p.get("draft")]
    done = [hours(p["opened_at"], p["first_verdict_at"]) for p in prs if p.get("opened_at") and p.get("first_verdict_at")]
    waiting = [(f"#{p['number']}", hours(p["opened_at"], now.isoformat())) for p in open_prs if p.get("opened_at") and not p.get("first_verdict_at")]
    worst = max(waiting, key=lambda x: x[1] or 0, default=None)
    edges["open_to_verdict"] = {"n": len(done), "median_hours": _median(done), "waiting": len(waiting),
                               "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    done = [hours(latest_sound(p), p["merged_at"]) for p in prs if p.get("merged_at") and latest_sound(p) and latest_sound(p) <= p["merged_at"]]
    waiting = [(f"#{p['number']}", hours(latest_sound(p), now.isoformat())) for p in open_prs if latest_verdict(p) == "SOUND"]
    worst = max(waiting, key=lambda x: x[1] or 0, default=None)
    edges["verdict_to_merge"] = {"n": len(done), "median_hours": _median(done), "waiting": len(waiting),
                                "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    waiting = [(f"#{p['number']}", hours(p["verdicts"][-1]["at"], now.isoformat())) for p in open_prs if latest_verdict(p) == "UNSOUND"]
    worst = max(waiting, key=lambda x: x[1] or 0, default=None)
    edges["unsound_open"] = {"n": 0, "median_hours": None, "waiting": len(waiting),
                            "worst_waiting_item": worst[0] if worst else None, "worst_waiting_hours": worst[1] if worst else None}
    return {"items": sorted(items.values(), key=lambda r: r["item"]), "edges": edges, "unreadable": unreadable}


#: a bare `no\b` here read "No production credential path for this routine" as *not a blocker* — the reading
#: lying in the reassuring direction, on a role that had been blocked four days (Lucille's doctor, 2026-09-22).
#: "No" is an answer to "are you blocked?" only when it ends there, or names the absence of one.
NOT_BLOCKED_RE = re.compile(
    r"^\s*(?:nothing blocks|nothing is blocking|none\b|n/a\b|nil\b|—|-|null\b|false\b"
    r"|no(?:\s*[.!,;)]|\s*$|\s+(?:blockers?|blocks?|blocking\b|issues?|problems?|concerns?)\b))", re.I)


def is_blocked(text: Any) -> bool:
    """A `blocked` field is a blocker when it is non-empty and does not open by saying it is not one — roles write
    "Nothing blocks me. TWO things need someone else…" in prose, and forwarding that as a blocker is noise."""
    if not text or isinstance(text, bool) and not text:
        return False
    return not NOT_BLOCKED_RE.match(str(text))


def _cut(text: Any, n: int = 200) -> str:
    """A blocker, cut where a reader can see it was cut. Lucille 2026-09-22: three blocked lines ended `Bu`,
    `0` and `MECHA` — a bare truncation reads as a broken writer, not as a long field."""
    t = str(text)
    return t if len(t) <= n else t[:n] + "…"


def blocked_now(board: list[dict[str, Any]], roles: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    latest = _latest_records(board)
    out = []
    for role, meta in roles.items():
        key = meta.get("report_key") or f"roles/{role}/last-run"
        row = latest.get(key)
        v = _value(row) if row else {}
        if not v:
            out.append({"role": role, "record": None})
            continue
        b = v.get("blocked")
        out.append({"role": role, "record_at": v.get("at") or row.get("updated_at"), "record_age_hours": hours(v.get("at") or row.get("updated_at"), now.isoformat()),
                    "blocked": (_cut(b) if is_blocked(b) else None), "blocked_text": (_cut(b) if b else None)})
    return out


def _triggers_by_role(facts: dict[str, Any]) -> dict[str, dict[str, Any]]:
    from .doctor import _trigger_for
    org = facts.get("org", "")
    out: dict[str, dict[str, Any]] = {}
    for role, meta in facts.get("roles", {}).items():
        t = _trigger_for(role, str(meta.get("name") or role), facts.get("triggers", []), org)
        if t is not None:
            out[role] = t
    return out


def wake_stats(facts: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """What can be seen of each role's wakes: the board's records, the run ledger, the routine's last fire."""
    out = []
    runs_by_role: dict[str, list[dict[str, Any]]] = {}
    for r in facts.get("runs", []):
        runs_by_role.setdefault(r.get("role", "?"), []).append(r)
    trig_by_role = _triggers_by_role(facts)
    records_seen: dict[str, set[str]] = {}
    for row in facts.get("board", []):
        m = ROLE_KEY_RE.match(row["key"])
        if m and m["rest"] == "last-run" or (m and (facts.get("roles", {}).get(m["role"]) or {}).get("report_key") == row["key"]):
            records_seen.setdefault(m["role"], set()).add(str(_record_at(row)))
    for role, meta in facts.get("roles", {}).items():
        t = trig_by_role.get(role) or {}
        last = t.get("last_run") or {}
        runs = runs_by_role.get(role, [])
        out.append({
            "role": role, "cadence": meta.get("cadence"), "runtime": meta.get("runtime") or t.get("runtime"),
            "last_fired_at": last.get("fired_at") or t.get("last_fired_at"), "last_finished_at": last.get("finished_at"),
            "last_run_minutes": (hours(last.get("fired_at"), last.get("finished_at")) or 0) * 60 if last.get("fired_at") and last.get("finished_at") else None,
            "records_seen": len(records_seen.get(role, ())), "ledger_runs": len(runs),
            "ledger_empty": sum(1 for r in runs if r.get("outcome") == "ran_empty"),
            "ledger_last": max((r.get("ended_at") or r.get("started_at") or "" for r in runs), default=None),
            "tempo": meta.get("tempo"),
        })
    return out


def _last_fire(role: str, facts: dict[str, Any], latest: dict[str, dict[str, Any]]) -> str | None:
    t = _triggers_by_role(facts).get(role) or {}
    fired = (t.get("last_run") or {}).get("fired_at")
    key = (facts.get("roles", {}).get(role) or {}).get("report_key") or f"roles/{role}/last-run"
    rec = latest.get(key)
    rec_at = _record_at(rec) if rec else None
    return max((x for x in (fired, rec_at) if x), default=None)


def wake_now(facts: dict[str, Any], now: dt.datetime, *, cycle: dict[str, Any] | None = None, edges: list[dict[str, Any]] | None = None,
             flow: dict[str, Any] | None = None, requested: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    """The variable half. For each role with `tempo.wake_on`: the events waiting on it longer than its target, and
    whether a port holder should fire it now (or hold, because it fired within `min_interval_hours`). `requested` are the
    routed DMs in the actuator's inbox (`requests_from_inbox`): an event they name counts whatever its age, and a role with
    a requested event fires regardless of its minimum interval — the sender asked now."""
    board, prs = facts.get("board", []), facts.get("prs", [])
    latest = _latest_records(board)
    cycle = cycle or pr_cycle(prs, now)
    edges = edges if edges is not None else handoff_edges(board, now, prs)
    flow = flow or item_flow(board, prs, now)
    out: list[dict[str, Any]] = []
    for role, meta in facts.get("roles", {}).items():
        cfg = meta.get("tempo") or DEFAULT_ROLE_TEMPO.get(role)
        if not cfg or not cfg.get("wake_on"):
            continue
        target = float(cfg.get("target_hours", 2))
        asked = {str(r.get("what")) for r in (requested or []) if r.get("role") == role}

        def past(what: str, waited: float | None) -> bool:
            return what in asked or (waited or 0) >= target

        events: list[dict[str, Any]] = []
        for ev in cfg["wake_on"]:
            if ev == "pr_opened":
                events += [{"event": ev, "what": f"#{p['number']}", "waiting_hours": p["age_hours"], "event_at": p.get("opened_at")}
                           for p in cycle["open"] if not p.get("verdict") and past(f"#{p['number']}", p["age_hours"])]
            elif ev == "correction_pushed":
                for p in cycle["open"]:
                    sha, head = p.get("verdict_sha"), p.get("head_sha")
                    if p.get("verdict") and sha and head and not head.startswith(sha) and not sha.startswith(head):
                        w = hours(p.get("updated_at"), now.isoformat())
                        if past(f"#{p['number']}", w):
                            events.append({"event": ev, "what": f"#{p['number']}", "waiting_hours": w, "event_at": p.get("updated_at"),
                                           "scope": f"pinned confirmation {sha[:7]}→{head[:7]}"})
            elif ev == "verdict_sound":
                events += [{"event": ev, "what": f"#{p['number']}", "waiting_hours": p["hours_since_verdict"], "event_at": p.get("verdict_at")}
                           for p in cycle["open"] if p.get("verdict") == "SOUND" and past(f"#{p['number']}", p["hours_since_verdict"])
                           and (not p.get("verdict_sha") or not p.get("head_sha") or p["head_sha"].startswith(p["verdict_sha"]) or p["verdict_sha"].startswith(p["head_sha"]))]
            elif ev == "handoff_written":
                events += [{"event": ev, "what": e["key"], "waiting_hours": e["waiting_hours"], "event_at": e["written_at"]}
                           for e in edges if e["to"] == role and not e["received_at"] and not e.get("overtaken_at") and past(e["key"], e["waiting_hours"])]
            elif ev == "finding_refuted":
                events += [{"event": ev, "what": r["item"], "waiting_hours": hours(r["refuted_at"], now.isoformat()), "event_at": r["refuted_at"]}
                           for r in flow["items"] if r.get("refuted_at") and not r.get("dispatched_at") and not r.get("pr")
                           and past(r["item"], hours(r["refuted_at"], now.isoformat()))]
        if not events:
            continue
        for e in events:
            if e["what"] in asked:
                e["requested"] = True
        last = _last_fire(role, facts, latest)
        since = hours(last, now.isoformat()) if last else None
        min_h = float(cfg.get("min_interval_hours", 1))
        t = _triggers_by_role(facts).get(role) or {}
        rec = latest.get(meta.get("report_key") or f"roles/{role}/last-run")
        blocked = _value(rec).get("blocked") if rec else None
        row = {"role": role, "events": sorted(events, key=lambda e: -(e["waiting_hours"] or 0)), "target_hours": target,
               "last_fire_at": last, "hours_since_last_fire": since, "min_interval_hours": min_h, "trigger": t.get("id"),
               "blocked": str(blocked)[:160] if blocked else None}
        if any(e.get("requested") for e in events):
            row["fire"] = True
            row["why"] = "requested by DM: " + ", ".join(e["what"] for e in events if e.get("requested")) + (
                f"; {sum(1 for e in events if not e.get('requested'))} more past the {target}h target" if any(not e.get("requested") for e in events) else "")
        elif since is not None and min_h > 0 and since < min_h:
            row["fire"] = False
            row["why"] = f"hold: fired {since}h ago, min interval {min_h}h"
        else:
            row["fire"] = True
            row["why"] = f"{len(events)} event(s) past the {target}h target; " + ("never seen firing" if since is None else f"last fire {since}h ago")
        out.append(row)
    return out


def handoff_unreachable(e: dict[str, Any], roles: dict[str, Any] | None, listening: set[str] | None) -> str:
    """Why nobody will ever read this handoff key, or `""` when somebody will. The receiver wakes on no
    `handoff_written`, has no listener parked, and the key names no open PR that would spawn it — so the
    difference between "late" and "addressed to nobody" is a sentence, not a guess. `roles` None means the
    roster was not read at all, and an unread roster decides nothing (row 65)."""
    if roles is None:
        return ""
    cfg = (roles.get(e["to"]) or {}).get("tempo") or DEFAULT_ROLE_TEMPO.get(e["to"]) or {}
    wake_on = list(cfg.get("wake_on") or [])
    if "handoff_written" in wake_on or e["to"] in (listening or set()) or e.get("pr_state") == "open":
        return ""
    return f"{e['to']} wakes on {', '.join(wake_on) or 'nothing'} and is not listening; nobody reads this key"


def slow_edges(flow: dict[str, Any], tgt: dict[str, float], edges: list[dict[str, Any]], roles: dict[str, Any] | None = None,
               listening: set[str] | None = None) -> list[str]:
    """SLOW / WAITING per edge; per unreceived handoff WAITING, or UNREACHABLE when the receiver wakes on no
    `handoff_written`, is not listening, and the handoff names no open PR that would spawn it — nobody reads that key.
    Overtaken handoffs are one aggregated line, not one alarm each (row 100's lesson)."""
    out = []
    for name, e in flow["edges"].items():
        t = tgt.get(name)
        if t is None:
            continue
        if e["median_hours"] is not None and e["median_hours"] > t:
            out.append(f"SLOW {name}: median {e['median_hours']}h over {e['n']} (target {t}h)")
        if e["worst_waiting_hours"] is not None and e["worst_waiting_hours"] > t:
            out.append(f"WAITING {name}: {e['worst_waiting_item']} for {e['worst_waiting_hours']}h (target {t}h), {e['waiting']} waiting")
    t = tgt.get("handoff_received")
    for e in edges:
        if e["received_at"] or e.get("overtaken_at") or t is None or (e["waiting_hours"] or 0) <= t:
            continue
        if e.get("unjudged_why"):   # a receipt nobody could look for is not a receipt that did not happen (row 65)
            continue
        why = handoff_unreachable(e, roles, listening)
        if why:
            out.append(f"UNREACHABLE handoff_received: {e['from']} → {e['to']} [{e['item']}] for {e['waiting_hours']}h — {why}")
        else:
            out.append(f"WAITING handoff_received: {e['from']} → {e['to']} [{e['item']}] for {e['waiting_hours']}h (target {t}h)")
    over = [e for e in edges if e.get("overtaken_at")]
    if over:
        before = sum(1 for e in over if "before the handoff" in (e.get("via") or ""))
        out.append(f"OVERTAKEN handoff_received: {len(over)} handoff(s) whose PR closed with no act by the receiver — "
                   f"{len(over) - before} closed after the handoff, {before} written after the merge")
    return out


def report(facts: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    now = now or dt.datetime.now(dt.timezone.utc)
    board, prs = facts.get("board", []), facts.get("prs", [])
    attribute_prs(prs, board, facts.get("runs", []))
    merge_board_verdicts(prs, board)
    edges = handoff_edges(board, now, prs)
    # Row 105: the receiver's act on the PR the handoff names is the truest signal of receipt, and 37 handoffs
    # stood NOT RECEIVED while every PR they named was reviewed. So when the PR half is UNREAD, a PR-named
    # handoff cannot be judged at all — with `prs` empty every one of them falls through to "never received",
    # which is row 65 wearing the handoffs tile. Measured on Lucille 2026-09-22: a `gh` 403 turned 62 of 70
    # handoff keys into 50 findings about receipts nobody had looked for.
    prs_unread = next((c for c in facts.get("could_not_read", []) if c.startswith("prs:")), "")
    for e in edges:
        e["unjudged_why"] = (f"it names {', '.join('#%d' % n for n in e['prs'])} and the PR half of receipt was "
                             f"not read — {prs_unread}"
                             if prs_unread and e["prs"] and not e["received_at"] and not e.get("overtaken_at") else "")
    cycle = pr_cycle(prs, now)
    flow = item_flow(board, prs, now)
    tgt = dict(DEFAULT_TARGETS)
    tgt.update(facts.get("targets") or {})
    lst = listeners(facts, now)
    from . import actuator as ac
    acfg = ac.org_tempo({"tempo": facts.get("tempo_cfg") or {}})
    ledger = ac.ledger_rows(board, acfg)
    hb = ac.heartbeat(board, acfg)
    actuator = {
        "heartbeat": hb, "heartbeat_age_hours": hours(hb.get("at"), now.isoformat()) if hb else None,
        "wakes": len(ledger), "wakes_idle": sum(1 for r in ledger if r.get("idle")),
        "spawns": sum(1 for r in ledger for f in r.get("fired", []) if f.get("kind") == "spawn" and not f.get("could_not")),
        "fires": sum(1 for r in ledger for f in r.get("fired", []) if f.get("kind") == "fire_trigger" and not f.get("could_not")),
        "refused": sum(1 for r in ledger for f in r.get("fired", []) if f.get("could_not")),
        "cost_per_wake": ac.wake_cost_series(board, acfg)[-12:],
        "orphans": {k: v for k, v in ac.orphans(facts, now, acfg).items() if k != "losses"},
    }
    return {
        "listeners": lst,
        "actuator": actuator,
        "org": facts.get("org"), "at": now.isoformat(timespec="seconds"), "facts_gathered_at": facts.get("gathered_at"), "since": facts.get("since"),
        "merged_from": facts.get("merged_from"),
        "cycle": cycle, "edges": flow["edges"], "items": flow["items"], "targets": tgt,
        "slow": slow_edges(flow, tgt, edges, roles=facts.get("roles", {}), listening={l["role"] for l in lst if l.get("listening")}),
        "handoffs": edges, "handoffs_unreceived": [dict(e, unreachable_why=handoff_unreachable(e, facts.get("roles"), {l["role"] for l in lst if l.get("listening")}))
                                                   for e in edges if not e["received_at"] and not e.get("overtaken_at")],
        "handoffs_overtaken": [e for e in edges if e.get("overtaken_at")],
        "blocked": blocked_now(board, facts.get("roles", {}), now),
        "wakes": wake_stats(facts, now),
        "wake_now": wake_now(facts, now, cycle=cycle, edges=edges, flow=flow),
        "could_not_read": list(facts.get("could_not_read", [])) + [f"record {u} — skipped, not crashed (rows 94, 95)" for u in flow.get("unreadable", [])],
    }


def render(rep: dict[str, Any]) -> str:
    L = [f"tempo — {rep['org']} at {rep['at']} (facts {rep.get('facts_gathered_at')}, since {rep.get('since')}" + (f", merged from {len(rep['merged_from'])} files" if rep.get("merged_from") else "") + ")", ""]
    L.append("edges: median hours, and the worst thing waiting now (target)")
    for name, e in rep["edges"].items():
        t = rep["targets"].get(name)
        L.append(f"  {name:<20} n {e['n']:>3} median {str(e['median_hours']):>7}h  waiting {e['waiting']:>3}" + (f"  worst {e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e["worst_waiting_item"] else "") + (f"  (target {t}h)" if t is not None else ""))
    for s in rep["slow"]:
        L.append(f"  {s}")
    L.append("")
    c = rep["cycle"]
    L.append("pull requests: opened → verdict → merged, median hours")
    for kind, k in c["by_kind"].items():
        L.append(f"  {kind:<8} opened {k['opened']:>3} merged {k['merged']:>3} open now {k['open_now']:>3}  open→verdict {k['median_hours_open_to_verdict']}  verdict→merge {k['median_hours_verdict_to_merge']}  open→merge {k['median_hours_open_to_merge']}")
    L.append(f"  last merge {c['last_merge_at']} — {c['hours_since_last_merge']}h ago")
    if c["open"]:
        L.append("  open now: " + ", ".join(f"#{p['number']} {p['kind']} {p['author_role']} {p['age_hours']}h" + (f" ({p['verdict']} {p['hours_since_verdict']}h ago)" if p.get('verdict') else "") for p in c["open"]))
    for p in c.get("needing_action") or []:
        L.append(f"  needing action: #{p['number']} ({'; '.join(p['why'])}) idle {p['idle_hours']}h" + (f"  (target {rep['targets'].get('pr_needing_action')}h)" if rep["targets"].get("pr_needing_action") is not None else ""))
    L.append("")
    L.append("handoffs (coord/handoffs/*)")
    for e in rep["handoffs"]:
        L.append(f"  {e['from']} → {e['to']} [{e['item']}] written {e['written_at']} " + (f"received {e['received_at']} via {e['via']} — {e['latency_hours']}h" if e['received_at'] else (f"OVERTAKEN — {e['via']} at {e['overtaken_at']}, {e['waiting_hours']}h after" if e.get('overtaken_at') else f"NOT RECEIVED — waiting {e['waiting_hours']}h")))
    if not rep["handoffs"]:
        L.append("  none on the board")
    L.append("")
    L.append("blocked fields now")
    for b in rep["blocked"]:
        L.append(f"  {b['role']:<16} " + ("no record" if not b.get("record_at") and b.get("record") is None else f"record {b['record_at']} ({b['record_age_hours']}h) blocked: {b['blocked'] or '—'}"))
    L.append("")
    L.append("wakes")
    for w in rep["wakes"]:
        L.append(f"  {w['role']:<16} {str(w['cadence']):<14} {str(w['runtime']):<8} last fire {w['last_fired_at']} run {w['last_run_minutes'] and round(w['last_run_minutes'])} min  records seen {w['records_seen']}  ledger {w['ledger_runs']} runs ({w['ledger_empty']} empty)")
    L.append("")
    L.append("listeners (persistent roles: registered in coord/tempo/agents, and on the roster now)")
    for l in rep.get("listeners") or []:
        L.append(f"  {l['role']:<16} " + (f"{l['agent_id']} " + ("LISTENING" if l["listening"] else ("not on the roster" if l["roster_read"] else "roster unread")) + f" — registered {l['registered_age_hours']}h ago, parked until {l['listen_until']}" if l.get("agent_id") else "never registered — no `org tempo register` from its session yet"))
    if not rep.get("listeners"):
        L.append("  no persistent roles declared")
    L.append("")
    a = rep.get("actuator") or {}
    L.append("actuator (coord/tempo/*)")
    if a.get("heartbeat"):
        L.append(f"  heartbeat {a['heartbeat'].get('at')} ({a['heartbeat_age_hours']}h ago) next wake {a['heartbeat'].get('next_wake_at')} session {a['heartbeat'].get('session_id')} {a['heartbeat'].get('context_tokens')} tokens")
        L.append(f"  wakes {a['wakes']} ({a['wakes_idle']} idle), spawns {a['spawns']}, fires {a['fires']}, refused {a['refused']}; $/wake " + ", ".join(f"{c['usd']}" for c in a["cost_per_wake"][-8:]))
        for k in ("fired_no_receiver", "suppressed", "unforwarded"):
            if a["orphans"].get(k):
                L.append(f"  {k}: {json.dumps(a['orphans'][k], ensure_ascii=False)[:240]}")
    else:
        L.append("  no heartbeat — no actuator has written coord/tempo/actuator yet (the dispatcher's routine prompt carries the four-call wake once it is updated)")
    L.append("")
    L.append("wake now (roles a port holder should fire before their next cron tick)")
    for w in rep["wake_now"]:
        L.append(f"  {'FIRE' if w['fire'] else 'HOLD'} {w['role']:<16} {w['why']}" + (f" — trigger {w['trigger']}" if w.get("trigger") else "") + (f" — its record says blocked: {w['blocked']}" if w.get("blocked") else ""))
        for e in w["events"][:5]:
            L.append(f"       {e['event']:<16} {e['what']} waiting {e['waiting_hours']}h")
    if not rep["wake_now"]:
        L.append("  nothing past target")
    if rep["could_not_read"]:
        L.append("")
        L.append("could not read: " + "; ".join(rep["could_not_read"]))
    return "\n".join(L) + "\n"
