"""The `org` command."""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import subprocess
import sys
from pathlib import Path

from . import __version__
from .apply import ApplyRefused, apply_plan
from .detect import detect, draft_manifest, dump_manifest
from .doctor import Ctx, exit_code, render_text, run, to_json
from .manifest import ManifestError, enabled_roles, flat_vars, layer, read, unfilled, validate
from .plan import make_plan
from .record import from_doctor, validate as validate_record
from .roles import defaults_by_role, discover
from .routine import render_text as routine_text, spec as routine_spec
from .verify import exit_code as verify_exit, render_text as verify_text, run_verify, summarize as verify_summary
from .vendor import HOOK_SNIPPET, unreleased, vendor, vendored_wheel

NOT_YET = {
    "knob": "P2.1 — SPEC §10",
    "report": "P4 — SPEC §11, the fleet",
}


def _load(manifest_path: Path):
    packages = discover()
    manifest = layer(read(manifest_path), defaults_by_role(packages))
    return manifest, packages


def cmd_roles(args) -> int:
    packages = discover()
    for rid, pkg in packages.items():
        c = pkg.contract
        print(f"{rid:<16} {c.get('display','?'):<8} v{pkg.version:<6} runtime={c.get('runtime',{}).get('default','?'):<8} cadence={c.get('cadence',{}).get('default','-'):<14} addenda={','.join(pkg.addenda) or '-'}")
    return 0


def cmd_validate(args) -> int:
    import yaml

    data = yaml.safe_load(Path(args.manifest).read_text())
    problems = validate(data)
    if problems:
        print("\n".join(problems))
        return 1
    packages = discover()
    m = layer(data, defaults_by_role(packages))
    missing = [r for r in enabled_roles(m) if r not in packages]
    if missing:
        print("enabled roles with no package: " + ", ".join(missing))
        return 1
    from .suite import suite_of
    suite = suite_of(m)
    if suite.problems:
        print("\n".join(suite.problems))
        return 1
    print(f"ok — {len(enabled_roles(m))} roles enabled, manifest_version {m['manifest_version']}; suite: " + ", ".join(f"{n} ({c['policy']})" for n, c in suite.enabled().items()))
    return 0


def cmd_render(args) -> int:
    from .plan import _render_role

    manifest, packages = _load(Path(args.manifest))
    if args.role not in packages:
        print(f"no such role: {args.role}")
        return 1
    fm, body, _ = _render_role(manifest, args.role, packages[args.role], args.kind, flat_vars(manifest))
    sys.stdout.write(fm + body)
    return 0


def _plan(args):
    manifest_path = Path(args.manifest)
    manifest, packages = _load(manifest_path)
    repo = Path(args.repo).resolve()
    project_from = Path(args.project_from).resolve() if getattr(args, "project_from", None) else None
    plan = make_plan(repo, manifest, packages, manifest_source=manifest_path,
                     adopt_existing=bool(getattr(args, "adopt_existing", False)), project_from=project_from)
    return repo, manifest, packages, plan


def cmd_plan(args) -> int:
    repo, manifest, packages, plan = _plan(args)
    if args.json:
        print(json.dumps({
            "repo": str(repo), "org": manifest["org"]["id"], "org_core": __version__,
            "worst": plan.worst, "by_status": plan.by_status(),
            "files": [{"path": a.path, "role": a.role, "kind": a.kind, "status": a.status, "detail": a.detail, "diff_lines": a.diff_lines} for a in plan.actions],
        }, indent=2))
        return 0 if not plan.blocking() else 1
    for a in plan.actions:
        extra = f"  ({a.diff_lines} diff lines)" if a.status == "changed" else ""
        print(f"{a.status:<13} {a.path}{extra}{('  ' + a.detail) if a.detail else ''}")
        if args.diff and a.diff:
            print(a.diff)
    print(f"\nworst: {plan.worst}   " + "  ".join(f"{k}={v}" for k, v in plan.by_status().items() if v))
    return 0 if not plan.blocking() else 1


def cmd_apply(args) -> int:
    repo, manifest, packages, plan = _plan(args)
    if args.cmd == "upgrade" and not (repo / ".org/lock.yaml").exists():
        print("upgrade needs an installed repo (.org/lock.yaml missing) — use apply for a first install")
        return 1
    if getattr(args, "diff", False):
        # a preview never writes (measured 2026-09-17: `apply --diff` rewrote every managed file of an installed org)
        for a in plan.actions:
            print(f"{a.status:<13} {a.path}{('  ' + a.detail) if a.detail else ''}")
            if a.diff:
                print(a.diff)
        print(f"\npreview only — nothing written; worst: {plan.worst}   " + "  ".join(f"{k}={v}" for k, v in plan.by_status().items() if v))
        return 0 if not plan.blocking() else 1
    try:
        result = apply_plan(repo, manifest, packages, plan, overwrite_changed=args.overwrite_changed)
    except ApplyRefused as e:
        print(f"apply refused: {e}")
        return 1
    for p in result.written:
        print(f"wrote      {p}")
    for p in result.skipped:
        print(f"unchanged  {p}")
    print(f"lock       {result.lock_path}")
    for line in result.unignored:
        print(f"whitelisted {line}   (git ignored a managed file; a fresh container would not have had it — row 93)")
    w = vendored_wheel(repo)
    if w is not None:
        print(f"vendored   {w.relative_to(repo)}")
        _say_if_unreleased()
    return 0


def _say_if_unreleased() -> None:
    """Print the provenance warning when the wheel just written is on no commit of org-core.

    Only ever a warning: while developing you are legitimately ahead of `main`, and
    refusing would block the release that makes it true. What it must not do is stay
    silent, which is what happened on 2026-09-22.
    """
    msg = unreleased()
    if msg:
        print(f"WARNING    {msg}")


def cmd_vendor(args) -> int:
    """Write the running org-core as a wheel into the repo (SPEC §6, row 54) and print the hook lines that install it."""
    repo = Path(args.repo).resolve()
    w = vendor(repo)
    print(f"vendored   {w.relative_to(repo)}  ({w.stat().st_size} bytes, org-core {__version__})")
    _say_if_unreleased()
    if args.hook:
        print(HOOK_SNIPPET)
    return 0


def cmd_fleet(args) -> int:
    """`org fleet`: who is behind the package, since when, and whether their upgrade is already open (SPEC §11, row 108)."""
    from . import fleet as fl
    root = Path(args.repo) if args.repo else Path(__file__).resolve().parents[1]
    registry = fl.load_registry(Path(args.registry) if args.registry else root / "fleet" / "orgs.yaml")
    try:
        history, note = fl.version_history(root)
    except (RuntimeError, OSError) as e:
        history, note = [], f"no git history at {root}: {str(e)[:120]}"
    rep = fl.report(registry, history=history, history_note=note)
    print(json.dumps(rep, indent=1, ensure_ascii=False) if args.json else fl.render(rep))
    return int(rep["exit"])


def cmd_operator(args) -> int:
    """`org operator render`: the operator file from the board (SPEC §9). Exit 2 when the board cannot be read — a file
    rendered from nothing would say `never ran` for everyone."""
    from . import doctor as dr
    from . import operator_file as of
    repo = Path(args.repo).resolve()
    manifest, packages = _load(Path(args.manifest))
    ctx = dr.Ctx(repo=repo, manifest=manifest)
    def read_record(key: str):
        return dr._record_value(ctx.record(key))
    try:
        rel, new, changes = of.render_repo(repo, manifest, packages, read_record, roles=[r.strip() for r in args.roles.split(",")] if args.roles else None)
    except dr.UnreachablePort as e:
        print(f"operator: {e} — nothing rendered")
        return 2
    for c in changes:
        print(f"{'would render' if args.dry_run else 'rendered'}  {c}")
    if not changes:
        print(f"unchanged  {rel} already says what the board says")
    elif not args.dry_run:
        (repo / rel).write_text(new)
        print(f"wrote      {rel} — commit it on main; the doctor's check 16 reads main")

    # OPT-IN, and it has to be. `operator render` reads the board and nothing else;
    # the page gathers over the network (>2 min against NumeroTech, 2026-09-22).
    # Making it the default put that I/O into a command every chair runs every wake
    # and hung the existing tests, which is how it was caught. The chair's rendered
    # instruction passes --dashboard, so every installed org still gets its page.
    #
    # THE PAGE RIDES THE OPERATOR FILE'S COMMITS. Every commit on an installed org's
    # main can deploy (NumeroTech: every one reaches Vercel production, no ignore
    # rule, 2026-09-22), so the page is re-read only when the file changed or the
    # page is missing: it adds no commit and no deploy the chair was not already
    # making, and it carries its own "read at" time, so a stale page says so.
    # Broken looks like: a wake whose board said nothing new rewriting the page.
    if args.dashboard:
        page = repo / ((manifest.get("org", {}).get("paths", {}) or {}).get("dashboard", DASHBOARD_DEFAULT))
        if changes or not page.exists():
            _render_dashboard(repo, manifest, packages, dry_run=args.dry_run)
        else:
            print(f"unchanged  {page.relative_to(repo)} — re-read only when the operator file changes, so it adds no commit")
    return 0


DASHBOARD_DEFAULT = "docs/human/dashboard.html"


def _render_dashboard(repo: Path, manifest: dict, packages: dict, dry_run: bool = False) -> bool:
    """The org's own page, written beside its operator file by the chair that already wakes.

    The operator file is the reading as text; this is the same reading as a page.
    It rides `org operator render` rather than a clock of its own for the reason
    rows 65 and 98 record: a surface the operator reads is rendered on `main` by
    the chair, never stamped from a role's PR, or it says `never ran` for roles
    that ran daily.

    BEST EFFORT, and deliberately so. `status` gathers over the network and took
    >2 min against NumeroTech on 2026-09-22; the operator file must not be lost to
    a slow or unreachable reading. A failure here prints and returns False, and
    `operator render` still exits 0 with the file written.

    Broken looks like: this raising out of `cmd_operator`, or the operator file
    going unwritten because the page could not be read.
    """
    rel = (manifest.get("org", {}).get("paths", {}) or {}).get("dashboard", DASHBOARD_DEFAULT)
    out = repo / rel
    if dry_run:
        print(f"would render  {rel}")
        return True
    try:
        import datetime as _dt

        from . import dashboard as dash
        from . import status as stx
        from . import tempo as tp

        now = _dt.datetime.now(_dt.timezone.utc)
        since = (now - _dt.timedelta(days=3)).strftime("%Y-%m-%dT00:00:00Z")
        facts = tp.gather(repo, manifest, since=since, now=now)
        st = stx.status(facts, now)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(dash.render_html(st, source="org operator render"))
        cov = st.get("coverage", {})
        print(f"wrote      {rel}  ({cov.get('measured', '?')} of {cov.get('tiles', '?')} tiles read) — commit it on main")
        return True
    except Exception as e:
        print(f"dashboard  not rendered: {type(e).__name__}: {e}")
        print(f"           {rel} is unchanged; the operator file above was written regardless")
        return False


def cmd_setup(args) -> int:
    """`org setup render|status|check` (SPEC §18): the suite install as one generated script, the report a session start
    wrote, and the probe of what this container has against what the tree vendors and pins."""
    from . import suite as su
    from .lock import read as read_lock

    repo = Path(args.repo).resolve()
    manifest, _ = _load(Path(args.manifest))
    if args.setup_cmd == "render":
        text, _ = su.render_setup(manifest)
        print(text, end="")
        return 0
    if args.setup_cmd == "status":
        report = su.read_report(Path(args.report) if args.report else None)
        if args.compact:
            # a reading, never an error: {"report": "absent"} says the setup never ran here, and a record carrying it is
            # distinguishable from one whose capture line failed (`{}`) — the two shapes check 21 tells apart (row 91)
            print(json.dumps(su.compact(report), ensure_ascii=False))
            return 0
        if args.json:
            print(json.dumps(report, indent=2, ensure_ascii=False) if report else "null")
        else:
            print(su.render_status(report))
        return 0 if report else 3
    rows = su.check(repo, manifest, lock=read_lock(repo), runtime=True)
    if args.json:
        print(json.dumps(rows, indent=2, ensure_ascii=False))
    else:
        print(su.render_check(rows))
    return 1 if any(r["ok"] is False for r in rows) else 0


def cmd_lessons(args) -> int:
    """`org lessons pull|digest` (SPEC §11): the fleet's inflow, pulled — what a repository wrote into its own ground truth
    since a watermark, with provenance and the section it landed in; and a reading of one or more pulls for the curator."""
    import datetime as _dt
    import yaml as _yaml
    from . import lessons as ls
    if args.lessons_cmd == "pull":
        repo = Path(args.repo).resolve()
        mpath = repo / (args.manifest or "org.yaml")
        manifest = _yaml.safe_load(mpath.read_text()) if mpath.exists() else None
        now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if getattr(args, "now", None) else None
        p = ls.pull(repo, manifest, since=args.since, now=now, max_lines=args.max_lines)
        out = Path(args.out) if args.out else repo / ".org" / "lessons" / f"pull-{p['pulled_at'][:10]}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(p, indent=1, ensure_ascii=False) + "\n")
        c = p["counts"]
        print(f"pulled     {out}  {p['org']}: {c['commits']} commit(s), {c['hunks']} hunk(s), {c['added_lines']} added line(s) since {p['since']}; sections {c['by_section']}")
        return 0
    if args.lessons_cmd == "seed":
        from .render import frame, parse_managed
        repo = Path(args.repo).resolve()
        mpath = repo / (args.manifest or "org.yaml")
        manifest = _yaml.safe_load(mpath.read_text()) if mpath.exists() else {}
        target = repo / ls.LESSONS_REL
        if not target.exists():
            print(f"no {ls.LESSONS_REL} — run `org apply`/`org upgrade` first; it renders the file")
            return 1
        managed = parse_managed(target.read_text())
        if managed is None:
            print(f"{ls.LESSONS_REL} is not a managed file")
            return 1
        names = {str(e.get("name")): r for r, e in (manifest.get("roles") or {}).items() if isinstance(e, dict) and e.get("name")}
        statuses = ls.load_statuses(Path(args.statuses)) if args.statuses else ls.load_statuses()
        rows = ls.rows_from_extraction(Path(args.extraction).read_text(), args.org or manifest.get("org", {}).get("id") or repo.name, args.date, statuses=statuses, names=names)
        project, n = ls.seed(managed.project, rows)
        target.write_text(frame(managed.frontmatter, managed.base, project, managed.role, managed.kind, managed.version))
        print(f"seeded     {target}  {n} new row(s) of {len(rows)} in the extraction; {sum(1 for r in rows if not r['status'].startswith('open'))} carry an answered status")
        return 0
    if args.lessons_cmd == "brief":
        digest_path = Path(args.digest)
        lines = digest_path.read_text().count("\n") if digest_path.exists() else 0
        text = ls.brief(args.org, digest_path=str(digest_path), digest_lines=lines, core_path=args.core, out_path=args.out_path, since=args.since or "the install", head=args.head or "HEAD")
        if args.out:
            Path(args.out).write_text(text)
            print(f"brief      {args.out}")
        else:
            print(text, end="")
        return 0
    if args.lessons_cmd == "ledger":
        pulls = [json.loads(Path(f).read_text()) for f in args.pulls]
        extractions = []
        for spec in args.extractions or []:
            org, _, path = spec.partition("=")
            extractions.append((org, Path(path).read_text()))
        text = ls.ledger_scaffold(pulls, extractions, args.date)
        if args.out:
            Path(args.out).write_text(text)
            print(f"ledger     {args.out}  (scaffold — the judgment is the curator's)")
        else:
            print(text, end="")
        return 0
    if args.lessons_cmd == "status":
        prefixes = {}
        for spec in args.prefix:
            letter, _, prefix = spec.partition("=")
            prefixes[letter] = prefix
        answers = ls.status_from_ledger(Path(args.ledger).read_text(), prefixes)
        out = Path(args.out) if args.out else Path(ls.__file__).with_name("lessons_status.json")
        current = ls.load_statuses(out) if out.exists() else {}
        current.update(answers)
        out.write_text(json.dumps(dict(sorted(current.items())), indent=1, ensure_ascii=False) + "\n")
        by = {}
        for v in answers.values():
            by[v["status"]] = by.get(v["status"], 0) + 1
        print(f"status     {out}  {len(answers)} row(s) answered from the ledger ({', '.join(f'{k} {n}' for k, n in sorted(by.items()))}); {len(current)} in the file")
        return 0
    pulls = [json.loads(Path(f).read_text()) for f in args.facts]
    text = ls.digest(pulls, min_added=args.min_added, skip_tags=tuple(args.skip_tags or ()), skip_sections=tuple(args.skip_sections or ()),
                     max_lines=args.max_lines, subjects_skip=tuple(args.skip_subject_prefix or ()))
    if args.out:
        Path(args.out).write_text(text)
        print(f"digest     {args.out}  {text.count(chr(10))} line(s)")
    else:
        print(text, end="")
    return 0


def cmd_tempo(args) -> int:
    """`org tempo gather|report|wake-now` (SPEC §13): the org's speed, measured from the board, the pull requests and the
    routines — and the roles a port holder should fire before their next cron tick."""
    import datetime as _dt
    import yaml as _yaml
    from . import actuator as ac
    from . import tempo as tp

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if getattr(args, "now", None) else _dt.datetime.now(_dt.timezone.utc)
    if args.tempo_cmd == "gather":
        extra = json.loads(Path(args.facts).read_text()) if args.facts else {}
        facts = tp.gather(repo, manifest, since=args.since, triggers=extra.get("triggers"), sessions=extra.get("sessions"), now=now)
        out = Path(args.out) if args.out else repo / tp.FACTS_DIR / f"facts-{facts['gathered_at'][:10]}.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(facts, indent=1, ensure_ascii=False) + "\n")
        print(f"gathered   {out}  board {len(facts['board'])} rows, prs {len(facts['prs'])}, runs {len(facts['runs'])}, triggers {len(facts['triggers'])}"
              + (f"  could not read: {'; '.join(facts['could_not_read'])}" if facts["could_not_read"] else ""))
        return 2 if facts["could_not_read"] else 0
    if args.tempo_cmd == "wake-now":
        extra = json.loads(Path(args.facts).read_text()) if args.facts else {}
        since = args.since or (now - _dt.timedelta(days=3)).strftime("%Y-%m-%dT00:00:00Z")
        facts = tp.gather(repo, manifest, since=since, triggers=extra.get("triggers"), sessions=extra.get("sessions"), now=now)
        rows = tp.wake_now(facts, now)
        if args.json:
            print(json.dumps({"wake_now": rows, "could_not_read": facts["could_not_read"]}, indent=2, ensure_ascii=False))
        else:
            for w in rows:
                print(f"{'FIRE' if w['fire'] else 'HOLD'} {w['role']:<16} {w['why']}" + (f" — trigger {w['trigger']}" if w.get("trigger") else " — no trigger seen (pass --facts with the triggers list)")
                      + (f" — its record says blocked: {w['blocked']}" if w.get("blocked") else ""))
                for e in w["events"][:5]:
                    print(f"     {e['event']:<16} {e['what']} waiting {e['waiting_hours']}h")
            if not rows:
                print("nothing past target")
            if facts["could_not_read"]:
                print("could not read: " + "; ".join(facts["could_not_read"]))
        return 2 if facts["could_not_read"] else 0
    if args.tempo_cmd == "triggers":
        dump = json.loads(Path(args.facts).read_text())
        rows = dump.get("triggers") if isinstance(dump, dict) else dump
        if isinstance(rows, dict) and "data" in rows:
            rows = rows["data"]
        compact = ac.compact_triggers(rows or [])
        key = ac.org_tempo(manifest)["triggers_key"]
        value = json.dumps({"at": now.isoformat(timespec="seconds"), "triggers": compact}, ensure_ascii=False)
        rc = _board_set(manifest, key, value, 604800)
        print(f"{key}: {len(compact)} triggers" + ("" if rc == 0 else " — WRITE FAILED"))
        return rc
    if args.tempo_cmd == "wake":
        return _tempo_wake(args, repo, manifest, now, ac, tp)
    if args.tempo_cmd in ("register", "dm", "park-until", "next-fire"):
        return _tempo_listener(args, repo, manifest, now, ac, tp)
    files = [json.loads(Path(f).read_text()) for f in args.facts]
    facts = tp.merge_facts(files) if len(files) > 1 else files[0]
    rep = tp.report(facts, now)
    if args.json:
        print(json.dumps(rep, indent=2, ensure_ascii=False))
    else:
        print(tp.render(rep), end="")
    return 0


def _board_set(manifest, key: str, value: str, ttl: int) -> int:
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    p = subprocess.run(["switchboard", "--json", "board", "set", key, value, "--ttl", str(int(ttl))], capture_output=True, text=True, timeout=60, env=env)
    if p.returncode != 0:
        print(f"board set {key} failed: {(p.stderr or p.stdout).strip()[:200]}")
    return 0 if p.returncode == 0 else 1


def _board_get(manifest, key: str):
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    p = subprocess.run(["switchboard", "--json", "board", "get", key], capture_output=True, text=True, timeout=60, env=env)
    text = (p.stdout or "").strip()
    if p.returncode != 0 or not text or text.startswith("no entry"):
        return None
    try:
        got = json.loads(text)
    except json.JSONDecodeError:
        return None
    v = got.get("value")
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            return None
    return v


def _switchboard(manifest, argv: list[str]):
    import os as _os
    env = dict(_os.environ)
    co = manifest["ports"]["coordination"]
    env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
    if co.get("url"):
        env["SWITCHBOARD_URL"] = co["url"]
    return subprocess.run(["switchboard", "--json", *argv], capture_output=True, text=True, timeout=60, env=env)


def _tempo_listener(args, repo, manifest, now, ac, tp) -> int:
    """`org tempo register|dm|park-until|next-fire` — the persistent roles' half of tempo (SPEC §5, §13): a role registers
    its agent id so senders can address it, a sender DMs a receiver that is listening, and a role learns how long to park."""
    import datetime as _dt
    now = now or _dt.datetime.now(_dt.timezone.utc)
    cfg = ac.org_tempo(manifest)
    minutes = float(getattr(args, "listen_minutes", None) or cfg.get("listen_minutes") or tp.DEFAULT_LISTEN_MINUTES)
    if args.tempo_cmd == "park-until":
        print((now + _dt.timedelta(minutes=minutes)).replace(microsecond=0).isoformat())
        return 0
    if args.tempo_cmd == "next-fire":
        entry = manifest["roles"].get(args.role) or {}
        cadence = entry.get("cadence") or tp._default(args.role, "cadence")
        nxt = tp.cron_next(str(cadence or ""), now)
        print(nxt.isoformat() if nxt else "none")
        return 0 if nxt else 2
    if args.tempo_cmd == "register":
        who = _switchboard(manifest, ["whoami"])
        try:
            me = json.loads(who.stdout or "{}")
        except json.JSONDecodeError:
            me = {}
        aid = me.get("agent_id")
        if not aid:
            print(f"register: switchboard whoami gave no agent_id: {(who.stderr or who.stdout).strip()[:200]}")
            return 1
        until = (now + _dt.timedelta(minutes=minutes)).replace(microsecond=0).isoformat()
        # one listener per session: the hub's `listener/<agent_id>` heartbeat (90 s TTL, refreshed every pass) says whether the
        # one parked last turn is still running — a cron that fires into a parked session must not park a second one
        alive = _board_get(manifest, f"listener/{aid}") is not None
        current = _board_get(manifest, tp.AGENTS_KEY) or {}
        roles = current.get("roles") if isinstance(current, dict) else None
        roles = dict(roles or {})
        roles[args.role] = {"agent_id": aid, "name": (manifest["roles"].get(args.role) or {}).get("name"), "session_id": getattr(args, "session_id", None) or roles.get(args.role, {}).get("session_id"),
                            "registered_at": now.isoformat(timespec="seconds"), "listen_until": until, "workspace": me.get("workspace"), "listen_minutes": minutes}
        rc = _board_set(manifest, tp.AGENTS_KEY, json.dumps({"at": now.isoformat(timespec="seconds"), "roles": roles}, ensure_ascii=False), 604800)
        print(json.dumps({"role": args.role, "agent_id": aid, "until": until, "listen_minutes": minutes, "written": rc == 0, "listener_alive": alive,
                          "park": "no — a listener is still running; it wakes you when it exits" if alive else "yes — park one before you end"}))
        return rc
    # dm — routed by the receiver's runtime (SPEC §5, rows 75 and 77)
    text = " ".join(args.text)
    how, target = tp.wake_route(args.role, manifest)
    if how == "clock":
        entry = manifest["roles"].get(args.role) or {}
        nxt = tp.cron_next(str(entry.get("cadence") or tp._default(args.role, "cadence") or ""), now)
        print(f"clock-only: {args.role} is woken by nothing on demand (on_demand none — the doctor, or a role this org opted out; "
              f"the CEO listens since 0.15.0, row 86); the board key is the handoff, read at its next fire" + (f" {nxt.isoformat()}" if nxt else " (no cron: a human-driven session)"))
        return 3
    if how == "route":
        text = f"wake {args.role}: {text}"
    reg = (_board_get(manifest, tp.AGENTS_KEY) or {}).get("roles") or {}
    entry = reg.get(target) or {}
    aid = entry.get("agent_id")
    if not aid:
        print(f"absent: {target} never registered in {tp.AGENTS_KEY} — nothing to address; "
              + (f"{args.role} is spawned by {target}, whose cron is the floor" if how == "route" else "the board key waits for its cron"))
        return 1
    ag = _switchboard(manifest, ["agents"])
    try:
        present = tp.roster_ids(json.loads(ag.stdout or "[]"))
        roster_read = True
    except json.JSONDecodeError:
        present, roster_read = set(), False
    if roster_read and aid not in present:
        print(f"absent: {target} is registered as {aid} but not on the roster (listener parked until {entry.get('listen_until')}, registered {entry.get('registered_at')}) — not sent; "
              + (f"{target}'s cron is the floor for spawning {args.role}" if how == "route" else "the board key waits for its cron"))
        return 2
    p = _switchboard(manifest, ["dm", aid, text])
    if p.returncode != 0:
        print(f"dm to {target} ({aid}) failed: {(p.stderr or p.stdout).strip()[:200]}")
        return 2
    head = (f"routed: {args.role} is spawned — DM to {target} ({aid}), whose wake spawns it" if how == "route" else f"delivered: {target} ({aid})")
    print(head + ("" if roster_read else " — roster unread, sent on the registry alone") + f": {(p.stdout or '').strip()[:160]}")
    return 0


def _tempo_wake(args, repo, manifest, now, ac, tp) -> int:
    """`org tempo wake plan|record` — the actuator's four-call wake (SPEC §13.1). `plan` gathers live and prints the acts;
    `record` writes the ledger row, the heartbeat and the lease from the plan and the port's answers."""
    import datetime as _dt
    now = now or _dt.datetime.now(_dt.timezone.utc)
    session = json.loads(Path(args.session_json).read_text()) if getattr(args, "session_json", None) else None
    if args.wake_cmd == "plan":
        extra = json.loads(Path(args.facts).read_text()) if args.facts else {}
        triggers = extra.get("triggers") if isinstance(extra, dict) else None
        since = args.since or (now - _dt.timedelta(days=3)).strftime("%Y-%m-%dT00:00:00Z")
        facts = tp.gather(repo, manifest, since=since, triggers=triggers, sessions=extra.get("sessions") if isinstance(extra, dict) else None, now=now)
        if not triggers:   # the compact key the actuator wrote once a day
            key = ac.org_tempo(manifest)["triggers_key"]
            row = tp._latest_records(facts["board"]).get(key)
            v = tp._value(row) if row else {}
            if v.get("triggers"):
                facts["triggers"] = v["triggers"]
                facts["triggers_key_at"] = v.get("at")
        requests = tp.requests_from_inbox(json.loads(Path(args.inbox).read_text())) if getattr(args, "inbox", None) else []
        p = ac.plan(facts, manifest, now, session=session, requests=requests)
        if facts.get("triggers_key_at") and (tp.hours(facts["triggers_key_at"], now.isoformat()) or 0) > 26:
            p["could_not_read"].append(f"triggers key is {tp.hours(facts['triggers_key_at'], now.isoformat())}h old — refresh it (org tempo triggers)")
        out = Path(args.out) if args.out else repo / ".org" / "tempo" / "plan.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(p, indent=1, ensure_ascii=False) + "\n")
        print(ac.render_plan(p), end="")
        print(f"plan written to {out}")
        return p["exit_code"]
    plan = json.loads(Path(args.plan).read_text())
    results = json.loads(Path(args.results).read_text()) if args.results else []
    if isinstance(results, dict):
        results = results.get("results") or []
    cfg = ac.org_tempo(manifest)
    board = []
    try:
        board = tp.gather_board(manifest["ports"]["coordination"]["workspace"], prefixes=("coord/tempo/",))
    except (RuntimeError, OSError, json.JSONDecodeError) as e:
        print(f"could not read the board: {e}")
    previous = ac.heartbeat(board, cfg)
    rec = ac.record_wake(plan, results, now, session=session, previous=previous, manifest=manifest)
    existing = tp._latest_records(board).get(rec["ledger_key"])
    rows = (tp._value(existing).get("rows") if existing else None) or []
    rows = [r for r in rows if r.get("run_id") != rec["row"]["run_id"]] + [rec["row"]]
    queue = ac.operator_queue(board, cfg) + rec["queue_add"]
    lz = ac.lease(board, cfg)
    if lz and lz.get("session_id") and rec["lease"].get("session_id") and ac._sid(lz["session_id"]) != ac._sid(rec["lease"]["session_id"]) and (tp.parse_ts(lz.get("until")) or now) > now:
        print(f"LEASE held by {lz['session_id']} until {lz.get('until')} — recording the row, not taking the lease")
        rec["lease"] = None
    if args.dry_run:
        print(json.dumps({k: rec[k] for k in ("row", "heartbeat", "lease", "queue_add")}, indent=1, ensure_ascii=False))
    else:
        rc = _board_set(manifest, rec["ledger_key"], json.dumps({"date": rec["ledger_key"].rsplit("-", 3)[-3:], "rows": rows}, ensure_ascii=False), 604800)
        rc |= _board_set(manifest, rec["heartbeat_key"], json.dumps(rec["heartbeat"], ensure_ascii=False), rec["ttl_seconds"])
        if rec["lease"]:
            rc |= _board_set(manifest, rec["lease_key"], json.dumps(rec["lease"], ensure_ascii=False), rec["ttl_seconds"])
        if rec["queue_add"]:
            rc |= _board_set(manifest, rec["operator_queue_key"], json.dumps({"at": now.isoformat(timespec="seconds"), "items": queue[-50:]}, ensure_ascii=False), 604800)
        if rc:
            return 1
    print("fired: " + json.dumps(rec["fired"], ensure_ascii=False))
    for pr in rec["problems"]:
        print(f"problem: {pr}")
    return 2 if rec["problems"] else 0


def cmd_fidelity(args) -> int:
    """Measure and record how far a repo's existing role files are from the packages (SPEC §6, the fidelity test)."""
    repo, manifest, packages, plan = _plan(args)
    try:
        head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        head = None
    record = {
        "at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "org_core": __version__,
        "org": manifest["org"]["id"],
        "repo_head": head,
        "worst": plan.worst,
        "by_status": plan.by_status(),
        "files": [{"path": a.path, "status": a.status, "diff_lines": a.diff_lines, "detail": a.detail} for a in plan.actions],
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(record, indent=2) + "\n")
    print(f"worst={plan.worst}  " + "  ".join(f"{k}={v}" for k, v in plan.by_status().items() if v) + f"  -> {out}")
    for a in plan.actions:
        if a.status not in ("markers-only", "unchanged"):
            print(f"  {a.status:<13} {a.path}  {a.diff_lines} diff lines  {a.detail}")
            if args.diff and a.diff:
                print(a.diff)
    return 0 if not any(a.status in ("changed", "undeclared", "error") for a in plan.actions) else 1


def cmd_init(args) -> int:
    repo = Path(args.repo).resolve()
    d = detect(repo)
    print(json.dumps(d, indent=2))
    if args.write:
        m = draft_manifest(repo, d, defaults_by_role(discover()))
        target = repo / "org.yaml"
        if target.exists() and not args.force:
            print(f"\n{target} exists; not overwriting (use --force)")
            return 1
        target.write_text(dump_manifest(m))
        print(f"\nwrote draft manifest {target} — every <...> is a value the tool would not guess")
    return 0


def cmd_install(args) -> int:
    """One command for a first install. Run it again after each thing it asks for.

    It is the same four commands an operator ran by hand — `init`, `validate`,
    `apply`, `verify` — with the step nobody was doing put back: reading the
    draft's `<...>` values before rendering them into role files.

    Three outcomes, and the exit code says which:
      0  installed, and `verify` is clean enough to hand over
      2  your turn — the manifest is missing or unfinished; it says what to fill
      1  the install itself failed, or `verify` found something broken

    Idempotent: on an installed repo `apply` writes nothing and this re-verifies.
    """
    repo = Path(args.repo).resolve()
    mpath = Path(args.manifest) if args.manifest else repo / "org.yaml"

    # Said here rather than left to a FileNotFoundError three calls down. Measured
    # 2026-09-22: a mistyped --repo ran `detect`, printed the whole detection JSON,
    # then exited 1 with "missing: .../org.yaml" — which names the wrong thing.
    if not repo.is_dir():
        print(f"no such directory: {repo}")
        print("\nNEXT: point --repo at the checkout you want the org installed into.")
        return 1

    if not mpath.exists():
        print(f"no manifest at {mpath} — writing the draft\n")
        rc = cmd_init(argparse.Namespace(repo=str(repo), write=True, force=False))
        if rc:
            return rc
        if not (repo / ".git").exists():
            print(f"\nnote  {repo} is not a git repository. `apply` will still write, but"
                  "\n      `verify`'s `tracked` step reads git to tell a committed install"
                  "\n      from one that exists only in this container.")
        print("\nNEXT: fill every <...> in org.yaml, then run this same command again.")
        return 2

    import yaml as _yaml

    # A syntax error in the file a person was just told to edit is the most likely
    # failure at this point, and a YAML traceback is not an answer to it.
    try:
        data = _yaml.safe_load(mpath.read_text()) or {}
    except _yaml.YAMLError as e:
        print(f"{mpath} is not valid YAML:\n")
        print("  " + str(e).replace("\n", "\n  "))
        print("\nNEXT: fix the syntax, then run this same command again.")
        return 2
    if not isinstance(data, dict):
        print(f"{mpath} is valid YAML but not a mapping — it parsed as {type(data).__name__}.")
        print("\nNEXT: `org init --repo . --write --force` rewrites the draft if you want to start over.")
        return 2
    problems = validate(data)
    if problems:
        print(f"{mpath} is not ready to install:\n")
        for p_ in problems:
            print(f"  {p_}")
        print("\nNEXT: fix those, then run this same command again.")
        return 2

    # Worth saying, never fatal: these are real but nothing renders them, and both
    # shipped orgs carry them (measured 2026-09-22).
    for u in unfilled(data):
        print(f"note  {u}")

    print(f"\n=== apply {repo} ===")
    rc = main(["apply", "--repo", str(repo), "--manifest", str(mpath)])
    if rc:
        return rc

    print("\n=== verify ===")
    manifest_data, packages = _load(mpath)
    steps = run_verify(repo, manifest_data, packages, {}, drill=None)
    print(verify_text(steps))
    rc = verify_exit(steps)

    # A first install CANNOT be verify-clean, and saying "8 bad" without saying why
    # reads as eight things broken. Two of the classes are the install's own next
    # steps rather than faults: `tracked` is red until somebody commits, and
    # `records-ever` is red until each role has run once. Measured 2026-09-22 on a
    # clean rehearsal: 8 bad, and all 8 were those two.
    bad = [s for s in steps if s.status in ("FAIL", "UNREACHABLE")]
    expected = [s for s in bad if s.id in ("tracked", "records-ever")]
    other = [s for s in bad if s.id not in ("tracked", "records-ever")]

    print("\nThe files are in. What is left has no API and so no command:")
    if any(s.id == "tracked" for s in expected):
        print("  1. commit them — `tracked` is red until git carries the managed files,\n"
              "     because a fresh container gets the install from git, not from here")
    print("  2. attach the repo to each role's routine and start the persistent sessions;\n"
          "     `org routine <role> --manifest org.yaml` prints what each one needs")
    print("  3. re-run this command — `records-ever` goes green as each role fires once.\n"
          "     Every manual step has a verification `org verify` runs; it refuses to pass\n"
          "     one by assertion (SPEC §6).")

    if other:
        print(f"\n{len(other)} step(s) need looking at beyond those — they are not part of the normal first install:")
        for s in other:
            print(f"  {s.status:<12} {s.id}")
    elif rc:
        print(f"\nverify is {len(expected)} bad, and all of it is the list above — nothing unexpected.")
    return rc


def cmd_doctor(args) -> int:
    manifest, _ = _load(Path(args.manifest))
    facts = json.loads(Path(args.facts).read_text()) if args.facts else {}
    ctx = Ctx(repo=Path(args.repo).resolve(), manifest=manifest, facts=facts)
    if args.drill:
        if args.drill not in manifest["roles"]:
            print(f"no such role: {args.drill}")
            return 1
        ctx.drill_absent = {ctx.report_key(args.drill)}
    only = {int(n) for n in args.only.split(",")} if args.only else None
    results = run(ctx, only)
    if args.json:
        print(json.dumps(to_json(results, ctx), indent=2))
    else:
        print(render_text(results))
    return exit_code(results)


def cmd_record(args) -> int:
    rec = json.loads(Path(args.file).read_text())
    counts_schema = None
    if isinstance(rec, dict) and rec.get("role"):
        pkg = discover().get(rec["role"])
        counts_schema = pkg.record_schema if pkg else None
    problems = validate_record(rec, counts_schema)
    if problems:
        print("\n".join(problems))
        return 1
    print("ok")
    return 0


def cmd_routine(args) -> int:
    manifest, packages = _load(Path(args.manifest))
    try:
        sp = routine_spec(manifest, packages, args.role)
    except (ValueError, KeyError) as e:
        print(str(e))
        return 1
    print(json.dumps(sp, indent=2) if args.json else routine_text(sp))
    return 0


def cmd_verify(args) -> int:
    manifest, packages = _load(Path(args.manifest))
    facts = json.loads(Path(args.facts).read_text()) if args.facts else {}
    steps = run_verify(Path(args.repo).resolve(), manifest, packages, facts, drill=None if args.no_drill else args.drill)
    if args.json:
        print(json.dumps({"summary": verify_summary(steps), "steps": [s.__dict__ for s in steps]}, indent=2))
    else:
        print(verify_text(steps))
    return verify_exit(steps)


def cmd_record_from_doctor(args) -> int:
    import yaml as _yaml
    from .lock import read as read_lock

    report = json.loads(Path(args.report).read_text())
    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / "org.yaml").read_text())
    lock = read_lock(repo) or {}
    role_version = ((lock.get("files") or {}).get(".claude/skills/doctor/SKILL.md") or {}).get("template_version")
    try:
        sha = subprocess.run(["git", "-C", str(repo), "rev-parse", "--short", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        sha = None
    from . import suite as su
    rec = from_doctor(report, org=manifest["org"]["id"], name=manifest["roles"]["doctor"]["name"], runtime=args.runtime,
                      session_id=args.session_id, manifest_version=manifest.get("manifest_version"), role_version=role_version,
                      git_sha=sha, pr=args.pr, next_due=args.next_due, suite=su.compact(su.read_report()))
    problems = validate_record(rec, discover()["doctor"].record_schema)
    if problems:
        print("\n".join(problems))
        return 1
    print(json.dumps(rec))
    return 0


def _tickets_rows(args, repo: Path, port: dict, manifest: dict | None = None) -> tuple[list[dict], list[dict], bool]:
    """(tickets, items, complete) from the chosen source. `file` is the executor pattern: a role ran the SQL through
    the org's read port and saved the rows; `psql` and `api` read live, never write."""
    from .tickets import adapters as ad

    manifest = manifest or {}

    def _rel(p):   # a role runs from anywhere with --repo: relative paths are the repo's unless they exist here
        q = Path(p)
        return q if q.is_absolute() or q.exists() else repo / q

    items_path = _rel(args.items) if args.items else repo / "roadmap" / "items"
    source = args.source or ("file" if args.tickets else ("api" if args.url else ("psql" if args.dsn_env else "file")))
    if source == "file":
        if not args.tickets:
            raise SystemExit("--tickets <rows.json> is required with --source file (run `org tickets sql` and save what the read port returns)")
        tickets = ad.load_tickets_json(_rel(args.tickets))
        if args.notes:
            ad.attach_notes(tickets, ad.load_notes_json(_rel(args.notes)))
        items = ad.load_items(items_path)
        return tickets, items, bool(args.assume_complete)
    if source == "psql":
        dsn = ad.token_from_env(args.dsn_env or port.get("dsn_env") or "TICKETS_DSN")
        sql = ad.sql_for(args.dialect)
        tickets = ad.psql_rows(dsn, sql["tickets"])
        ad.attach_notes(tickets, ad.psql_rows(dsn, sql["notes"]))
        return tickets, ad.load_items(items_path), True
    if source == "api":
        base = args.url or port.get("api")
        if not base:
            raise SystemExit("--url (or ports.tickets.api) is required with --source api")
        token_file = port.get("token_file") or ((manifest.get("ports") or {}).get("prod_read") or {}).get("jwt_cache")
        token = ad.token_from_env(args.token_env or port.get("token_env") or "LUCILLE_ADMIN_JWT", token_file)
        if getattr(args, "id", None):   # stage: one ticket, with its notes, as the reference script does
            tid = args.id.strip().lower()
            tickets, complete = ad.api_tickets(base, token)
            for t in tickets:
                if str(t.get("id") or "").lower() == tid:
                    try:
                        t["notes"] = ad.api_notes(base, token, tid)
                    except Exception:  # noqa: BLE001 — notes are context, never the answer
                        t["notes"] = []
        else:
            tickets, complete = ad.api_tickets(base, token)
        items = ad.api_items(base, token) if not args.items else ad.load_items(items_path)
        return tickets, items, complete
    raise SystemExit(f"unknown source {source!r}")


def cmd_tickets(args) -> int:
    """The tickets port (SPEC §17): the lifecycle over an org's own store, plus the github-issues intake helpers."""
    import datetime as _dt

    import yaml as _yaml

    from . import tickets as tk
    from .tickets import adapters as ad
    from .tickets import core as tc

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / "org.yaml").read_text()) if (repo / "org.yaml").exists() else {}
    port = (manifest.get("ports") or {}).get("tickets") or {}
    people = port.get("person_sources") or sorted(tc.DEFAULT_PERSON_SOURCES)
    cmd = args.tickets_cmd
    if cmd == "sql":
        sql = ad.sql_for(args.dialect)
        print(f"-- tickets ({args.dialect}); run through the org's read port, save the rows as JSON, pass --tickets\n{sql['tickets']};\n-- notes; pass --notes\n{sql['notes']};")
        return 0
    if cmd in ("stage", "open-loops", "report", "impact"):
        try:
            tickets, items, complete = _tickets_rows(args, repo, port, manifest)
        except (RuntimeError, OSError, ValueError) as e:   # no credential, no rows file, bad JSON: the reason, not a traceback
            print(f"org tickets {cmd}: {e}", file=sys.stderr)
            return 2
        now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if args.now else _dt.datetime.now(_dt.timezone.utc)
        index = tc.index_by_ticket(items)
        if cmd == "stage":
            wanted = args.id.strip().lower()
            match = [t for t in tickets if str(t.get("id") or "").lower() == wanted]
            if not match:
                print(f"no ticket {args.id}")
                return 1
            t = tc.normalize_ticket(match[0]); linked = index.get(wanted, []); stage = tc.stage_of(t, linked)
            print(json.dumps({"ticket": t, "items": linked, "stage": stage}, default=str, indent=2) if args.json else tc.render_stage(t, linked, stage, people))
            return 0
        findings = tc.find_open_loops(tickets, index, now=now, person_sources=people)
        if cmd == "open-loops":
            if complete:
                findings += tc.dangling_links(index, [t.get("id") for t in tickets])
            else:
                print("note: read is not known-complete — skipping dangling_link (pass --assume-complete for a full dump)", file=sys.stderr)
            if args.json:
                print(json.dumps(findings, default=str, indent=2))
            else:
                print(tc.render_findings(findings))
                blockers = tc.prune_blockers(index, tickets)
                if blockers:
                    print("Do not prune yet — these done items still carry an open loop:")
                    for key in blockers:
                        print(f"  {key}")
            return 2 if findings else 0
        if cmd == "report":
            today = now.date().isoformat()
            text = tc.report_text(tickets, items, findings, today)
            if args.write:
                out = repo / (port.get("reports_dir") or "docs/operations/ticket-reports") / f"{today}-pipeline.md"
                out.parent.mkdir(parents=True, exist_ok=True); out.write_text(text); print(f"wrote {out.relative_to(repo)}")
            else:
                print(text)
            return 0
        if cmd == "impact":
            by_key = {tc.item_key(i): i for i in items}
            item = by_key.get(args.key)
            if item is None:
                print(f"no item {args.key}")
                return 1
            r = tc.impact(item, tickets)
            if args.json:
                print(json.dumps(r, default=str, indent=2))
            else:
                print(f"{r['item']}: done_at={r['done_at'] or '—'} done_version={r['done_version'] or '—'} — {len(r['tickets'])} linked, {r['recurred']} after, {len(r['missing'])} missing")
                for row in r["tickets"]:
                    print(f"  {row['verdict']:7s} {row['ticket']} [{row['source'] or '?'}] {row['status']} filed {row['created_at']} on {row['deployed_version'] or '—'}")
                for m in r["missing"]:
                    print(f"  missing {m} — linked by the item, not in the rows")
            return 2 if r["recurred"] else 0
    if port.get("tool") != "github-issues":
        print(f"tickets port is `{port.get('tool', 'absent')}` — `org tickets` only serves github-issues orgs")
        return 1
    gh_repo = (manifest.get("org") or {}).get("repo")
    if not gh_repo:
        print("org.repo missing from org.yaml")
        return 1
    wanted = tk.wanted_labels(port)
    tpl = port.get("template")
    try:
        existing = tk.gh_labels(gh_repo)
    except Exception as e:  # noqa: BLE001 — the reason is the output
        print(f"cannot list labels in {gh_repo}: {e}")
        return 2
    missing = tk.label_plan(existing, wanted)
    tpl_state = "not declared" if not tpl else ("present" if (repo / tpl).exists() else "MISSING")
    print(f"labels wanted {len(wanted)}, present {len(wanted) - len(missing)}, missing {len(missing)}" + (": " + ", ".join(missing) if missing else ""))
    print(f"issue form: {tpl_state}" + (f" ({tpl})" if tpl else ""))
    if args.tickets_cmd == "status":
        return 0 if not missing and tpl_state != "MISSING" else 1
    if args.dry_run:
        print("dry run — nothing created")
        return 0
    for line in tk.ensure_labels(gh_repo, wanted):
        print(f"label      {line}")
    if tpl and tk.write_template(repo, tpl, wanted[0]):
        print(f"wrote      {tpl}")
    return 0


def cmd_checks(args) -> int:
    import datetime as _dt

    import yaml as _yaml

    from . import checks as ck

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / "org.yaml").read_text()) if (repo / "org.yaml").exists() else {}
    port = (manifest.get("ports") or {}).get("checks") or {}
    registry = repo / (args.registry or port.get("registry") or ck.DEFAULT_REGISTRY)
    ledger_path = repo / (args.ledger or port.get("ledger") or ck.DEFAULT_LEDGER)
    results_path = repo / (args.results or port.get("results") or ck.DEFAULT_RESULTS)
    today = _dt.date.fromisoformat(args.today) if args.today else _dt.datetime.now(_dt.timezone.utc).date()
    try:
        checks = ck.load_registry(registry)
    except ck.RegistryError as e:
        print(str(e))
        return 1

    def _print_results(results):
        for r in results:
            extra = ("  " + ", ".join(f"{k}={v}" for k, v in r.detail.items())) if r.detail else ""
            err = f"  error: {r.error}" if r.error else ""
            esc = "  ESCALATED" if r.escalated else ""
            print(f"{r.state:<13} {r.check.id}{extra}{err}{esc}")
        bad = sum(1 for r in results if r.state in (ck.FAIL, ck.ERROR))
        print(f"\n{len(results)} checks: " + ", ".join(f"{s}={sum(1 for r in results if r.state == s)}" for s in (ck.PASS, ck.FAIL, ck.INCONCLUSIVE, ck.ERROR, ck.PENDING, ck.EXPIRED)))
        return bad

    if args.checks_cmd == "validate":
        try:
            problems = ck.ledger_problems(checks, ck.load_ledger(ledger_path))
        except ck.RegistryError as e:
            problems = [str(e)]
        if problems:
            print("\n".join(problems))
            return 1
        print(f"ok — {len(checks)} checks, ledger consistent")
        return 0
    if args.checks_cmd == "plan":
        rows = ck.plan(checks, today)
        if args.json:
            print(json.dumps(rows, indent=2))
        else:
            for r in rows:
                print(f"{r['state']:<8} {r['id']}  ({r['check_after']} → {r['until']}, {r['severity']})")
            print(f"\n{sum(1 for r in rows if r['state'] == 'due')} due today ({today.isoformat()})")
        return 0
    if args.checks_cmd in ("evaluate", "record", "run"):
        if args.checks_cmd == "run":
            if args.executor != "psql":
                print("run supports --executor psql only; for supabase-mcp or manual, use plan → (run the SQL) → record --rows")
                return 2
            dsn = os.environ.get(args.dsn_env or port.get("dsn_env") or "CHECKS_DSN")
            if not dsn:
                print(f"no DSN: set {args.dsn_env or port.get('dsn_env') or 'CHECKS_DSN'}")
                return 2
            try:
                rows = ck.run_psql(checks, today, dsn)
            except RuntimeError as e:
                print(str(e))
                return 2
        else:
            rows = json.loads(Path(args.rows).read_text())
        results = ck.evaluate_all(checks, rows, today)
        bad = _print_results(results)
        if args.checks_cmd == "evaluate":
            return 1 if bad else 0
        n = ck.append_results(results_path, results, today)
        print(f"appended {n} lines to {results_path.relative_to(repo)}")
        if args.file_issues:
            slug = (manifest.get("org") or {}).get("repo")
            label = ((manifest.get("ports") or {}).get("tickets") or {}).get("label", "ticket")
            if not slug:
                print("--file-issues needs org.repo in org.yaml")
                return 1
            try:
                open_issues = [] if args.dry_run and args.no_gh else ck.gh_open_issues(slug, label)
            except RuntimeError as e:
                print(f"issues: {e}")
                return 1
            actions = ck.issue_actions(results, open_issues, _dt.datetime.now(_dt.timezone.utc), slug, label)
            if args.dry_run:
                for a in actions:
                    print("would " + json.dumps({k: v for k, v in a.items() if k != "body"}))
            else:
                for line in ck.gh_apply(slug, actions):
                    print(line)
        return 1 if bad else 0
    if args.checks_cmd == "report":
        rep = ck.report(checks, ck.read_results(results_path), today, repo / "roadmap" / "items")
        if args.json:
            print(json.dumps(rep, indent=2))
        else:
            c = rep["counts"]
            print(f"{rep['date']}: {rep['checked']} checks — pass {c['pass']}, fail {c['fail']} (high {rep['high']}), inconclusive {c['inconclusive']}, error {c['error']}, pending {c['pending']}, expired {c['expired']}, never run {len(rep['never_run'])}")
            if rep["oldest_failure"]:
                print(f"oldest failure: {rep['oldest_failure']['id']} red {rep['oldest_failure']['days']}d")
            for k in ("failures_without_item", "vacuous_unflagged", "expiring_within_7d", "expired_while_red", "worsening", "never_run"):
                for line in rep[k]:
                    print(f"{k}: {line}")
        return 0
    return 2


def cmd_command(args) -> int:
    """`org command` (SPEC §9, §11): the fleet as one console, for the person it waits on. One reading per
    org in the registry; an org that could not be read is a row saying so, never a row left out."""
    import datetime as _dt

    import yaml as _yaml

    from . import command as cm
    from . import fleet as fl
    from . import status as stx
    from . import tempo as tp

    repo = Path(args.repo).resolve()
    now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if args.now else _dt.datetime.now(_dt.timezone.utc)
    since = (now - _dt.timedelta(days=float(args.days))).strftime("%Y-%m-%dT00:00:00Z")
    registry = fl.load_registry(Path(args.registry) if args.registry else repo / "fleet" / "orgs.yaml")
    extra = json.loads(Path(args.extra).read_text()) if getattr(args, "extra", None) else {}
    orgs = []
    for entry in registry:
        checkout = Path(entry.get("checkout") or "")
        mf = checkout / "org.yaml"
        if not mf.is_file():
            orgs.append({"org": entry, "status": None,
                         "why": f"no checkout at {checkout or '<none declared>'} — this session cannot read it"})
            continue
        try:
            manifest = _yaml.safe_load(mf.read_text())
            facts = tp.gather(checkout, manifest, since=since, sessions=extra.get("sessions"),
                              triggers=extra.get("triggers"), now=now)
            orgs.append({"org": manifest["org"], "status": stx.status(facts, now)})
        except (OSError, ValueError, KeyError) as e:
            orgs.append({"org": entry, "status": None, "why": f"{type(e).__name__}: {e}"})
    d = cm.read(orgs, now)
    if args.json:
        print(json.dumps(d, indent=2))
    if args.html:
        from . import dashboard as dash
        Path(args.html).write_text(dash.render_command_html(d, note=args.sample_note))
        print(f"wrote      {args.html}")
    if not args.json and not args.html:
        print(cm.render(d))
    return 2 if d["state"] == "RED" else (3 if d["state"] == "DARK" else 0)


def cmd_status(args) -> int:
    """`org status` (SPEC §13): what is stopped right now, read at call time. One clock read for the whole
    reading; every tile carries the tier it came from, and the footer says what it could not see."""
    import datetime as _dt

    import yaml as _yaml

    from . import status as stx
    from . import tempo as tp

    repo = Path(args.repo).resolve()
    manifest = _yaml.safe_load((repo / (args.manifest or "org.yaml")).read_text())
    now = _dt.datetime.fromisoformat(args.now.replace("Z", "+00:00")) if args.now else _dt.datetime.now(_dt.timezone.utc)

    def read(at) -> dict:
        """One reading at `at`. Called once for a render, and once per interval by the reader (`--serve`)."""
        since = args.since or (at - _dt.timedelta(days=float(args.days))).strftime("%Y-%m-%dT00:00:00Z")
        tiers = None
        if args.facts:
            files = [json.loads(Path(f).read_text()) for f in args.facts]
            facts = tp.merge_facts(files) if len(files) > 1 else files[0]
        elif args.store:
            from . import store as sto
            conn = sto.connect(sto.db_path(repo, args.db))
            facts = sto.facts_since(conn, manifest, since=since, now=at, repo=repo)
            tiers = {stx.BOARD: f"replayed from the store — {sto.counts(conn).get('record_snapshot', 0)} record snapshot(s) kept across wakes"}
        else:
            extra = json.loads(Path(args.extra).read_text()) if getattr(args, "extra", None) else {}
            facts = tp.gather(repo, manifest, since=since, triggers=extra.get("triggers"), sessions=extra.get("sessions"), now=at)
            if args.ingest:
                from . import store as sto
                got = sto.ingest(sto.connect(sto.db_path(repo, args.db)), facts)
                print(f"store      +{got['new_snapshots']} record snapshot(s), +{got['new_verdicts']} verdict(s)")
        return stx.status(facts, at, tiers=tiers)

    if args.serve:
        from . import serve as srv
        reader = srv.Reader(read, interval=float(args.interval), poll_ms=int(float(args.interval) * 1000 / 6) or 1000,
                            source=f"org status --serve, re-read every {args.interval}s")
        srv.serve(reader, host=args.host, port=int(args.port),
                  ready=lambda url: print(f"reading    {url}  — re-read at most every {args.interval}s; "
                                          f"the age on the page is the reading's, not the poll's. Ctrl-C to stop."))
        return 0

    st = read(now)
    if args.html:
        from . import dashboard as dash
        out = Path(args.html)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(dash.render_html(st, sample_note=args.sample_note, live=bool(args.live),
                                        source=args.source or "org status"))
        print(f"wrote      {out}  ({st['coverage']['measured']} of {st['coverage']['tiles']} tiles read)")
        if args.reading:
            r = Path(args.reading)
            r.parent.mkdir(parents=True, exist_ok=True)
            r.write_text(json.dumps(dash.reading_doc(st, source=args.source or "org status"), indent=1, ensure_ascii=False) + "\n")
            print(f"reading    {r}  — the document a live page reads; org-core writes files, never a store (rule 6)")
        return stx.exit_code(st)
    if args.json:
        print(json.dumps(st, indent=2, ensure_ascii=False))
    else:
        print(stx.render(st), end="")
    return stx.exit_code(st)


def cmd_store(args) -> int:
    """`org store` (SPEC §9): the derived index. It is not a source — `rebuild` reconstructs it from the
    committed facts files, which is also how check 7's drift question gets an answer."""
    from . import store as sto

    repo = Path(args.repo).resolve()
    conn = sto.connect(sto.db_path(repo, args.db))
    if args.store_cmd == "ingest":
        total = {"new_snapshots": 0, "new_verdicts": 0, "unkeyable_board_rows": 0}
        for f in args.facts:
            got = sto.ingest(conn, json.loads(Path(f).read_text()))
            for k in total:
                total[k] += got[k]
        print(f"ingested   {len(args.facts)} file(s): +{total['new_snapshots']} snapshot(s), +{total['new_verdicts']} verdict(s)"
              + (f", {total['unkeyable_board_rows']} board row(s) with no timestamp to key on" if total["unkeyable_board_rows"] else ""))
        return 0
    if args.store_cmd == "rebuild":
        got = sto.rebuild(conn, repo)
        print(f"rebuilt    from {got['files']} committed facts file(s): +{got['new_snapshots']} snapshot(s), +{got['new_verdicts']} verdict(s)")
        return 0 if got["files"] else 2
    c = sto.counts(conn)
    print(f"store      {sto.db_path(repo, args.db)}")
    for k in ("ingest", "record_snapshot", "pr", "pr_verdict"):
        print(f"  {k:<16} {c[k]}")
    return 0


def cmd_not_yet(args) -> int:
    print(f"`org {args.cmd}` is not implemented in org-core {__version__} ({NOT_YET[args.cmd]}). Exit 2 so nothing reads this as done.")
    return 2


def _repo_args(p: argparse.ArgumentParser, *, parent: bool) -> None:
    """`--repo`/`--manifest` on a command group's parent AND on each subcommand, so both orders parse:
    `org tempo --repo X dm …` and `org tempo dm --repo X …`. Reed's two reads of NumeroTech #210 (2026-09-20, row 91):
    every line the templates rendered put `--repo` after the subcommand — 19 new `setup status` lines and 18 `tempo`
    lines already on both orgs' main — and argparse rejected each with exit 2, so every role's `suite` read `{}` and every
    step-5 escalation failed on its first try. A subcommand's copy uses SUPPRESS so it never clobbers the parent's value."""
    if parent:
        p.add_argument("--repo", default=None)
        p.add_argument("--manifest", default=None, help="defaults to <repo>/org.yaml")
    else:
        p.add_argument("--repo", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
        p.add_argument("--manifest", default=argparse.SUPPRESS, help=argparse.SUPPRESS)


REPO_GROUPS = ("setup", "tempo", "checks", "tickets", "operator", "store")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="org", description="the org builder (see SPEC.md)")
    p.add_argument("--version", action="version", version=f"org-core {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("roles", help="list the role packages this org-core ships")
    s.set_defaults(fn=cmd_roles)

    s = sub.add_parser("validate", help="validate a manifest against the schema")
    s.add_argument("--manifest", default="org.yaml")
    s.set_defaults(fn=cmd_validate)

    s = sub.add_parser("render", help="render one role file to stdout")
    s.add_argument("role")
    s.add_argument("kind", choices=["agent", "skill"])
    s.add_argument("--manifest", default="org.yaml")
    s.set_defaults(fn=cmd_render)

    for name, fn, help_ in (("plan", cmd_plan, "what apply would do"), ("apply", cmd_apply, "render the manifest into the repo"),
                            ("upgrade", cmd_apply, "re-render an installed repo against a newer org-core; base sections replaced, project sections kept, migrations applied"),
                            ("fidelity", cmd_fidelity, "measure how far the repo's files are from the packages and record it")):
        s = sub.add_parser(name, help=help_)
        s.add_argument("--repo", required=True)
        s.add_argument("--manifest", default=None, help="defaults to <repo>/org.yaml")
        s.add_argument("--diff", action="store_true")
        s.add_argument("--adopt-existing", action="store_true", help="keep a pre-existing unmanaged role file verbatim as the project section beneath the package base")
        s.add_argument("--project-from", default=None, help="directory of <role>/agent.md and <role>/SKILL.md to seed project sections of files that do not exist yet")
        if name == "plan":
            s.add_argument("--json", action="store_true")
        if name in ("apply", "upgrade"):
            s.add_argument("--overwrite-changed", action="store_true")
        if name == "fidelity":
            s.add_argument("--out", required=True)
        s.set_defaults(fn=fn)

    s = sub.add_parser("lessons", help="the fleet's inflow, pulled (SPEC §11): what a repository wrote into its own ground truth since a watermark, and a digest for the curator")
    lsub = s.add_subparsers(dest="lessons_cmd", required=True)
    lp = lsub.add_parser("pull", help="every hunk in the ground-truth files since an ISO time or a commit, with provenance and the section it landed in")
    lp.add_argument("--repo", required=True)
    lp.add_argument("--manifest", default=None, help="defaults to <repo>/org.yaml; org-core itself has none")
    lp.add_argument("--since", required=True, help="ISO time, or a commit (everything after it)")
    lp.add_argument("--out", default=None, help="defaults to <repo>/.org/lessons/pull-<date>.json")
    lp.add_argument("--max-lines", type=int, default=400)
    lp.add_argument("--now", default=None)
    ld = lsub.add_parser("digest", help="a reading of one or more pulls: per org, per file, every hunk with its tags and added text")
    ld.add_argument("--facts", required=True, nargs="+")
    ld.add_argument("--min-added", type=int, default=1)
    ld.add_argument("--max-lines", type=int, default=60)
    ld.add_argument("--skip-tags", nargs="*", default=["stamp"])
    ld.add_argument("--skip-sections", nargs="*", default=[])
    ld.add_argument("--skip-subject-prefix", nargs="*", default=[], help="drop hunks from commits whose subject starts with any of these (e.g. 'org-core ' for an installer's re-renders)")
    ld.add_argument("--out", default=None)
    sd = lsub.add_parser("seed", help="append a reader's extraction table to the org's docs/ai/lessons.md as rows (ids <org>-<date>-<n>), with the curator's answered statuses")
    sd.add_argument("--repo", required=True)
    sd.add_argument("--manifest", default=None)
    sd.add_argument("--extraction", required=True, help="the reader's table (fleet/lessons/<date>-<org>-extraction.md)")
    sd.add_argument("--date", required=True, help="the pull date the ids carry")
    sd.add_argument("--org", default=None, help="defaults to the manifest's org id")
    sd.add_argument("--statuses", default=None, help="a lessons_status.json; defaults to the one shipped with org-core")
    br = lsub.add_parser("brief", help="the standard reader brief for one org's digest — the same instructions every time")
    br.add_argument("--org", required=True)
    br.add_argument("--digest", required=True)
    br.add_argument("--core", default="/home/user/org-core", help="where the reader checks what org-core already ships")
    br.add_argument("--out-path", required=True, help="where the reader writes its table")
    br.add_argument("--since", default=None)
    br.add_argument("--head", default=None)
    br.add_argument("--out", default=None, help="write the brief here instead of stdout")
    lg = lsub.add_parser("ledger", help="scaffold the curated ledger: watermarks and counts filled in, the judgment left blank")
    lg.add_argument("--pulls", required=True, nargs="+")
    lg.add_argument("--extractions", nargs="*", default=[], help="<org>=<path> per reader table")
    lg.add_argument("--date", required=True)
    lg.add_argument("--out", default=None)
    st = lsub.add_parser("status", help="read the curator's answers out of a ledger into org_core/lessons_status.json, which `org upgrade` writes into each org's rows")
    st.add_argument("--ledger", required=True)
    st.add_argument("--prefix", required=True, nargs="+", help="<letter>=<org>-<date>, e.g. N=numerotech-2026-09-19")
    st.add_argument("--out", default=None, help="defaults to the package's lessons_status.json")
    s.set_defaults(fn=cmd_lessons)
    s = sub.add_parser("setup", help="the suite install (SPEC §18): render the setup script, read the report a session start wrote, or probe what this container has")
    _repo_args(s, parent=True)
    ssub = s.add_subparsers(dest="setup_cmd", required=True)
    sr = ssub.add_parser("render", help="the generated .claude/hooks/org-setup.sh to stdout (apply writes it)")
    _repo_args(sr, parent=False)
    st = ssub.add_parser("status", help="the report the last session start wrote ($TMPDIR/org-setup-report.json); exit 3 when none — the script never ran here (a usage error is exit 2, kept distinct on purpose); --compact always exits 0 and prints {\"report\": \"absent\"} for none")
    _repo_args(st, parent=False)
    st.add_argument("--report", default=None, help="read this report file instead")
    st.add_argument("--compact", action="store_true", help="the versions alone, one JSON line, for a role's record")
    st.add_argument("--json", action="store_true")
    ck = ssub.add_parser("check", help="probe every module and the wiring now; exit 1 on any row that is not what the tree says")
    _repo_args(ck, parent=False)
    ck.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_setup)
    s = sub.add_parser("operator", help="the operator file (SPEC §9): render every role's three lines from the board — the chair runs it each wake and commits the file on main (rows 65, 98)")
    _repo_args(s, parent=True)
    osub = s.add_subparsers(dest="operator_cmd", required=True)
    orr = osub.add_parser("render", help="rewrite each role's `last run` / `outcome` / `blocked` from roles/<role>/last-run; everything else in the file is kept")
    _repo_args(orr, parent=False)
    orr.add_argument("--dry-run", action="store_true", help="print the changes, write nothing")
    orr.add_argument("--roles", default=None, help="comma-separated role ids (default: every enabled role with a section contract)")
    orr.add_argument("--dashboard", action="store_true", help="also write the org's own page (org.paths.dashboard, default docs/human/dashboard.html) from a live reading — this gathers over the network; the operator file does not")
    s.set_defaults(fn=cmd_operator)
    s = sub.add_parser("fleet", help="every installed org's default branch against this package (SPEC §11): installed version, since when it is behind, and the open upgrade PR if any — exit 1 when an org is behind with no upgrade open, 2 when one could not be read")
    s.add_argument("--repo", default=None, help="the org-core checkout (default: the one this package runs from) — its git log dates when the package moved past each org")
    s.add_argument("--registry", default=None, help="defaults to <repo>/fleet/orgs.yaml")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_fleet)
    s = sub.add_parser("vendor", help="write the running org-core as a wheel under .org/wheels/ so a cold session installs it with no credential (SPEC §6)")
    s.add_argument("--repo", required=True)
    s.add_argument("--hook", action="store_true", help="also print the session-start hook lines that install from the wheel")
    s.set_defaults(fn=cmd_vendor)
    s = sub.add_parser("tempo", help="the org's speed, measured — and the roles to wake before their cron tick (SPEC §13)")
    _repo_args(s, parent=True)
    tsub = s.add_subparsers(dest="tempo_cmd", required=True)
    g = tsub.add_parser("gather", help="read the board, the pull requests and the run ledgers into one facts file (read-only)")
    _repo_args(g, parent=False)
    g.add_argument("--since", required=True, help="ISO time; pull requests updated before it are ignored")
    g.add_argument("--facts", default=None, help="JSON with `triggers`/`sessions` from a session holding the sessions port, folded in")
    g.add_argument("--out", default=None, help="defaults to .org/tempo/facts-<date>.json")
    g.add_argument("--now", default=None, help="pin the reading's clock: one instant stamps the facts and ages everything read from them")
    r = tsub.add_parser("report", help="edge latencies vs targets, the PR cycle, handoffs, blocked fields, wakes and wake-now, from one or more facts files")
    _repo_args(r, parent=False)
    r.add_argument("--facts", required=True, nargs="+", help="facts files; several are merged (a week from a day's files)")
    r.add_argument("--now", default=None)
    r.add_argument("--json", action="store_true")
    w = tsub.add_parser("wake-now", help="gather live and list the roles whose events are past target — the read-only view of the plan")
    _repo_args(w, parent=False)
    w.add_argument("--facts", default=None, help="JSON with `triggers` from the session holding the sessions port (trigger ids and last fires)")
    w.add_argument("--since", default=None, help="ISO time; defaults to three days ago")
    w.add_argument("--now", default=None)
    w.add_argument("--json", action="store_true")
    t = tsub.add_parser("triggers", help="write the compact coord/tempo/triggers key from a list_triggers dump (once a day, not per wake)")
    _repo_args(t, parent=False)
    t.add_argument("--facts", required=True, help="the list_triggers JSON (or {triggers: [...]})")
    t.add_argument("--now", default=None)
    rg = tsub.add_parser("register", help="a persistent role's first act every wake: its agent id into coord/tempo/agents, and the deadline to park its listener until")
    _repo_args(rg, parent=False)
    rg.add_argument("--role", required=True)
    rg.add_argument("--session-id", default=None)
    rg.add_argument("--listen-minutes", type=float, default=None, help="defaults to tempo.listen_minutes (1440 — a day)")
    rg.add_argument("--now", default=None)
    dm = tsub.add_parser("dm", help="wake a receiver: a listening persistent role is DMed; a spawned/fresh role's DM is routed to the actuator (`wake <role>: …`), whose wake spawns it; a clock-only role (`on_demand: none` — the doctor, or a role the org opted out) is not woken — exit 0 delivered/routed, 1 unregistered, 2 absent (not sent), 3 clock-only")
    _repo_args(dm, parent=False)
    dm.add_argument("--role", required=True, help="the receiving role")
    dm.add_argument("text", nargs="+", help="the message — usually the handoff key")
    dm.add_argument("--now", default=None)
    pu = tsub.add_parser("park-until", help="the ISO time a listener parks until: now + tempo.listen_minutes (default a day)")
    _repo_args(pu, parent=False)
    pu.add_argument("--listen-minutes", type=float, default=None)
    pu.add_argument("--now", default=None)
    nf = tsub.add_parser("next-fire", help="the next cron fire of a role, ISO; exit 2 when it has no cron")
    _repo_args(nf, parent=False)
    nf.add_argument("--role", required=True)
    nf.add_argument("--now", default=None)
    wk = tsub.add_parser("wake", help="the actuator's four-call wake: plan (gather live, print the acts and the one-shot prompts) and record (ledger, heartbeat, lease)")
    wsub = wk.add_subparsers(dest="wake_cmd", required=True)
    wp = wsub.add_parser("plan")
    _repo_args(wp, parent=False)
    wp.add_argument("--facts", default=None, help="JSON with `triggers`; else the compact board key is read")
    wp.add_argument("--session-json", default=None, help="this session's get_session JSON (context tokens, cost) — needed for the rotate rule and the cost series")
    wp.add_argument("--inbox", default=None, help="this wake's `switchboard --json inbox` saved to a file: the routed `wake <role>: <event> <what>` DMs are acted on now, target or not")
    wp.add_argument("--since", default=None)
    wp.add_argument("--now", default=None)
    wp.add_argument("--out", default=None, help="defaults to .org/tempo/plan.json")
    wr = wsub.add_parser("record")
    _repo_args(wr, parent=False)
    wr.add_argument("--plan", required=True)
    wr.add_argument("--results", default=None, help="[{i, ok, id, readback, could_not}] per action index the session performed")
    wr.add_argument("--session-json", default=None)
    wr.add_argument("--now", default=None)
    wr.add_argument("--dry-run", action="store_true", help="print the row, heartbeat and lease; write nothing")
    s.set_defaults(fn=cmd_tempo)
    s = sub.add_parser("command", help="the fleet as one console, for the person it waits on: every org's "
                                       "operator queue, what each item is holding up, and the signal matrix (SPEC §9, §11)")
    s.add_argument("--repo", default=".")
    s.add_argument("--registry", help="defaults to <repo>/fleet/orgs.yaml")
    s.add_argument("--days", default=3, help="how far back each org's reading looks")
    s.add_argument("--extra", help="a JSON file carrying `sessions` from a session holding the sessions port")
    s.add_argument("--html", help="write the console as one self-contained page")
    s.add_argument("--sample-note", help="a banner naming the reading")
    s.add_argument("--now")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_command)

    s = sub.add_parser("status", help="what is stopped right now, read at call time — the chain, the chair, the roles, the wake chain (SPEC §13)")
    s.add_argument("--repo", default="."); s.add_argument("--manifest")
    s.add_argument("--facts", nargs="*", help="read committed facts files instead of gathering live")
    s.add_argument("--store", action="store_true", help="replay from the store, so board edges keep the history the board overwrites")
    s.add_argument("--db", help="store path (default <repo>/.org/status.db)")
    s.add_argument("--extra", help="a JSON file carrying `triggers`/`sessions` from a session holding the sessions port")
    s.add_argument("--since"); s.add_argument("--days", default=3, help="how far back to read when --since is absent")
    s.add_argument("--ingest", action="store_true", help="fold what this live reading saw into the store — the board is overwritten every wake (row 62)")
    s.add_argument("--html", help="write the same reading as one self-contained page")
    s.add_argument("--sample-note", help="a banner naming the reading as a replay or sample, never passed off as live")
    s.add_argument("--live", action="store_true", help="the page redraws when a newer reading reaches the store it watches; it still renders this one at rest")
    s.add_argument("--reading", help="also write the reading as one JSON document — what a live page reads")
    s.add_argument("--serve", action="store_true", help="serve the page and re-take the reading on an interval, the way switchboard's own viewer does")
    s.add_argument("--host", default="127.0.0.1", help="bind address (default local only: the reader holds the org's credentials)")
    s.add_argument("--port", default=8799)
    s.add_argument("--interval", default=30, help="seconds between reads — a live gather is 1 + 3N gh calls, so this is a floor, not a refresh rate")
    s.add_argument("--source", help="where this reading came from, shown in the page footer")
    s.add_argument("--now"); s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_status)

    s = sub.add_parser("store", help="the derived index over the sources (SPEC §9) — not a source: rebuild reconstructs it from the committed facts files")
    _repo_args(s, parent=True)
    s.add_argument("--db", default=None, help="store path (default <repo>/.org/status.db)")

    def _store_sub(sp):                       # --repo/--manifest/--db read the same either side (row 91)
        _repo_args(sp, parent=False)
        sp.add_argument("--db", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
        return sp

    st_ = s.add_subparsers(dest="store_cmd", required=True)
    i = _store_sub(st_.add_parser("ingest", help="fold one or more facts files into the store (idempotent)"))
    i.add_argument("--facts", nargs="+", required=True)
    _store_sub(st_.add_parser("rebuild", help="reconstruct from every committed .org/tempo/facts-*.json, oldest first"))
    _store_sub(st_.add_parser("counts", help="how many rows the store holds, per table"))
    s.set_defaults(fn=cmd_store)

    s = sub.add_parser("install", help="ONE COMMAND for a first install: init -> check the draft is filled -> apply -> verify. Run it again after each thing it asks for.")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.set_defaults(fn=cmd_install)

    s = sub.add_parser("init", help="detect what a repo has; --write a draft manifest")
    s.add_argument("--repo", required=True)
    s.add_argument("--write", action="store_true")
    s.add_argument("--force", action="store_true")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("doctor", help="run the health checks (SPEC §8)")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.add_argument("--facts", default=None, help="JSON with `triggers` and/or `sessions` gathered by a session holding the sessions port")
    s.add_argument("--only", default=None, help="comma-separated check numbers")
    s.add_argument("--drill", default=None, help="read this role's record as absent (the dead-role drill)")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_doctor)

    s = sub.add_parser("routine", help="the trigger spec a clock role needs (SPEC §5/§6) — create it on the org account")
    s.add_argument("role")
    s.add_argument("--manifest", default="org.yaml")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_routine)

    s = sub.add_parser("verify", help="prove an install works, including the dead-role drill (SPEC §7)")
    s.add_argument("--repo", required=True)
    s.add_argument("--manifest", default=None)
    s.add_argument("--facts", default=None)
    s.add_argument("--drill", default="random", help="role to kill at the read layer; default random")
    s.add_argument("--no-drill", action="store_true")
    s.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_verify)

    s = sub.add_parser("record", help="validate a run record JSON file")
    s.add_argument("file")
    s.set_defaults(fn=cmd_record)

    s = sub.add_parser("record-from-doctor", help="build the doctor's run record from `org doctor --json` output (one JSON line, validated)")
    s.add_argument("report")
    s.add_argument("--repo", required=True)
    s.add_argument("--runtime", default="fresh", choices=["fresh", "session", "spawned"])
    s.add_argument("--session-id", default=None)
    s.add_argument("--pr", default=None)
    s.add_argument("--next-due", default=None)
    s.set_defaults(fn=cmd_record_from_doctor)

    s = sub.add_parser("tickets", help="the tickets port for a github-issues org: labels + issue form (SPEC §16 decision 4)")
    _repo_args(s, parent=True)
    ts = s.add_subparsers(dest="tickets_cmd", required=True)
    _repo_args(ts.add_parser("status", help="github-issues intake: which declared labels exist, and whether the issue form is in the tree"), parent=False)
    t = ts.add_parser("init", help="github-issues intake: create every missing label (idempotent) and write the issue form if absent")
    _repo_args(t, parent=False)
    t.add_argument("--dry-run", action="store_true")
    t = ts.add_parser("sql", help="the read-only SELECTs a role runs through the read port to get the rows")
    _repo_args(t, parent=False)
    t.add_argument("--dialect", choices=["generic", "lucille"], default="generic")

    def _rows_opts(p):
        p.add_argument("--tickets", default=None, help="rows JSON saved from the read port (a list, or {tickets: [...]})")
        p.add_argument("--notes", default=None, help="notes rows JSON (optional)")
        p.add_argument("--items", default=None, help="roadmap items: a directory of YAML (files mode) or a JSON dump; default <repo>/roadmap/items")
        p.add_argument("--source", choices=["file", "psql", "api"], default=None, help="default: file when --tickets is given, api when --url, psql when --dsn-env")
        p.add_argument("--dsn-env", default=None); p.add_argument("--url", default=None); p.add_argument("--token-env", default=None)
        p.add_argument("--dialect", choices=["generic", "lucille"], default="generic")
        p.add_argument("--now", default=None, help="ISO-8601, for reproducible runs")
        p.add_argument("--assume-complete", action="store_true", help="the rows file is the whole table (enables dangling_link)")
        p.add_argument("--json", action="store_true")

    t = ts.add_parser("stage", help="one ticket, across every layer"); t.add_argument("--id", required=True); _rows_opts(t)
    _repo_args(t, parent=False)
    t = ts.add_parser("open-loops", help="every place the pipeline stopped without finishing (exit 2 on any finding)"); _rows_opts(t)
    _repo_args(t, parent=False)
    t = ts.add_parser("report", help="the pipeline digest: stages, open loops"); t.add_argument("--write", action="store_true"); _rows_opts(t)
    _repo_args(t, parent=False)
    t = ts.add_parser("impact", help="an item's linked tickets, before/after it was called done (exit 2 on any after)"); t.add_argument("key"); _rows_opts(t)
    _repo_args(t, parent=False)
    s.set_defaults(fn=cmd_tickets)

    s = sub.add_parser("checks", help="checks-core: a production checks registry (SPEC §4 checks port)")
    _repo_args(s, parent=True)
    s.add_argument("--registry", default=None)
    s.add_argument("--ledger", default=None)
    s.add_argument("--results", default=None)
    s.add_argument("--today", default=None, help="YYYY-MM-DD; defaults to today UTC")
    cs = s.add_subparsers(dest="checks_cmd", required=True)
    _repo_args(cs.add_parser("validate", help="registry well-formed, queries read-only, ledger consistent (a LOST check is a finding)"), parent=False)
    c = cs.add_parser("plan", help="which checks are due today, with their SQL")
    _repo_args(c, parent=False)
    c.add_argument("--json", action="store_true")
    c = cs.add_parser("evaluate", help="verdicts from a rows file {check_id: row | {error}}; nothing recorded")
    _repo_args(c, parent=False)
    c.add_argument("--rows", required=True)
    c = cs.add_parser("record", help="evaluate a rows file, append the results log, optionally file/retire GitHub issues")
    _repo_args(c, parent=False)
    c.add_argument("--rows", required=True)
    c.add_argument("--file-issues", action="store_true")
    c.add_argument("--dry-run", action="store_true")
    c.add_argument("--no-gh", action="store_true", help="with --dry-run: do not call gh at all")
    c = cs.add_parser("run", help="plan → execute through psql (read-only, time-bounded) → record")
    _repo_args(c, parent=False)
    c.add_argument("--executor", default="psql")
    c.add_argument("--dsn-env", default=None)
    c.add_argument("--file-issues", action="store_true")
    c.add_argument("--dry-run", action="store_true")
    c.add_argument("--no-gh", action="store_true")
    c = cs.add_parser("report", help="what the checks-watch role reads: counts, oldest failure, unowned failures, vacuous passes, expiries, worsening")
    _repo_args(c, parent=False)
    c.add_argument("--json", action="store_true")
    s.set_defaults(fn=cmd_checks)

    for name in NOT_YET:
        s = sub.add_parser(name, help=f"not implemented: {NOT_YET[name]}")
        s.add_argument("rest", nargs="*")
        s.set_defaults(fn=cmd_not_yet)
    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "cmd", None) in REPO_GROUPS and getattr(args, "repo", None) is None:
        parser.error(f"org {args.cmd}: --repo is required (before or after the subcommand)")
    if hasattr(args, "repo") and getattr(args, "manifest", "org.yaml") is None:
        args.manifest = str(Path(args.repo) / "org.yaml")
    try:
        return args.fn(args)
    except ManifestError as e:
        print(str(e))
        return 1
    except FileNotFoundError as e:
        print(f"missing: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
