"""`org routine <role>`: the trigger a clock role needs, as a spec (SPEC.md §5, §6 "manual steps are real steps").

The tool does not create it. A session holding the sessions port can create the
trigger itself (measured 2026-09-17: seven created from a CEO session), but what
the fired session will hold cannot be set that way: `create_trigger` refuses the
`connectors` parameter on this organization ("not available for this
organization"), a routine created through it stores no connectors even when the
creating session holds them, it has no `sources` parameter, and a persistent
session binding is fixed at creation (`update_trigger` cannot change it). So the
deliverable is a spec precise enough that creating it is one action, plus the
web-UI steps that finish it and the verification that proves each took.
"""

from __future__ import annotations

from typing import Any

from .manifest import flat_vars
from .render import render_base
from .roles import RolePackage

DEFAULT_PROMPT = """You are {[ role.name ]}, the {[ role_id ]} of the {[ org_id ]} org.

Read `.claude/agents/{[ role_id ]}.md`, then invoke the `{[ role_id ]}` skill and follow it end to end.
Write your run record on every run, including a run that finds nothing — a missing record is read as this role having died.

Repository: {[ repo_url ]}, expected at `{[ checkout ]}`. This routine must carry it as a source; if there is no checkout there, stop, write a record with `blocked` saying so, and do nothing else.
{% if role.runtime == 'session' %}
You are a persistent agent (SPEC §5): this routine is your cron floor, and a DM to your parked listener is the other way you wake. First `org tempo --repo {[ checkout ]} register --role {[ role_id ]}`, then `switchboard --json inbox` — a message naming a handoff key or a PR is the reason you are awake; act on it first. Before you end this turn, unless `register` answered `listener_alive: true` (the one parked last turn is still running and will wake you), park the listener again for a day: `switchboard listen --until "$(org tempo --repo {[ checkout ]} park-until)"`, run with your runner's background mechanism (never `&` or `nohup`) — its exit is your next wake.
{% endif %}"""


def spec(manifest: dict[str, Any], packages: dict[str, RolePackage], role_id: str) -> dict[str, Any]:
    entry = manifest["roles"][role_id]
    pkg = packages[role_id]
    runtime = entry.get("runtime")
    if runtime == "spawned":
        raise ValueError(f"{role_id} runs on demand (spawned); it has no trigger")
    cadence = entry.get("cadence")
    if not cadence or cadence in ("on-demand", "on-wake"):
        raise ValueError(f"{role_id} has no cron cadence ({cadence!r}); a trigger needs one")
    ctx = flat_vars(manifest)
    ctx["role"] = entry
    ctx["role_id"] = role_id
    tpl = pkg.dir / "prompt.routine.md"
    prompt = render_base(tpl.read_text() if tpl.exists() else DEFAULT_PROMPT, ctx)
    connectors = list(entry.get("connectors") or pkg.contract.get("needs", {}).get("connectors", []) or [])
    report_key = entry.get("report_key") or f"roles/{role_id}/last-run"
    steps = [
        {"step": f"create the routine on the org account ({manifest['org'].get('account', '<org account>')}) — from a session holding the sessions port, or from the claude.ai routines UI",
         "verify": "org doctor --only 5 --facts <triggers dump> reports PASS"},
        {"step": f"attach the repository {ctx['repo_url']} as a source (web UI; create_trigger has no sources parameter)",
         "verify": f"org doctor --only 3 --facts <triggers dump> shows no 'sources: []' for {role_id}"},
    ]
    if connectors:
        steps.append({"step": f"add the connectors {connectors} in the web UI (create_trigger's connectors parameter is refused on this organization, and a routine created through it stores none — measured 2026-09-17)",
                      "verify": f"the routine's mcp_connections is not [] in the triggers dump; the first record at {report_key} carries no could_not_reach for them"})
    if runtime == "session":
        steps.insert(0, {"step": f"start the persistent session for {entry['name']} by hand from claude.ai on the org account, with the repository attached, then create the routine bound to it (persistent_session_id is fixed at creation; update_trigger cannot change it)",
                         "verify": f"org doctor --only 4 --facts <triggers+sessions dump> reports PASS for {role_id}"})
    steps.append({"step": "wait for the first fire", "verify": f"a record appears at {report_key}; org doctor --only 1 reports PASS for {role_id}"})
    return {
        "role": role_id,
        "name": f"{entry['name']} — {role_id} · {ctx['org_id']}",   # the org tag is what the doctor matches on when two orgs share an account
        "runtime": runtime,
        "cron_expression": cadence,
        "create_new_session_on_fire": runtime == "fresh",
        "persistent_session_id": None if runtime == "fresh" else "<the session started by a human on the org account>",
        "sources": [ctx["repo_url"]],
        "connectors": connectors,
        "report_key": report_key,
        "prompt": prompt,
        "manual_steps": steps,
    }


def render_text(s: dict[str, Any]) -> str:
    lines = [
        f"routine for {s['role']} ({s['runtime']})",
        f"  name:                        {s['name']}",
        f"  cron_expression (UTC):       {s['cron_expression']}",
        f"  create_new_session_on_fire:  {str(s['create_new_session_on_fire']).lower()}",
    ]
    if s["persistent_session_id"]:
        lines.append(f"  persistent_session_id:       {s['persistent_session_id']}")
    lines.append(f"  sources:                     {', '.join(s['sources'])}   (attach in the web UI)")
    lines.append(f"  connectors:                  {', '.join(s['connectors']) or 'none'}")
    lines.append(f"  first record expected at:    {s['report_key']}")
    lines.append("  prompt:")
    lines.extend("    | " + line for line in s["prompt"].rstrip("\n").split("\n"))
    lines.append("  manual steps, each with the check that proves it took:")
    for i, st in enumerate(s["manual_steps"], 1):
        lines.append(f"    {i}. {st['step']}")
        lines.append(f"       verify: {st['verify']}")
    return "\n".join(lines)
