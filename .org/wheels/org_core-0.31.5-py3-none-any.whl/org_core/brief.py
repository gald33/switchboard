"""The same reading, for somebody who does not know how org-core works (SPEC §9).

`org status` is an **instrument**. Every line names the mechanism it measured — `handoff_received`, `suite`,
`row 62`, the tier each number came from — because a finding that cannot be traced to its source is not a
measurement, and most of Appendix A is the record of what happens when one is. That is the right shape for the
terminal and for the person maintaining the tool.

It is the wrong shape for the page. Measured 2026-09-22: the operator opened the published dashboard and could
not use it. The words on it are the tool's words — the reader wanted to know what is stopped, who can move it,
and what needs them, and every line answered in the vocabulary of the machine that measured it.

So this module translates, and only translates. Three rules keep it honest:

1. **It reads `status()["subjects"]`, never the tiles' prose.** A surface that parses another surface's
   sentences is two readings that drift, and this file has already paid for that twice (rows 119, 121).
2. **It adds no judgement.** Every plain sentence is a restatement of a finding the reading already made; the
   states are the reading's own, and a `DARK` subject becomes "not checked", never "fine".
3. **Every finding is translated or the tests fail.** A finding kind with no plain sentence is the same defect
   as a check that cannot fail (CLAUDE.md rule 2), read from the reader's side.

The grouping is the whole point: **by who can clear it**, not by which mechanism found it. A person opening
this page is themselves one of the three answers, and until now that was the one thing the page never said.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from . import tempo as tp
from .status import CLEAR, DARK, RED

#: who can actually clear a finding. The page is grouped by this and nothing else, because it is the only
#: question its reader has: the org cannot move `you`, and no person can move `machinery` by answering it.
YOU, TEAM, MACHINERY, UNCHECKED = "you", "team", "machinery", "unchecked"
#: a fourth tone, for a thing that is waiting but not yet overdue. It cannot be `CLEAR`: green means resolved,
#: and every row in the reader's own queue is unresolved by definition — the young ones are just not late yet.
OPEN = "OPEN"
#: how many rows a group shows before the rest fold away. The page's job is the SHAPE of the situation —
#: 25 rows of one group is an enumeration, and the reader stops at about the third. Nothing is dropped: the
#: rest are one click down, and the instrument below still carries every finding in the tool's own words.
SECTION_ROWS = 3
SECTIONS = {
    YOU: ("Waiting on you", "Nobody in the org can clear these — they were written for a person."),
    TEAM: ("Stuck inside the team", "A role could move each of these, and none of them has."),
    MACHINERY: ("The machinery that runs it", "Plumbing, not work. While it is broken the org runs on its clocks alone."),
    UNCHECKED: ("Not checked", "This reading could not see these. Not measured is neither fine nor broken."),
}


def ago(hours: float | None) -> str:
    """A duration a person reads without arithmetic. `None` when the reading has no clock for it."""
    if hours is None:
        return ""
    if hours < 1:
        m = max(1, round(hours * 60))
        return f"{m} minute{'s' if m != 1 else ''}"
    if hours < 36:                      # above this, hours and days appear side by side in one list and read
        h = round(hours)                # as two different measurements of the same span
        return f"{h} hour{'s' if h != 1 else ''}"
    d = hours / 24
    return "1 day" if d < 1.5 else f"{round(d)} days"


def _sentence(text: str) -> str:
    """One sentence from a fragment the tool wrote. `str.capitalize()` lower-cases everything after the first
    letter, which turned `ci red: pytest` into `Ci red: pytest` — only the first character moves."""
    t = " ".join(str(text or "").split())
    if not t:
        return ""
    t = t[0].upper() + t[1:]
    return t if t.endswith((".", "!", "?")) else t + "."


#: `needs_action` writes the tool's shorthand (`ci red: pytest`). Capitalising it yields `Ci red: pytest`;
#: these are the sentences a person would say instead.
WHY_PR = (("ci red: ", "CI is failing ({})"), ("status failure: ", "a required check failed ({})"),
          ("conflicted", "it has merge conflicts"), ("changes requested", "a reviewer asked for changes"))


def why_pr(reasons: list[str]) -> str:
    """Why an open pull request is waiting on somebody, in words. Anything unmapped is passed through rather
    than dropped: a reason nobody translated is still a reason, and silence would be the worse failure."""
    out = []
    for r in reasons or []:
        for prefix, plain in WHY_PR:
            if r == prefix:
                out.append(plain)
                break
            if prefix.endswith(": ") and r.startswith(prefix):
                out.append(plain.format(r[len(prefix):]))
                break
        else:
            out.append(r)
    return _sentence(" and ".join(out)) if out else ""


def _name(subjects: dict[str, Any], role: str) -> str:
    """`Reed (reviewer)` — the org named its roles, and a reader knows them by those names."""
    n = (subjects.get("names") or {}).get(role)
    return f"{n} ({role})" if n and n.lower() != role.lower() else role


def _item(what: str, why: str = "", *, quote: str = "", hours: float | None = None, at: str = "",
          tone: str = RED, source: str = "", rank: int = 5, clause: str = "") -> dict[str, Any]:
    """`hours` is kept beside `ago`, because sorting on the sentence means parsing it back — which is the
    mistake this whole module exists to stop making. `rank` orders a group where age does not: a dead
    scheduler outranks a role that went quiet an hour earlier. `clause` is the same fact as a lower-case
    fragment, so the verdict can splice it without doing surgery on a proper noun."""
    return {"what": what, "why": why, "quote": quote, "ago": ago(hours), "hours": hours, "at": at,
            "tone": tone, "source": source, "rank": rank, "clause": clause or what}


def _you(s: dict[str, Any]) -> list[dict[str, Any]]:
    """The operator queue: the org's roles cannot touch it, which is why it is first and why it ages fastest."""
    out = []
    for q in s.get("queue") or []:
        days = q.get("age_days")
        head = str(q.get("head") or "").strip()
        who, sep, rest = head.partition(": ")
        if sep and who in (s.get("names") or {}) or who == "chair":
            head = rest or head                       # `chair: <ask>` is the key's shape, not the ask
            who = _name(s, "ceo") if who == "chair" else _name(s, who)
        else:
            who = ""
        where = ("your state-of-the-org file" if str(q.get("source", "")).endswith(".md")
                 else f"the record {who or 'the chair'} last wrote" if "blocked" in str(q.get("source", ""))
                 else f"the queue the roles write to{f', by {who}' if who else ''}")
        # the headline names the thing; the body says what it is and what it is waiting for. A row with only
        # the first is a label, and a page of labels is what "hard to understand from those titles" means.
        undated = ("" if days is not None else
                   " It carries no date, and nothing in this checkout can say when it was written — so its "
                   "age here is unknown, not zero.")
        out.append(_item(_sentence(head),
                         (str(q.get("body") or "").strip() or f"Written in {where}.") + undated,
                         hours=(days * 24) if days is not None else None,
                         at=str(q.get("since") or ""),
                         tone=RED if (days or 0) >= float(s.get("queue_alarm_days") or 3) else
                              (DARK if days is None else OPEN),
                         source=f"WAITING ON A PERSON {days}d ({q.get('source')})"))
    ow = s.get("operator_file")
    if isinstance(ow, dict) and not ow.get("has_section"):
        out.append(_item("There is nowhere for the org to write to you",
                         f"{ow.get('file')} has no “Waiting on the operator” section, so anything a role "
                         "needs from you has no place to land.", source="NO OPERATOR SURFACE"))
    return out


def _team(s: dict[str, Any]) -> list[dict[str, Any]]:
    """What a role could move. Each item names the role, because the reader's next question is always "who"."""
    out: list[dict[str, Any]] = []
    unfwd = {r: g for g in (s.get("unforwarded") or []) for r in g["roles"]}
    # the chair's blocked field is also an operator-queue row, so the same ask arrives here and in `you`.
    # It belongs to whoever can clear it, and that is the reader — printing it twice is row 118 in prose.
    from .status import ask_key
    on_your_list = {ask_key(q.get("head", "").split(": ", 1)[-1]) for q in (s.get("queue") or [])}
    for g in s.get("blocked") or []:
        if ask_key(g.get("text")) in on_your_list:
            continue
        roles = ", ".join(_name(s, r) for r in g["roles"])
        never = [r for r in g["roles"] if r in unfwd]
        out.append(_item(f"{roles} reported being stuck" if len(g["roles"]) == 1 else
                         f"{len(g['roles'])} roles reported the same blocker",
                         ("Nobody passed it on to you, so it is stuck twice over." if never else
                          "It reached the queue you read.") + ("" if len(g["roles"]) == 1 else f" ({roles}.)"),
                         quote=str(g.get("text") or ""), source="BLOCKED " + ", ".join(g["roles"])))
    for g in s.get("handoffs", {}).get("groups") or []:
        to, n, oldest = _name(s, g["to"]), g["n"], g["oldest"]
        senders = ", ".join(_name(s, x) for x in g["senders"])
        if g["why"]:
            out.append(_item(f"{n} message{'s' if n != 1 else ''} to {to} that nobody will ever pick up",
                             f"{to} only wakes for certain events and has no listener running, so this channel "
                             f"reaches nothing. Sent by {senders}.",
                             hours=oldest.get("waiting_hours"),
                             at=str(oldest.get("written_at") or ""), source=f"UNREACHABLE {n} to {g['to']}"))
        else:
            out.append(_item(f"{n} message{'s' if n != 1 else ''} to {to} waiting to be picked up",
                             f"{to} can be reached — it has not acted. Sent by {senders}.",
                             hours=oldest.get("waiting_hours"),
                             at=str(oldest.get("written_at") or ""), source=f"NOT RECEIVED {n} to {g['to']}"))
    ch = s.get("chair") or {}
    for x in ch.get("stale") or []:
        out.append(_item(f"Pull request #{x['number']} needs someone to act",
                         why_pr(x.get("why") or []) +
                         " Nothing wakes the role that opened it for this.",
                         hours=x.get("idle_hours"), at=str(x.get("updated_at") or ""),
                         source=f"NEEDING ACTION #{x['number']}"))
    silent = [r for r in (s.get("roles") or []) if not r.get("record_at")]
    stale = sorted((r for r in (s.get("roles") or []) if r.get("record_at")),
                   key=lambda r: -(r.get("age_hours") or 0))
    if len(stale) >= 2:
        # eight rows saying "its last record is older than its own schedule allows" is one fact eight times,
        # and a reader stops reading at about the third (row 118, now in the half a person actually reads)
        who = ", ".join(_name(s, r["role"]) for r in stale)
        out.append(_item(f"{len(stale)} roles have stopped reporting",
                         f"{who}. Each one's last record is older than its own schedule allows — the oldest "
                         f"{ago(stale[0].get('age_hours'))}, the newest {ago(stale[-1].get('age_hours'))}.",
                         hours=stale[0].get("age_hours"), at=str(stale[0].get("record_at") or ""),
                         clause=f"{len(stale)} roles have stopped reporting",
                         source="DEAD " + ", ".join(r["role"] for r in stale)))
    else:
        for r in stale:
            out.append(_item(f"{_name(s, r['role'])} has stopped reporting",
                             r.get("history") or "Its last record is older than its own schedule allows.",
                             hours=r.get("age_hours"), at=str(r.get("record_at") or ""),
                             source=f"{r['state'].upper()} {r['role']}"))
    if silent:   # one cause, one fix — the same collapse the instrument makes (row 118)
        who = ", ".join(_name(s, r["role"]) for r in silent)
        hist = {r.get("history") or "" for r in silent}
        out.append(_item(f"{len(silent)} roles have never reported" if len(silent) > 1 else
                         f"{_name(s, silent[0]['role'])} has never reported",
                         (f"{who}. " if len(silent) > 1 else "")
                         + (hist.pop() if len(hist) == 1 and next(iter(hist), "") else
                            "There is no record from any of them — they never ran, or they ran and could not "
                            "write. Nothing here can tell those apart." if len(silent) > 1 else
                            "There is no record from it — it never ran, or it ran and could not write. "
                            "Nothing here can tell those apart."),
                         source="DEAD/ABSENT " + ", ".join(r["role"] for r in silent)))
    return out


def _machinery(s: dict[str, Any]) -> list[dict[str, Any]]:
    """Plumbing. A person can fix it, but answering it is not the fix — restarting the thing is."""
    out: list[dict[str, Any]] = []
    a = s.get("actuator") or {}
    if a.get("missing"):
        who = ", ".join(_name(s, r) for r in a.get("routed") or [])
        out.append(_item(f"Nothing can start {who}",
                         f"They only run when the scheduler starts them, and the role that would be the scheduler "
                         f"({a.get('role')}) is switched off in this org. They run only if a person starts them.",
                         rank=0, clause=f"nothing can start {who}", source="NO ACTUATOR"))
    elif a.get("needed") is False:
        pass    # an org that asks nothing of a scheduler is not missing one (org-core, 2026-09-23)
    elif a.get("read") and not a.get("heartbeat"):
        out.append(_item("The scheduler that wakes the team is not running",
                         "Nothing is being triggered automatically. Every role moves only when its own clock "
                         "fires or a person starts it — which is why work can sit for days with nobody on it."
                         + ("" if a.get("wakes") else " It has never run at all."),
                         rank=0, clause="the scheduler that wakes the team is not running",
                         source="DEAD actuator"))
    for f in a.get("fired_no_receiver") or []:
        out.append(_item(f"{_name(s, str(f.get('role')))} was woken and never answered",
                         "The scheduler started it and nothing came back.", hours=f.get("age_hours"),
                         source=f"FIRED-NO-RECEIVER {f.get('role')}"))
    for role in a.get("suppressed") or []:
        out.append(_item(f"{_name(s, str(role))} is no longer being woken",
                         "It lost too many wakes in a row, so the scheduler stopped trying.",
                         source=f"SUPPRESSED {role}"))
    ls = s.get("listeners") or {}
    never, lapsed = ls.get("never") or [], ls.get("lapsed") or []
    if never:
        out.append(_item(f"{len(never)} role{'s' if len(never) != 1 else ''} can't be reached at all",
                         rank=1,
                         why="They have never checked in, so nothing can be routed to them: "
                             + ", ".join(_name(s, l["role"]) for l in never) + ".",
                         clause=f"{len(never)} role{'s' if len(never) != 1 else ''} cannot be reached at all",
                         source="NEVER REGISTERED " + ", ".join(l["role"] for l in never)))
    for l in lapsed:
        out.append(_item(f"{_name(s, l['role'])} has gone quiet",
                         "It checked in, but it is not on the roster now — whatever was listening has stopped.",
                         hours=l.get("registered_age_hours"), source=f"NOT LISTENING {l['role']}"))
    v = s.get("versions") or {}
    if v.get("read") and v.get("behind"):
        n, total = len(v["behind"]), len(v["behind"]) + len(v.get("ok") or [])
        out.append(_item(f"{n} of {total} roles are not running the installed version" if n != 1 else
                         f"1 of {total} roles is not running the installed version",
                         f"The version installed here is {v.get('lock')}. "
                         + "; ".join(
                             (f"{_name(s, b['role'])} is on {b['got']}" if b["cause"] == "behind" else
                              f"{_name(s, b['role'])} never said which version it ran")
                             for b in v["behind"][:6])
                         + ". A role on an older version is following older instructions.",
                         source="BEHIND / NO SUITE"))
    sp = s.get("spend") or {}
    for r in sp.get("stopped") or []:
        out.append(_item("A session is stopped waiting for permission",
                         f"“{r.get('needs') or 'a permission prompt'}” — nobody unattended can answer it, and it "
                         f"has cost ${r.get('cost', 0):.0f} so far. A person answers it or stops it.",
                         quote=str(r.get("title") or ""), hours=r.get("hours"),
                         source="BLOCKED ON A PROMPT"))
    return out


def _unchecked(st: dict[str, Any], s: dict[str, Any]) -> list[dict[str, Any]]:
    """Every dark tile, said plainly. "Not measured" must read as neither fine nor broken (rows 62, 65)."""
    plain = {
        "spend": ("what the org is costing", "the list of sessions this reading could take does not include "
                                             "this org's, so no figure here would be its spend"),
        "chair": ("whether anything is shipping", "its pull requests could not be read"),
        "versions": ("which version each role is running", "the installed version or the roles' records "
                                                           "could not be read"),
        "people": ("part of what waits on you", "one of the two places it is written could not be read"),
        "handoffs": ("whether messages were picked up", "a message is picked up on its pull request, and those "
                                                        "could not be read"),
        "listeners": ("which roles are reachable", "the roster could not be read"),
        "roles": ("whether each role is reporting on time", "the board could not be read"),
        "blocked": ("what the roles say is blocking them", "the board could not be read"),
        "actuator": ("whether the scheduler is running", "the board could not be read"),
        "chain": ("how fast work moves", "one of its sources could not be read"),
    }
    out = []
    for t in st.get("tiles") or []:
        if t["state"] != DARK:
            continue
        what, why = plain.get(t["id"], (t["title"], "this reading could not read its source"))
        out.append(_item(f"Not checked: {what}", _sentence(why), tone=DARK, source=f"DARK {t['id']}"))
    return out


def _numbers(st: dict[str, Any], s: dict[str, Any], sections: dict[str, list[dict[str, Any]]]) -> list[dict[str, Any]]:
    """Four figures, and only where the figure is the point. Each says what it is, not which key it came from."""
    ch = s.get("chair") or {}
    out = []
    if ch.get("read"):
        h = ch.get("hours_since_last_merge")
        out.append({"label": "Last shipped", "value": ago(h) + " ago" if h is not None else "nothing yet",
                    "note": f"{ch.get('merged') or 0} merged in this window", "tone": CLEAR if (h or 0) < 24 else RED})
    else:
        out.append({"label": "Last shipped", "value": "not checked", "note": "pull requests were not read", "tone": DARK})
    q = s.get("queue") or []
    oldest = max((x.get("age_days") or 0) for x in q) if q else 0
    partial = len(s.get("queue_halves") or []) < 2   # the queue is written in two places; both, or it is a floor
    if partial and not q:
        # "0" over a source nobody read is the reassuring lie this whole reading is built to refuse
        out.append({"label": "Waiting on you", "value": "not checked",
                    "note": "one of the two places it is written could not be read", "tone": DARK})
    else:
        out.append({"label": "Waiting on you", "value": (f"{len(q)} or more" if partial else str(len(q))),
                    "note": ("one of the two places it is written could not be read" if partial else
                             f"oldest {ago(oldest * 24)}" if q else "nothing"),
                    "tone": DARK if partial else (RED if q else CLEAR)})
    out.append({"label": "Stuck in the team", "value": str(len(sections[TEAM])),
                "note": "each has a role that could move it" if sections[TEAM] else "nothing",
                "tone": RED if sections[TEAM] else CLEAR})
    v = s.get("versions") or {}
    if v.get("read"):
        n, total = len(v.get("behind") or []), len(v.get("behind") or []) + len(v.get("ok") or [])
        if not total:
            # `0 of 0` in the pass colour is a check that cannot fail wearing a figure: no role has written a
            # record, so there is nothing to compare, and that is not agreement (org-core's own page, 2026-09-22)
            out.append({"label": "On the installed version", "value": "no records yet",
                        "note": f"version {v.get('lock')} is installed; no role has written a record to read",
                        "tone": DARK})
        else:
            out.append({"label": "On the installed version", "value": f"{total - n} of {total}",
                        "note": f"version {v.get('lock')}", "tone": CLEAR if not n else RED})
    else:
        out.append({"label": "On the installed version", "value": "not checked",
                    "note": "the records or the lock were not read", "tone": DARK})
    return out


def _verdict(st: dict[str, Any], s: dict[str, Any], sections: dict[str, list[dict[str, Any]]]) -> str:
    """One sentence a person can act on, built from the worst thing each group holds — never a finding's own
    wording, which is what made the old headline (`DEAD actuator: no heartbeat at coord/tempo/actuator`) useless."""
    if all(t["state"] == DARK for t in st.get("tiles") or [{}]):
        return "This reading could not see the org at all — every source it tried was unreachable."
    ch = s.get("chair") or {}
    h = ch.get("hours_since_last_merge")
    if not ch.get("read"):
        lead = "Whether anything is shipping could not be checked"
    elif h is None:
        lead = "Nothing has shipped in this window"
    elif h < 24:
        lead = f"Work is shipping — the last merge was {ago(h)} ago"
    else:
        lead = f"Nothing has shipped for {ago(h)}"
    # one sentence, not a summary of the whole page: the figures beside it carry the counts, and repeating
    # them here made the reader read the same three numbers twice before reaching anything new.
    worst = (sections[MACHINERY] or sections[YOU] or sections[TEAM] or [None])[0]
    if worst is None:
        return _sentence(lead) + (f" {len(sections[UNCHECKED])} thing(s) could not be checked."
                                  if sections[UNCHECKED] else " Nothing is stopped.")
    tail = worst["clause"]
    if worst in sections[YOU]:
        tail = f"the oldest thing waiting on you has been waiting {worst['ago']}" if worst.get("ago") else tail
    return _sentence(lead) + " " + _sentence(tail[0].upper() + tail[1:])


def brief(st: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """The reading as a person reads it. Pure over the status dict; reaches nothing and decides nothing."""
    s = st.get("subjects") or {}
    grouped = {YOU: _you(s), TEAM: _team(s), MACHINERY: _machinery(s), UNCHECKED: _unchecked(st, s)}
    for items in grouped.values():
        items.sort(key=lambda i: (i["tone"] != RED, i["rank"], -(i["hours"] or 0)))
    states = [t["state"] for t in st.get("tiles") or []]
    state = RED if RED in states else (DARK if DARK in states else CLEAR)
    sections = []
    for k in (YOU, TEAM, MACHINERY, UNCHECKED):
        items, lead = grouped[k], SECTIONS[k][1]
        whys = {i["why"] for i in items}
        if len(items) > 2 and len(whys) == 1 and whys != {""}:
            # 25 rows each ending "Written in your state-of-the-org file." is eight words of noise 25 times
            lead = lead + " " + whys.pop().replace("Written in", "All of them are written in")
            items = [dict(i, why="") for i in items]
        sections.append({"id": k, "title": SECTIONS[k][0], "lead": lead, "count": len(items),
                         "items": items[:SECTION_ROWS], "more": items[SECTION_ROWS:]})
    return {"kind": "org-brief", "org": st.get("org"), "at": st.get("at"), "state": state,
            "verdict": _verdict(st, s, grouped), "timeline": timeline(st, now),
            "numbers": _numbers(st, s, grouped), "sections": sections,
            "read": (st.get("coverage") or {}).get("measured"), "of": (st.get("coverage") or {}).get("tiles")}



# --- where the time went ------------------------------------------------------------------------------

#: how many bars the chart draws. The rest are shorter and are named in a line beneath it, so the chart shows
#: where the time actually went rather than 80 identical slivers (dataviz: emphasis, not categorical flooding).
TIMELINE_ROWS = 24
#: a bar this thin is invisible; a mark that cannot be seen is not a mark. Percent of the window.
MIN_BAR_PCT = 0.45


def timeline(st: dict[str, Any], now: dt.datetime | None = None) -> dict[str, Any]:
    """Pull requests as spans on one time axis — the only stretch of the chain with real per-item history.

    **Four of the chain's six stages are not drawn, and that is the whole reason this is honest.** A finding
    reaching a dispatcher, and a merge being verified, live on the board, and the board keeps one record per
    key and overwrites it every wake (row 62) — so live there is no `found_at` and no `dispatched_at` to draw
    a bar between. Measured on Lucille 2026-09-22: 59 chain items, 0 with a dispatch timestamp, 18 with a pull
    request. A Gantt of "the chain" that quietly drew only the stages it happened to have would say the work
    starts when a pull request opens, which is the tool's blind spot presented as the org's behaviour.

    Within a pull request the split is drawn only where a verdict exists. On the same reading 10 of 80 carried
    one, so 68 merges are a single unsplit bar — not a missing measurement but the finding of row 96, that the
    chair merged on green. The chart says so in words; it does not paint it red, because 68 of 78 bars in the
    alarm colour is shouting, not reading.

    Every percentage is computed here. The page places what this returns and does no arithmetic of its own.
    """
    now = now or dt.datetime.now(dt.timezone.utc)
    s = st.get("subjects") or {}
    if next((c for c in (st.get("could_not_read") or []) if c.startswith("prs:")), ""):
        return {"read": False, "why": "pull requests could not be read, so there is no history to draw", "rows": []}
    prs = [p for p in (s.get("prs") or []) if p.get("opened_at")]
    if not prs:
        return {"read": False, "why": "no pull request in this window", "rows": []}

    t0 = min(tp.parse_ts(p["opened_at"]) for p in prs)
    span = max((now - t0).total_seconds() / 3600, 1.0)

    def pct(a: dt.datetime, b: dt.datetime) -> float:
        return max(0.0, (b - a).total_seconds() / 3600) / span * 100

    rows = []
    for p in prs:
        opened = tp.parse_ts(p["opened_at"])
        ended = tp.parse_ts(p.get("merged_at") or p.get("closed_at") or "") or now
        still_open = not (p.get("merged_at") or p.get("closed_at"))
        verdict = tp.parse_ts(p.get("first_verdict_at") or "")
        if verdict and not (opened <= verdict <= ended):
            verdict = None                 # a verdict outside its own span is not a boundary, it is a defect
        total = (ended - opened).total_seconds() / 3600
        row = {"number": p.get("number"), "role": p.get("author_role") or "unknown", "kind": p.get("kind") or "",
               "opened_at": p["opened_at"], "verdict_at": p.get("first_verdict_at") if verdict else None,
               "end_at": (p.get("merged_at") or p.get("closed_at") or ""), "open": still_open,
               "merged": bool(p.get("merged_at")), "total_hours": round(total, 2),
               "left": round(pct(t0, opened), 3), "split": bool(verdict),
               "review_hours": round((verdict - opened).total_seconds() / 3600, 2) if verdict else None,
               "merge_hours": round((ended - verdict).total_seconds() / 3600, 2) if verdict else None}
        first = pct(opened, verdict) if verdict else pct(opened, ended)
        row["first_pct"] = round(max(first, MIN_BAR_PCT), 3)
        row["second_pct"] = round(max(pct(verdict, ended), MIN_BAR_PCT), 3) if verdict else 0.0
        rows.append(row)

    rows.sort(key=lambda r: -r["total_hours"])
    shown, rest = rows[:TIMELINE_ROWS], rows[TIMELINE_ROWS:]
    ticks = []
    day = t0.replace(hour=0, minute=0, second=0, microsecond=0) + dt.timedelta(days=1)
    while day < now:
        ticks.append({"at": day.isoformat(), "label": day.strftime("%b %-d"), "left": round(pct(t0, day), 3)})
        day += dt.timedelta(days=1)
    no_verdict = sum(1 for r in rows if r["merged"] and not r["split"])
    return {
        "read": True, "rows": shown, "shown": len(shown), "total": len(rows),
        "since": t0.isoformat(timespec="seconds"), "until": now.isoformat(timespec="seconds"),
        "span_hours": round(span, 1), "ticks": ticks,
        "rest": len(rest), "rest_under": round(max((r["total_hours"] for r in rest), default=0), 1),
        "no_verdict": no_verdict, "merged": sum(1 for r in rows if r["merged"]),
        "open_now": sum(1 for r in rows if r["open"]),
        # "still open" is a state, not a fifth thing to colour: an open request with no verdict is waiting for
        # a review, one with a verdict is waiting to merge, and the arrow says it has not finished. A swatch
        # for it put a second blue beside slot 1 and told the reader nothing.
        "legend": [{"id": "review", "label": "waiting for a review"},
                   {"id": "merge", "label": "reviewed, waiting to merge"},
                   {"id": "none", "label": "merged with no review recorded"},
                   {"id": "open", "label": "still open"}],
    }
