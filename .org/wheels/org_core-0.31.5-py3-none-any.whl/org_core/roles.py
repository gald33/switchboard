"""Role packages (SPEC.md §3): discovery and the contract each one ships."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from . import ROLE_IDS

ROLES_DIR = Path(__file__).parent / "roles"

# file kind -> where it lands in an installed repo
TARGETS = {
    "agent": ".claude/agents/{role}.md",
    "skill": ".claude/skills/{role}/SKILL.md",
}


def parse_version(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in str(v).split(".") if x.isdigit())


@dataclass
class RolePackage:
    id: str
    dir: Path
    contract: dict[str, Any]
    addenda: dict[str, Path] = field(default_factory=dict)   # kind -> agent.base.md / skill.base.md, rendered after the core
    record_schema: dict[str, Any] | None = None

    KINDS = ("agent", "skill")

    @property
    def version(self) -> str:
        return str(self.contract.get("version", "0"))

    def migration_for(self, installed_version: str) -> str | None:
        """The migration to apply when upgrading an install at `installed_version` to this package, if any."""
        inst = parse_version(installed_version)
        for at, kind in (self.contract.get("migrations") or {}).items():
            if inst < parse_version(at) <= parse_version(self.version):
                return str(kind)
        return None

    def defaults(self) -> dict[str, Any]:
        """The manifest-shaped defaults this package contributes (layered under org.yaml)."""
        c = self.contract
        d: dict[str, Any] = {"name": c.get("display", self.id)}
        rt = c.get("runtime", {})
        if "default" in rt:
            d["runtime"] = rt["default"]
        cad = c.get("cadence", {})
        for k in ("default", "label", "tolerance", "period_hours"):
            if k in cad:
                d[{"default": "cadence", "label": "cadence_label"}.get(k, k)] = cad[k]
        for k in ("model", "effort", "cap", "max_concurrent"):
            if k in c:
                d[k] = c[k]
        return d

    def target(self, kind: str) -> str:
        return TARGETS[kind].format(role=self.id)


def discover(roles_dir: Path = ROLES_DIR) -> dict[str, RolePackage]:
    """Every role package on disk, in cast order. A package with no contract is an error, not a skip."""
    found: dict[str, RolePackage] = {}
    for role_id in ROLE_IDS:
        d = roles_dir / role_id
        if not d.is_dir():
            continue
        contract_path = d / "role.yaml"
        if not contract_path.exists():
            raise FileNotFoundError(f"role package {role_id} has no role.yaml")
        contract = yaml.safe_load(contract_path.read_text()) or {}
        if contract.get("id") != role_id:
            raise ValueError(f"{contract_path}: id is {contract.get('id')!r}, directory is {role_id!r}")
        pkg = RolePackage(id=role_id, dir=d, contract=contract)
        for kind, fname in (("agent", "agent.base.md"), ("skill", "skill.base.md")):
            p = d / fname
            if p.exists():
                pkg.addenda[kind] = p
        for key in ("description", "tools", "skill_description", "summary", "never", "boundary", "report"):
            if key not in contract:
                raise ValueError(f"{contract_path}: contract lacks `{key}`, which the core templates render")
        rs = d / "record.schema.json"
        if rs.exists():
            pkg.record_schema = json.loads(rs.read_text())
        found[role_id] = pkg
    return found


def defaults_by_role(packages: dict[str, RolePackage]) -> dict[str, dict[str, Any]]:
    return {rid: pkg.defaults() for rid, pkg in packages.items()}
