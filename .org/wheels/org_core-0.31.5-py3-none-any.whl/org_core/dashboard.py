"""`org status --html` — the same reading, as a page (SPEC §9).

A pure function: `render_html(status_dict)` returns one self-contained document and reaches nothing. The
page is scanned, not read, so state is encoded in form as well as colour — every tile carries the word
`RED` / `CLEAR` / `DARK` beside its mark, because a status colour must never carry meaning alone.

`DARK` is deliberately **not** a third severity. A tile nobody could measure is absent, not bad, so it
takes a muted neutral and a dashed edge rather than a warning hue — the whole point of rows 62 and 65 is
that "not measured" must never read as either "fine" or "failing".
"""

from __future__ import annotations

import datetime as dt
import html
import json
import re
from typing import Any

from .status import FINDING

#: status steps, fixed — never reused for anything but state (dataviz: the status palette is reserved)
CRITICAL, GOOD = "#d03b3b", "#0ca30c"

STATE_MARK = {"RED": "●", "CLEAR": "○", "DARK": "—"}

CSS = """
:root{
  --bg:#fbfbfc; --surface:#fff; --surface-2:#f6f7f9; --ink:#12141a; --ink-2:#565c6b; --muted:#8b91a1;
  --border:#e3e5ea; --accent:#3d6ea8;
  --red:#d03b3b; --green:#0ca30c; --dark-mark:#9aa0ae;
  --red-wash:#fdf2f2; --green-wash:#f1faf1; --dark-wash:#f6f7f9;
}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){
  --bg:#131417; --surface:#1a1c21; --surface-2:#212429; --ink:#f2f3f5; --ink-2:#a8aebd; --muted:#767c8b;
  --border:#2a2d35; --accent:#7aa8dc;
  --red:#e2584f; --green:#3fbb3f; --dark-mark:#767c8b;
  --red-wash:#241a1b; --green-wash:#16231a; --dark-wash:#1f2228;
}}
:root[data-theme="dark"]{
  --bg:#131417; --surface:#1a1c21; --surface-2:#212429; --ink:#f2f3f5; --ink-2:#a8aebd; --muted:#767c8b;
  --border:#2a2d35; --accent:#7aa8dc;
  --red:#e2584f; --green:#3fbb3f; --dark-mark:#767c8b;
  --red-wash:#241a1b; --green-wash:#16231a; --dark-wash:#1f2228;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);
  font-family:"IBM Plex Sans",ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
  font-size:14px;line-height:1.5;-webkit-font-smoothing:antialiased}
.wrap{max-width:1180px;margin:0 auto;padding-inline:16px;padding-block:28px 56px}
h1{font-size:19px;font-weight:600;margin:0;letter-spacing:-.01em}
.sub{color:var(--ink-2);font-size:12.5px;margin-top:3px;
  font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-variant-numeric:tabular-nums}
.eyebrow{font-size:10.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.banner{display:flex;gap:12px;margin-top:20px;padding:14px 16px;border:1px solid var(--border);
  border-left-width:4px;border-radius:7px;background:var(--surface)}
.banner.RED{border-left-color:var(--red);background:var(--red-wash)}
.banner.CLEAR{border-left-color:var(--green);background:var(--green-wash)}
.banner.DARK{border-left-color:var(--dark-mark);border-left-style:dashed;background:var(--dark-wash)}
.banner p{margin:4px 0 0;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;
  word-break:break-word;line-height:1.55}
.note{margin-top:14px;padding:10px 13px;border:1px dashed var(--border);border-radius:7px;
  background:var(--surface-2);color:var(--ink-2);font-size:12.5px}
.grid{display:grid;gap:14px;margin-top:18px;grid-template-columns:repeat(auto-fit,minmax(330px,1fr))}
.tile{border:1px solid var(--border);border-radius:9px;background:var(--surface);padding:14px 16px;
  display:flex;flex-direction:column;gap:9px;min-width:0}
.tile.span{grid-column:1/-1}
.tile.DARK{border-style:dashed}
.thead{display:flex;align-items:baseline;gap:9px;flex-wrap:wrap}
.chip{display:inline-flex;align-items:center;gap:5px;font-size:10.5px;font-weight:600;letter-spacing:.07em;
  padding:2px 8px;border-radius:99px;border:1px solid var(--border);white-space:nowrap}
.chip.RED{color:var(--red);border-color:var(--red)}
.chip.CLEAR{color:var(--green);border-color:var(--green)}
.chip.DARK{color:var(--dark-mark);border-style:dashed}
.tname{font-weight:600;font-size:14px}
.tier{font-size:11.5px;color:var(--muted)}
.lines{margin:0;font-family:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12.5px;
  line-height:1.65;overflow-x:auto;font-variant-numeric:tabular-nums}
.lines div{padding:1px 0;word-break:break-word}
.lines div.hot{color:var(--red)}
.broken{font-size:11.5px;color:var(--muted);border-top:1px dotted var(--border);padding-top:8px;margin-top:auto}
.broken b{font-weight:600;color:var(--ink-2)}
table{border-collapse:collapse;width:100%;font-size:12.5px;
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-variant-numeric:tabular-nums}
th{text-align:left;font-weight:600;color:var(--muted);font-size:10.5px;letter-spacing:.07em;
  text-transform:uppercase;padding:0 10px 6px 0;white-space:nowrap}
td{padding:5px 10px 5px 0;border-top:1px solid var(--border);vertical-align:middle;white-space:nowrap}
td.wide{white-space:normal;min-width:150px}
.scroll{overflow-x:auto}
.bar{position:relative;display:inline-block;height:8px;min-width:90px;width:120px;vertical-align:middle;background:var(--surface-2);border-radius:4px}
.bar i{position:absolute;inset:0 auto 0 0;border-radius:4px;background:var(--green)}
.bar i.over{background:var(--red)}
.bar u{position:absolute;top:-3px;bottom:-3px;width:2px;background:var(--ink-2);opacity:.6}
.foot{margin-top:26px;padding-top:14px;border-top:1px solid var(--border);color:var(--muted);font-size:12px}
.foot code{font-family:"IBM Plex Mono",ui-monospace,monospace;color:var(--ink-2);word-break:break-all}
.foot p{margin:5px 0}
@media (max-width:460px){.wrap{padding-block:20px 40px}.grid{grid-template-columns:1fr}}

/* --- the plain reading: prose in the sans face, figures in the mono one -------------------------- */
.verdict{margin-top:18px;padding:18px 20px 18px 22px;border:1px solid var(--border);border-left-width:5px;
  border-radius:9px;background:var(--surface);font-size:19px;line-height:1.45;text-wrap:balance;
  letter-spacing:-.005em}
.verdict.RED{border-left-color:var(--red)}
.verdict.CLEAR{border-left-color:var(--green)}
.verdict.DARK{border-left-color:var(--dark-mark);border-left-style:dashed}
.nums{display:grid;gap:10px;margin-top:14px;grid-template-columns:repeat(auto-fit,minmax(168px,1fr))}
.num{border:1px solid var(--border);border-radius:9px;background:var(--surface);padding:12px 14px;min-width:0}
.num .k{font-size:10.5px;font-weight:600;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.num .v{font-family:"IBM Plex Mono",ui-monospace,monospace;font-variant-numeric:tabular-nums;
  font-size:22px;font-weight:600;line-height:1.25;margin-top:5px;letter-spacing:-.02em;word-break:break-word}
.num .v.RED{color:var(--red)}
.num .v.CLEAR{color:var(--green)}
.num .v.DARK{color:var(--dark-mark)}
.num .n{font-size:12px;color:var(--ink-2);margin-top:3px}
.sec{margin-top:22px;border:1px solid var(--border);border-radius:10px;background:var(--surface);overflow:hidden}
.sec.you{border-left:5px solid var(--accent)}
.sechead{padding:13px 18px;background:var(--surface-2);border-bottom:1px solid var(--border)}
.sechead h2{margin:0;font-size:15px;font-weight:600;letter-spacing:-.01em}
.sechead p{margin:3px 0 0;font-size:12.5px;color:var(--ink-2);max-width:68ch}
.sechead .ct{float:right;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:13px;color:var(--muted);
  font-variant-numeric:tabular-nums}
.row{display:flex;gap:14px;align-items:flex-start;padding:13px 18px;border-top:1px solid var(--border)}
.row:first-of-type{border-top:none}
.row .body{flex:1;min-width:0}
.row .what{font-weight:600;font-size:14.5px;line-height:1.4;text-wrap:balance}
.row .why{margin-top:3px;font-size:13px;color:var(--ink-2);line-height:1.5;max-width:74ch}
.row .quote{margin-top:6px;padding:7px 10px;border-left:2px solid var(--border);background:var(--surface-2);
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px;color:var(--ink-2);
  white-space:pre-wrap;word-break:break-word;border-radius:0 5px 5px 0}
.age{flex:none;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:12px;color:var(--muted);
  font-variant-numeric:tabular-nums;white-space:nowrap;padding-top:2px}
.dot{flex:none;width:7px;height:7px;border-radius:50%;margin-top:7px;background:var(--dark-mark)}
.dot.RED{background:var(--red)}
.dot.CLEAR{background:var(--green)}
.dot.OPEN{background:var(--accent)}
details.instrument{margin-top:30px;border-top:1px solid var(--border);padding-top:16px}
details.instrument>summary{cursor:pointer;font-size:13px;color:var(--ink-2);list-style:none;
  display:flex;align-items:center;gap:7px;padding:4px 0}
details.instrument>summary::-webkit-details-marker{display:none}
details.instrument>summary::before{content:"▸";color:var(--muted);font-size:11px}
details.instrument[open]>summary::before{content:"▾"}
details.instrument>summary:hover{color:var(--accent)}
details.instrument>summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px;border-radius:4px}
.sub2{font-size:12.5px;color:var(--ink-2);margin:10px 0 0;max-width:74ch}
@media (max-width:460px){.sechead .ct{float:none;display:block;margin-bottom:2px}}

/* --- the command centre: the fleet at a glance, then the things only a person can clear -------- */
.fleet{width:100%;border-collapse:separate;border-spacing:0;font-size:12.5px;margin-top:4px}
.fleet th{text-align:left;font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;
  color:var(--muted);padding:0 12px 7px 0;white-space:nowrap}
.fleet td{padding:8px 12px 8px 0;border-top:1px solid var(--border);white-space:nowrap;vertical-align:top}
.fleet td.org{font-weight:600;font-size:13px;white-space:nowrap;padding-right:18px}
.fleet td.org a{color:inherit;text-decoration:none;border-bottom:1px solid var(--border)}
.fleet td.org a:hover{color:var(--accent);border-bottom-color:var(--accent)}
.fleet td.org a:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:3px}
.fleet .cell{display:flex;align-items:center;gap:6px;
  font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--ink-2)}
.fleet .cell b{width:7px;height:7px;border-radius:50%;flex:none;background:var(--dark-mark)}
.fleet .cell.RED b{background:var(--red)}
.fleet .cell.CLEAR b{background:var(--green)}
.fleet .cell.RED{color:var(--red)}
.fleet td.wide{white-space:normal;color:var(--muted);font-size:12px}
.act{margin-top:20px;border:1px solid var(--border);border-left:5px solid var(--accent);border-radius:10px;
  background:var(--surface);overflow:hidden}
.arow{display:grid;grid-template-columns:78px 1fr auto;gap:14px;align-items:start;padding:13px 18px;
  border-top:1px solid var(--border)}
.arow:first-of-type{border-top:none}
.achip{font-size:10.5px;font-weight:600;letter-spacing:.05em;text-transform:uppercase;color:var(--muted);
  padding-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.arow .what{font-weight:600;font-size:14.5px;line-height:1.4;text-wrap:balance}
.arow .why{margin-top:3px;font-size:13px;color:var(--ink-2);line-height:1.5;max-width:74ch}
.blocks{margin-top:7px;padding:6px 10px;border-radius:6px;background:var(--surface-2);
  font-size:12.5px;color:var(--ink);display:flex;gap:8px;align-items:baseline}
.blocks s{text-decoration:none;color:var(--accent);font-weight:600;flex:none}
.blocks em{font-style:normal;color:var(--ink-2)}
.blocks code{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11.5px;color:var(--ink-2)}
.arow .side{text-align:right;font-size:12px;color:var(--muted);white-space:nowrap;
  font-family:"IBM Plex Mono",ui-monospace,monospace}
.arow .side a{display:block;margin-top:5px;color:var(--accent);font-family:inherit;text-decoration:none}
.arow .side a:hover{text-decoration:underline}
.arow .side a:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:3px}
@media (max-width:620px){.arow{grid-template-columns:1fr;gap:6px}.arow .side{text-align:left}
/* the matrix is the glance, so on a phone it stacks into one block per org rather than scrolling
   sideways out of view: every cell prints its own signal name, which is why each carries data-k. */
.fleet,.fleet tbody,.fleet tr,.fleet td{display:block;width:100%}
.fleet thead{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}
.fleet tr{border-top:1px solid var(--border);padding:10px 0}
.fleet tr:first-child{border-top:none}
.fleet td{border-top:none;padding:2px 0;white-space:normal;display:grid;
  grid-template-columns:84px 1fr;gap:10px;align-items:baseline}
.fleet td[data-k]::before{content:attr(data-k);font-size:10px;font-weight:600;letter-spacing:.08em;
  text-transform:uppercase;color:var(--muted);font-family:"IBM Plex Sans",system-ui,sans-serif}
.fleet td.org{display:block;font-size:14px;padding-bottom:4px}}

/* --- where the time went: spans on one axis ------------------------------------------------------
   The two stage hues are slots 1 and 2 of the validated categorical palette, stepped for each surface
   (not flipped). "No review recorded" reuses the page's own ABSENT grey, which is what it means: the
   bar could not be split because nothing was written, and that is the same kind of fact as a dark tile. */
:root{--s1:#2a78d6; --s2:#eb6834; --s0:#9aa0ae; --lab:112px}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){--s1:#3987e5; --s2:#d95926; --s0:#767c8b}}
:root[data-theme="dark"]{--s1:#3987e5; --s2:#d95926; --s0:#767c8b}
.gkey{display:flex;flex-wrap:wrap;gap:12px;margin:0 0 12px;font-size:12px;color:var(--ink-2)}
.gkey span{display:inline-flex;align-items:center;gap:6px}
.gkey i{width:15px;height:9px;border-radius:0 3px 3px 0;flex:none}
.gkey i.review{background:var(--s1)}
.gkey i.merge{background:var(--s2)}
.gkey i.none{background:var(--s0)}
.gkey s{text-decoration:none;color:var(--ink-2);font-size:11px}
.gplot{position:relative;padding-bottom:20px;padding-right:9px}
.ggrid{position:absolute;left:var(--lab);right:9px;top:0;bottom:20px;pointer-events:none}
.ggrid b{position:absolute;top:0;bottom:0;width:1px;background:var(--border)}
.grow{display:grid;grid-template-columns:var(--lab) 1fr;align-items:center;height:15px}
.glabel{font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:11px;color:var(--ink-2);
  font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding-right:9px}
.gtrack{position:relative;height:15px}
.gspan{position:absolute;top:3px;height:9px;display:flex;gap:2px}
.gspan i{display:block;height:9px;min-width:2px}
.gspan i:last-child{border-radius:0 4px 4px 0}
.gspan i.review{background:var(--s1)}
.gspan i.merge{background:var(--s2)}
.gspan i.none{background:var(--s0)}
.gspan.open i:last-child{border-radius:0}
.gspan.open::after{content:"";position:absolute;right:-7px;top:0;border:4.5px solid transparent;
  border-left-color:var(--s1)}
.gaxis{position:absolute;left:var(--lab);right:9px;bottom:0;height:18px}
.gaxis b{position:absolute;top:0;font-family:"IBM Plex Mono",ui-monospace,monospace;font-size:10.5px;
  font-weight:400;color:var(--muted);transform:translateX(-50%);white-space:nowrap}
.gnote{margin:12px 0 0;font-size:12.5px;color:var(--ink-2);max-width:74ch}
details.more>summary{cursor:pointer;padding:10px 18px;border-top:1px solid var(--border);font-size:12.5px;
  color:var(--ink-2);background:var(--surface-2)}
details.more>summary:hover{color:var(--accent)}
details.more>summary:focus-visible{outline:2px solid var(--accent);outline-offset:-2px}
details.gtable{margin-top:12px}
details.gtable>summary{cursor:pointer;font-size:12.5px;color:var(--ink-2)}
details.gtable>summary:hover{color:var(--accent)}
details.gtable>summary:focus-visible{outline:2px solid var(--accent);outline-offset:3px;border-radius:4px}
details.gtable table{margin-top:9px}
@media (max-width:460px){:root{--lab:78px}.glabel{font-size:10px}}
"""


def reading_doc(st: dict[str, Any], *, source: str = "org status") -> dict[str, Any]:
    """One reading, flattened to what the page draws — defined once, so the copy embedded in the page and
    the copy a live store holds are the same shape and can never disagree.

    `report` is dropped: it is the whole measurement and a store document is capped, and the page renders
    none of it directly. The `brief` — the plain reading — rides along, so a live page repaints the words a
    person reads and the instrument beneath them from the same document, and the two can never disagree.
    """
    from .status import EDGE_OWNER, EDGE_TIER, NO_MEDIAN, tier_unread

    rep = st.get("report") or {}
    unread_by_tier = tier_unread(st.get("could_not_read") or [])
    edges = []
    for name, e in (rep.get("edges") or {}).items():
        edges.append({"name": name, "tier": EDGE_TIER.get(name, "board"), "owner": EDGE_OWNER.get(name, "?"),
                      "median_hours": e.get("median_hours"), "n": e.get("n"), "waiting": e.get("waiting"),
                      "worst_item": e.get("worst_waiting_item"), "worst_hours": e.get("worst_waiting_hours"),
                      "target": (rep.get("targets") or {}).get(name),
                      "unread_why": unread_by_tier.get(EDGE_TIER.get(name, "board"), ""),
                      "note": NO_MEDIAN.get(name, "") or ("the board kept no earlier record (row 62)"
                                                          if EDGE_TIER.get(name) == "board" and not e.get("n") else "")})
    from .brief import brief

    return {"at": st.get("at"), "org": st.get("org"), "headline": st.get("headline"), "brief": brief(st),
            "tiles": [{k: t[k] for k in ("id", "title", "tier", "state", "lines", "broken_looks_like")} for t in st["tiles"]],
            "edges": edges, "coverage": st.get("coverage") or {}, "tiers": st.get("tiers") or {},
            "could_not_read": st.get("could_not_read") or [], "source": source}

#: the page is live by subscription, not by polling: it draws the reading it shipped with, then redraws
#: whenever a newer one lands in the artifact's store. org-core writes no store — rule 6 — so the writer is
#: whatever session can reach the org. With no store granted the page still shows its embedded reading and
#: says so, because a dashboard that silently shows stale numbers is the failure this whole file is about.
LIVE_JS = r"""
<script>
(function () {
  var EL = function (t, c, x) { var e = document.createElement(t); if (c) e.className = c;
    if (x !== undefined && x !== null) e.textContent = String(x); return e; };
  var MARK = { RED: "\u25cf", CLEAR: "\u25cb", DARK: "\u2014" };
  var FINDING = __FINDING__;   // generated from status.FINDING — two hand-kept copies drifted once
  var isFinding = function (l) { for (var i = 0; i < FINDING.length; i++) if (l.indexOf(FINDING[i]) === 0) return true; return false; };
  var seen = null;

  function ago(iso) {
    var t = Date.parse(iso); if (isNaN(t)) return "";
    var m = Math.round((Date.now() - t) / 60000);
    if (m < 1) return "just now"; if (m < 60) return m + " min ago";
    var h = m / 60; return (h < 48 ? h.toFixed(1) + "h ago" : Math.round(h / 24) + "d ago");
  }
  function tickAges() {
    var n = document.getElementById("age"); if (n && seen) n.textContent = " \u00b7 read " + ago(seen.at);
  }
  function banner(tiles) {
    for (var i = 0; i < tiles.length; i++) if (tiles[i].state === "RED") return "RED";
    for (var j = 0; j < tiles.length; j++) if (tiles[j].state === "DARK") return "DARK";
    return "CLEAR";
  }
  function edgeTable(d) {
    var wrap = EL("div", "scroll"), t = EL("table"), h = EL("thead"), hr = EL("tr");
    ["edge","tier","owner","median","n","waiting","worst now","vs target"].forEach(function (c) { hr.appendChild(EL("th", null, c)); });
    h.appendChild(hr); t.appendChild(h);
    var b = EL("tbody");
    (d.edges || []).forEach(function (e) {
      var r = EL("tr");
      if (e.unread_why) {                 // an unread source is never repainted as a zero (row 65)
        [e.name, e.tier, e.owner].forEach(function (v) { r.appendChild(EL("td", null, v)); });
        var u = EL("td", "wide", "not judged \u2014 " + e.unread_why);
        u.colSpan = 5; u.style.color = "var(--red)";
        r.appendChild(u); b.appendChild(r); return;
      }
      [e.name, e.tier, e.owner,
       (e.median_hours === null || e.median_hours === undefined) ? "\u2014" : e.median_hours + "h",
       e.n, e.waiting,
       e.worst_item ? e.worst_item + " " + e.worst_hours + "h" : "\u2014"].forEach(function (v, i) {
        var td = EL("td", i === 6 ? "wide" : null, v); r.appendChild(td);
      });
      var td = EL("td");
      if (e.worst_hours !== null && e.worst_hours !== undefined && e.target) {
        var bar = EL("span", "bar"), fill = EL("i"), tick = EL("u");
        var ratio = e.worst_hours / e.target;
        fill.style.width = Math.min(ratio, 1) * 100 + "%"; if (ratio > 1) fill.className = "over";
        tick.style.left = "100%"; bar.appendChild(fill); bar.appendChild(tick);
        bar.title = "worst " + e.worst_hours + "h against a " + e.target + "h target";
        td.appendChild(bar);
      } else { td.appendChild(document.createTextNode("\u2014")); }
      if (e.target) td.appendChild(document.createTextNode("  (target " + e.target + "h)"));
      r.appendChild(td); b.appendChild(r);
      if (e.note) { var nr = EL("tr"), nd = EL("td", "wide", e.note);
        nd.colSpan = 8; nd.style.color = "var(--muted)"; nd.style.borderTop = "none"; nd.style.paddingTop = "0";
        nr.appendChild(nd); b.appendChild(nr); }
    });
    t.appendChild(b); wrap.appendChild(t); return wrap;
  }
  function paintBrief(b) {
    // the plain half repaints from the same document as the instrument below it: a live page whose words
    // stay on the last reading while its tiles move is worse than one that never claimed to be live
    if (!b) return;
    var v = document.getElementById("verdict");
    if (v) { v.textContent = b.verdict || ""; v.className = "verdict " + (b.state || "DARK"); }
    var nums = document.getElementById("nums");
    if (nums) {
      nums.textContent = "";
      (b.numbers || []).forEach(function (n) {
        var d2 = EL("div", "num");
        d2.appendChild(EL("div", "k", n.label));
        d2.appendChild(EL("div", "v " + (n.tone || "DARK"), n.value));
        d2.appendChild(EL("div", "n", n.note));
        nums.appendChild(d2);
      });
    }
    var secs = document.getElementById("secs");
    if (!secs) return;
    secs.textContent = "";
    (b.sections || []).forEach(function (sec) {
      if (!sec.count) return;
      var s2 = EL("section", "sec " + sec.id), head = EL("div", "sechead");
      head.appendChild(EL("span", "ct", sec.count));
      head.appendChild(EL("h2", null, sec.title));
      head.appendChild(EL("p", null, sec.lead));
      s2.appendChild(head);
      (sec.items || []).forEach(function (i) {
        var r = EL("div", "row");
        r.appendChild(EL("span", "dot " + (i.tone || "DARK")));
        var body = EL("div", "body");
        body.appendChild(EL("div", "what", i.what));
        if (i.why) body.appendChild(EL("div", "why", i.why));
        if (i.quote) body.appendChild(EL("div", "quote", i.quote));
        r.appendChild(body);
        if (i.ago) { var a = EL("div", "age", i.ago); if (i.at) a.title = i.at; r.appendChild(a); }
        s2.appendChild(r);
      });
      secs.appendChild(s2);
    });
  }
  function paint(d) {
    seen = d;
    paintBrief(d.brief);
    document.getElementById("org").textContent = d.org || "";
    document.getElementById("readat").textContent = "read at " + (d.at || "");
    var hl = document.getElementById("headline"); hl.textContent = d.headline || "";
    var bn = document.getElementById("banner"); bn.className = "banner " + banner(d.tiles || []);
    var grid = document.getElementById("tiles"); grid.textContent = "";
    (d.tiles || []).forEach(function (t) {
      var sec = EL("section", "tile " + t.state + (t.id === "chain" ? " span" : ""));
      var head = EL("div", "thead");
      head.appendChild(EL("span", "chip " + t.state, MARK[t.state] + " " + t.state));
      head.appendChild(EL("span", "tname", t.title));
      head.appendChild(EL("span", "tier", t.tier + " \u2014 " + ((d.tiers || {})[t.tier] || "several sources")));
      sec.appendChild(head);
      var hasTable = t.id === "chain" && (d.edges || []).length;
      if (hasTable) sec.appendChild(edgeTable(d));
      var lines = EL("div", "lines");
      (t.lines || []).forEach(function (l) {
        if (hasTable && !isFinding(l)) return;
        lines.appendChild(EL("div", isFinding(l) ? "hot" : null, l));
      });
      sec.appendChild(lines);
      if (t.state !== "RED") {
        var br = EL("div", "broken"); br.appendChild(EL("b", null, "broken looks like: "));
        br.appendChild(document.createTextNode(t.broken_looks_like || "")); sec.appendChild(br);
      }
      grid.appendChild(sec);
    });
    var c = d.coverage || {}, foot = document.getElementById("cover"); foot.textContent = "";
    foot.appendChild(EL("b", null, "read " + c.measured + " of " + c.tiles + " tiles"));
    if (c.dark && c.dark.length) foot.appendChild(document.createTextNode(" \u00b7 dark: " + c.dark.join(", ")));
    if (d.source) foot.appendChild(document.createTextNode(" \u00b7 " + d.source));
    var un = document.getElementById("unread"); un.textContent = "";
    (d.could_not_read || []).forEach(function (x) {
      var pEl = document.createElement("p"); pEl.appendChild(EL("code", null, "could not read: " + x)); un.appendChild(pEl);
    });
    tickAges();
  }
  function history(docs) {
    var h = document.getElementById("history"); h.textContent = "";
    if (docs.length < 2) return;
    h.appendChild(EL("span", "eyebrow", "readings"));
    docs.forEach(function (d, i) {
      var b = EL("button", "hbtn" + (i === 0 ? " now" : ""), ago(d.at));
      b.title = d.at + " \u2014 " + (d.headline || "");
      b.onclick = function () {
        paint(d);
        Array.prototype.forEach.call(h.querySelectorAll(".hbtn"), function (x) { x.classList.remove("now"); });
        b.classList.add("now");
      };
      h.appendChild(b);
    });
  }
  function live(txt, on) {
    var n = document.getElementById("live");
    n.textContent = txt; n.className = "live " + (on ? "on" : "off");
  }

  var initial = null;
  try { initial = JSON.parse(document.getElementById("reading").textContent); } catch (e) {}
  if (initial) paint(initial);
  setInterval(tickAges, 30000);

  __SOURCE__
})();
</script>
"""

#: the artifact source: a store subscription. org-core pushes nothing (rule 6) — the page only reads.
SOURCE_STORE = r"""

  (async function () {
    var db = null;
    try { db = window.claude && window.claude.use ? await window.claude.use("db") : null; } catch (e) { db = null; }
    if (!db) { live("not live \u2014 showing the reading this page shipped with", false); return; }
    live("live \u2014 watching for new readings", true);
    try {
      db.collection("readings").orderBy("at", "desc").limit(20).onSnapshot(
        function (snap) {
          var docs = snap.docs.map(function (x) { return x.data(); }).filter(Boolean);
          if (!docs.length) { live("live \u2014 no reading written yet; showing the embedded one", true); return; }
          paint(docs[0]); history(docs);
          live("live \u2014 " + docs.length + " reading(s), newest " + ago(docs[0].at), true);
        },
        function (err) { live("live updates stopped (" + (err && err.code) + ") \u2014 showing the last reading received", false); }
      );
    } catch (e) { live("not live \u2014 " + e, false); }
  })();
"""

#: the served source: poll the process that took the reading. That process re-reads on its own interval, so
#: polling faster than it costs nothing — and the age on screen stays the truth about how old the data is.
SOURCE_POLL = r"""
  var POLL_URL = "__POLL__", POLL_MS = __POLL_MS__;
  async function pollOnce() {
    try {
      var r = await fetch(POLL_URL, { cache: "no-store" });
      if (!r.ok) throw new Error("HTTP " + r.status);
      var d = await r.json();
      if (!seen || d.at !== seen.at) paint(d); else tickAges();
      live("live \u2014 re-read " + ago(d.at), true);
    } catch (e) {
      live("the reader stopped answering \u2014 showing the last reading received", false);
    }
  }
  pollOnce();
  setInterval(pollOnce, POLL_MS);
"""

LIVE_CSS = """
.live{display:inline-flex;align-items:center;gap:6px;font-size:11px;font-weight:600;letter-spacing:.06em;
  text-transform:uppercase;padding:2px 9px;border-radius:99px;border:1px solid var(--border);color:var(--muted)}
.live.on{color:var(--green);border-color:var(--green)}
.live.on::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--green)}
.live.off::before{content:"";width:6px;height:6px;border-radius:50%;background:var(--dark-mark)}
#history{display:flex;flex-wrap:wrap;align-items:center;gap:7px;margin-top:14px}
.hbtn{font:inherit;font-size:11.5px;font-family:"IBM Plex Mono",ui-monospace,monospace;color:var(--ink-2);
  background:var(--surface);border:1px solid var(--border);border-radius:99px;padding:3px 10px;cursor:pointer}
.hbtn:hover{border-color:var(--accent);color:var(--accent)}
.hbtn.now{border-color:var(--accent);color:var(--accent);font-weight:600}
.hbtn:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
"""


def _e(x: Any) -> str:
    return html.escape(str(x if x is not None else ""))


#: the roles write markdown into the operator file and into their blockers, so `LUCILLE_ADMIN_JWT` and
#: *(Ruth, 2026-09-20)* reach this page as literal backticks and asterisks. Printing them raw made the one
#: thing a row is about — the name — the hardest part of the row to see (measured 2026-09-22 on the first
#: `org command` render). This renders the three inline forms and nothing else: no links, no images, no
#: blocks. It runs AFTER escaping, so nothing here can introduce markup the text did not already ask for.
_MD = (
    (re.compile(r"`([^`\n]{1,120})`"), r"<code>\1</code>"),
    (re.compile(r"\*\*(\S|\S[^*\n]{0,198}\S)\*\*"), r"<b>\1</b>"),
    # the emphasised run may not begin or end in a space: `a * b * c` is arithmetic, not an italic.
    (re.compile(r"(?<![*\w])\*(\S|\S[^*\n]{0,198}\S)\*(?!\*)"), r"<i>\1</i>"),
)


def _md(x: Any) -> str:
    """Escaped text with `code`, **bold** and *italic* rendered. The escape is first and unconditional."""
    out = _e(x)
    for rx, rep in _MD:
        out = rx.sub(rep, out)
    return out


def _clock(at: Any) -> str:
    """`2026-09-22 18:05 UTC` from an ISO instant. A header is glanced at; `T18:05:30+00:00` is not."""
    try:
        t = dt.datetime.fromisoformat(str(at).replace("Z", "+00:00"))
    except ValueError:
        return _e(at)                       # unparseable: show what we were given, never a made-up time
    return t.strftime("%Y-%m-%d %H:%M UTC" if (t.utcoffset() or dt.timedelta()) == dt.timedelta() else "%Y-%m-%d %H:%M %Z")


def _edge_rows(rep: dict[str, Any], tiers: dict[str, str], unread: list[str] | None = None) -> str:
    """The chain as a table: every median beside its n, every worst-waiting beside its target.

    A board-tier edge shows what it is: a worst-waiting-now and no median, because the board keeps one
    record per key (row 62). The bar compares the worst wait to that edge's target and to nothing else.
    """
    from .status import EDGE_OWNER, EDGE_TIER, NO_MEDIAN, tier_unread

    out = ["<div class='scroll'><table><thead><tr><th>edge</th><th>tier</th><th>owner</th>"
           "<th>median</th><th>n</th><th>waiting</th><th>worst now</th><th>vs target</th></tr></thead><tbody>"]
    unread_by_tier = tier_unread(unread or [])
    for name, e in (rep.get("edges") or {}).items():
        tier = EDGE_TIER.get(name, "board")
        why = unread_by_tier.get(tier, "")
        if why:                      # an unread source is never rendered as a zero (row 65)
            out.append(f"<tr><td>{_e(name)}</td><td>{_e(tier)}</td><td>{_e(EDGE_OWNER.get(name, '?'))}</td>"
                       f"<td colspan='5' class='wide' style='color:var(--red)'>not judged — {_e(why)}</td></tr>")
            continue
        t = (rep.get("targets") or {}).get(name)
        med = f"{e['median_hours']}h" if e.get("median_hours") is not None else "—"
        worst = f"{e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e.get("worst_waiting_item") else "—"
        bar = "—"
        if e.get("worst_waiting_hours") is not None and t:
            ratio = e["worst_waiting_hours"] / t
            pct = min(ratio, 1.0) * 100
            over = " over" if ratio > 1 else ""
            bar = (f"<span class='bar' title='worst {e['worst_waiting_hours']}h against a {t}h target'>"
                   f"<i class='{over.strip()}' style='width:{pct:.0f}%'></i><u style='left:100%'></u></span>")
        why = NO_MEDIAN.get(name, "") or ("the board kept no earlier record (row 62)" if tier == "board" and not e.get("n") else "")
        out.append(
            f"<tr><td>{_e(name)}</td><td>{_e(tier)}</td><td>{_e(EDGE_OWNER.get(name, '?'))}</td>"
            f"<td>{_e(med)}</td><td>{_e(e.get('n'))}</td><td>{_e(e.get('waiting'))}</td>"
            f"<td class='wide'>{_e(worst)}</td><td>{bar}{('  (target ' + str(t) + 'h)') if t else ''}</td></tr>")
        if why:
            out.append(f"<tr><td colspan='8' class='wide' style='color:var(--muted);border-top:none;padding-top:0'>{_e(why)}</td></tr>")
    out.append("</tbody></table></div>")
    return "".join(out)


def _brief_html(b: dict[str, Any]) -> str:
    """The plain reading: a verdict, four figures, and the items grouped by who can clear them.

    Severity is never colour alone — every row carries a dot AND sits under a titled group that says in words
    who it is for, and each figure states its own unit. The one accent on the page marks the group addressed
    to the reader, because that is the only group they can act on themselves."""
    nums = "".join(
        f"<div class='num'><div class='k'>{_e(n['label'])}</div>"
        f"<div class='v {n['tone']}'>{_e(n['value'])}</div><div class='n'>{_e(n['note'])}</div></div>"
        for n in b.get("numbers") or [])
    secs = []
    for sec in b.get("sections") or []:
        if not sec["count"]:
            continue
        def row(i: dict[str, Any]) -> str:
            return (f"<div class='row'><span class='dot {i['tone']}'></span><div class='body'>"
                    f"<div class='what'>{_md(i['what'])}</div>"
                    + (f"<div class='why'>{_md(i['why'])}</div>" if i.get("why") else "")
                    + (f"<div class='quote'>{_md(i['quote'])}</div>" if i.get("quote") else "")
                    + "</div>"
                    + (f"<div class='age' title='{_e(i.get('at') or '')}'>{_e(i['ago'])}</div>" if i.get("ago") else "")
                    + "</div>")
        rows = "".join(row(i) for i in sec["items"])
        rest = ("".join(row(i) for i in sec["more"]) and
                f"<details class='more'><summary>{len(sec['more'])} more</summary>"
                f"{''.join(row(i) for i in sec['more'])}</details>") if sec.get("more") else ""
        secs.append(f"<section class='sec {sec['id']}'><div class='sechead'>"
                    f"<span class='ct'>{sec['count']}</span><h2>{_e(sec['title'])}</h2>"
                    f"<p>{_e(sec['lead'])}</p></div>{rows}{rest}</section>")
    return (f"<div class='verdict {b.get('state', 'DARK')}' id='verdict'>{_e(b.get('verdict'))}</div>"
            f"<div class='nums' id='nums'>{nums}</div><div id='secs'>{''.join(secs)}</div>"
            f"<div id='gantt'>{_timeline_html(b.get('timeline') or {})}</div>")


def _timeline_html(t: dict[str, Any]) -> str:
    """The spans, placed. Every percentage was computed in Python — the page does no arithmetic of its own,
    which is the same rule the rest of this file follows and the reason two surfaces cannot drift."""
    if not t.get("read"):
        return (f"<section class='sec'><div class='sechead'><h2>Where the time went</h2>"
                f"<p>Not drawn — {_e(t.get('why'))}.</p></div></section>")
    grid = "".join(f"<b style='left:{x['left']}%'></b>" for x in t.get("ticks") or [])
    axis = "".join(f"<b style='left:{x['left']}%'>{_e(x['label'])}</b>" for x in t.get("ticks") or [])
    rows = []
    for r in t["rows"]:
        cls = "open" if r["open"] else ""
        segs = (f"<i class='review'style='flex:{r['first_pct']}'></i><i class='merge'style='flex:{r['second_pct']}'></i>"
                if r["split"] else f"<i class='{'review' if r['open'] else 'none'}'style='flex:1'></i>")
        tip = (f"#{r['number']} — opened {r['opened_at']}"
               + (f", reviewed after {r['review_hours']}h, merged {r['merge_hours']}h later"
                  if r["split"] else
                  (", still open" if r["open"] else ", merged with no review recorded"))
               + f" — {r['total_hours']}h in total")
        rows.append(f"<div class='grow'><span class='glabel'>#{_e(r['number'])} {_e(r['role'])}</span>"
                    f"<span class='gtrack'><span class='gspan {cls}' title='{_e(tip)}' "
                    f"style='left:{r['left']}%;width:{round(r['first_pct'] + r['second_pct'], 3)}%'>{segs}</span></span></div>")
    key = "".join(f"<span><s>▶</s>{_e(k['label'])}</span>" if k["id"] == "open" else
                  f"<span><i class='{k['id']}'></i>{_e(k['label'])}</span>" for k in t["legend"])
    table = "".join(
        f"<tr><td>#{_e(r['number'])}</td><td>{_e(r['role'])}</td><td>{_e(r['opened_at'])}</td>"
        f"<td>{_e(r['verdict_at'] or '—')}</td><td>{_e(r['end_at'] or 'still open')}</td>"
        f"<td>{_e(r['total_hours'])}h</td></tr>" for r in t["rows"])
    return (f"<section class='sec'><div class='sechead'><span class='ct'>{t['span_hours']}h</span>"
            f"<h2>Where the time went</h2>"
            f"<p>Every pull request in this window, longest first, on one time axis. This is the only stretch "
            f"of the org's chain with real per-item history — <b>a finding reaching a role, and a merge being "
            f"verified, are not drawn</b>, because those live on a board that keeps only the latest value and "
            f"overwrites it. Drawing the stages that happen to survive would say work begins when a pull "
            f"request opens.</p></div>"
            f"<div style='padding:14px 18px 6px'><div class='gkey'>{key}</div>"
            f"<div class='gplot'><div class='ggrid'>{grid}</div>{''.join(rows)}<div class='gaxis'>{axis}</div></div>"
            f"<p class='gnote'>{t['shown']} of {t['total']} drawn"
            + (f"; the other {t['rest']} were all shorter than {t['rest_under']}h" if t["rest"] else "")
            + f". {t['merged']} merged in this window and <b>{t['no_verdict']} of them carry no review</b>, so "
              f"those bars are one length with no split — not a gap in the measurement, but what happened."
            + (f" {t['open_now']} are still open." if t["open_now"] else "")
            + f"</p><details class='gtable'><summary>The same spans as a table</summary>"
              f"<div class='scroll'><table><thead><tr><th>pr</th><th>opened by</th><th>opened</th>"
              f"<th>first review</th><th>merged</th><th>total</th></tr></thead><tbody>{table}</tbody></table>"
              f"</div></details></div></section>")


def render_command_html(d: dict[str, Any], *, note: str | None = None) -> str:
    """The fleet as one console: a verdict, a signal matrix, and the things only a person can clear.

    The matrix is the glance — one row per org, one cell per signal, each cell a dot AND a reading, because a
    colour alone is not a state. The list below it is the work: every row carries what it is holding up, the
    token that link was made on, and the one place to go and do something about it."""
    sig = d.get("signals") or []
    head = "".join(f"<th>{_e(x)}</th>" for x in sig)
    body = []
    for o in d.get("orgs") or []:
        if not o.get("cells"):
            body.append(f"<tr><td class='org'>{_e(o['id'])}</td>"
                        f"<td class='wide' data-k='read' colspan='{len(sig)}'>not read — "
                        f"{_e(o.get('read'))}</td></tr>")
            continue
        cells = "".join(f"<td data-k='{_e(k)}'><span class='cell {o['cells'][k]['state']}'><b></b>"
                        f"{_e(o['cells'][k]['read'])}</span></td>" for k in sig)
        name = (f"<a href='https://github.com/{_e(o['repo'])}' target='_blank' rel='noopener'>{_e(o['id'])}</a>"
                if o.get("repo") else _e(o["id"]))
        body.append(f"<tr><td class='org'>{name}</td>{cells}</tr>")

    def row(r: dict[str, Any]) -> str:
        c = r["cost"]
        who = c["roles"] + c["sessions"]
        blocks = (f"<div class='blocks'><s>blocks</s><span>{_e(', '.join(who))} "
                  f"<em>— both name</em> <code>{_e(', '.join(c['on']))}</code></span></div>") if who else ""
        a = r.get("action") or {}
        link = (f"<a href='{_e(a['href'])}' target='_blank' rel='noopener'>{_e(a['label'])} ↗</a>"
                if a.get("href") else (f"<a as='span' style='color:var(--muted)'>{_e(a['label'])}</a>"
                                       if a.get("label") else ""))
        return (f"<div class='arow'><div class='achip'>{_e(r['org'])}</div><div>"
                f"<div class='what'>{_md(r['what'])}</div>"
                + (f"<div class='why'>{_md(r['why'][:300])}</div>" if r.get("why") else "")
                + blocks + "</div>"
                f"<div class='side'>{_e(r['ago'])}{link}</div></div>")

    shown = "".join(row(r) for r in d.get("shown") or [])
    more = d.get("more") or []
    rest = (f"<details class='more'><summary>{len(more)} more waiting on you</summary>"
            f"{''.join(row(r) for r in more)}</details>") if more else ""
    return f"""<title>Fleet Command</title>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap">
<style>{CSS}</style>
<div class="wrap">
  <div class="eyebrow">the fleet · read {_e(_clock(d.get('at')))}</div>
  <h1>Command</h1>
  {f'<div class="note">{_e(note)}</div>' if note else ''}
  <div class="verdict {d.get('state', 'RED')}">{_e(d.get('verdict'))}</div>
  <div class="scroll" style="margin-top:20px">
    <table class="fleet"><thead><tr><th>org</th>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>
  </div>
  <div class="act">
    <div class="sechead"><span class="ct">{len(d.get('needs_you') or [])}</span><h2>Waiting on you</h2>
      <p>Nobody in any of these orgs can clear these. Sorted by what each one is holding up, then by age.
         A <b>blocks</b> line means a role or a session is stopped naming the same thing — the token it
         matched on is printed, so the link is yours to judge rather than to trust.</p></div>
    {shown}{rest}
  </div>
  <div class="foot">
    <p>Each org's full reading is its own page. A cell that says <b>not checked</b> is a source this reading
       could not see — absent, not fine — and an org with no row at all could not be read at all.</p>
  </div>
</div>
"""


def render_html(st: dict[str, Any], *, sample_note: str | None = None, live: bool = False,
                source: str = "org status", poll: str | None = None, poll_ms: int = 5000) -> str:
    """One self-contained page from one status dict. No network, no clock: everything is `st`.

    `live=True` adds the subscription layer: the page still renders this reading at rest, and redraws
    when a newer one lands in the artifact's store. The page never writes — org-core sends nothing
    (rule 6), so whoever can reach the org writes the readings.
    """
    from .brief import brief

    c = st.get("coverage") or {}
    tiers = st.get("tiers") or {}
    states = [t["state"] for t in st["tiles"]]
    banner = "RED" if "RED" in states else ("DARK" if "DARK" in states else "CLEAR")
    brief_html = _brief_html(brief(st))

    tiles = []
    for t in st["tiles"]:
        body = _edge_rows(st.get("report") or {}, tiers, st.get("could_not_read") or []) if t["id"] == "chain" and (st.get("report") or {}).get("edges") else ""
        lines = "".join(
            f"<div class='{'hot' if l.startswith(FINDING) else ''}'>{_e(l)}</div>"
            for l in t["lines"]) if (t["id"] != "chain" or not body) else "".join(
            f"<div class='hot'>{_e(l)}</div>" for l in t["lines"] if l.startswith(FINDING))
        tiles.append(
            f"<section class='tile {t['state']}{' span' if t['id'] == 'chain' else ''}'>"
            f"<div class='thead'><span class='chip {t['state']}'>{STATE_MARK[t['state']]} {t['state']}</span>"
            f"<span class='tname'>{_e(t['title'])}</span>"
            f"<span class='tier'>{_e(t['tier'])} — {_e(tiers.get(t['tier'], 'several sources'))}</span></div>"
            f"{body}<div class='lines'>{lines}</div>"
            + (f"<div class='broken'><b>broken looks like:</b> {_e(t['broken_looks_like'])}</div>" if t["state"] != "RED" else "")
            + "</section>")

    note = f"<div class='note'>{_e(sample_note)}</div>" if sample_note else ""
    dark = f" · dark: {', '.join(c.get('dark') or [])}" if c.get("dark") else ""
    age = f" · facts {_e(c.get('facts_gathered_at'))} ({_e(c.get('facts_age_hours'))}h old)" if c.get("facts_gathered_at") else ""
    unread = "".join(f"<p><code>could not read: {_e(x)}</code></p>" for x in (st.get("could_not_read") or []))
    seed = json.dumps(reading_doc(st, source=source), ensure_ascii=False).replace("<", "\\u003c")
    live_head = (f"<span class='live off' id='live'>not live</span>" if live else "")
    if poll:                                  # served: the page asks the reader that took this reading
        js = LIVE_JS.replace("__FINDING__", json.dumps(list(FINDING))).replace("__SOURCE__", SOURCE_POLL.replace("__POLL__", poll).replace("__POLL_MS__", str(int(poll_ms))))
        live = True
    else:                                     # published: the page watches the artifact's own store
        js = LIVE_JS.replace("__FINDING__", json.dumps(list(FINDING))).replace("__SOURCE__", SOURCE_STORE)
    live_history = "<div id='history'></div>" if (live and not poll) else ""
    # the script goes LAST: it paints #tiles, #cover and #unread, which are further down the document
    live_script = (f"<script type='application/json' id='reading'>{seed}</script>{js}" if live else "")
    return f"""<title>Org Status</title>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600&family=IBM+Plex+Sans:wght@400;500;600&display=swap">
<style>{CSS}{LIVE_CSS if live else ""}</style>
<div class="wrap">
  <div class="eyebrow">the org right now {live_head}</div>
  <h1 id="org">{_e(st.get('org'))}</h1>
  <div class="sub"><span id="readat">read at {_e(st.get('at'))}</span><span id="age"></span>{age}</div>
  {note}
  {brief_html}
  {live_history}
  <details class="instrument">
    <summary>The reading this came from — every finding in the tool's own words, with the source it was measured from</summary>
    <p class="sub2">Each tile names the <b>tier</b> it was read from, which is how much that tile's numbers are
       worth: <code>github</code> and <code>git</code> keep history, so their medians are real; the board keeps
       one record per key and overwrites it, so a board-ended number is only what is waiting <i>now</i>. A tile
       nobody could measure is <b>DARK</b> — absent, not failing, and shown with a dashed edge and a muted mark
       rather than a warning colour, so "not measured" reads as neither "fine" nor "broken".</p>
    <div class="banner {banner}" id="banner">
      <div><div class="eyebrow">headline</div><p id="headline">{_e(st.get('headline'))}</p></div>
    </div>
    <div class="grid" id="tiles">{''.join(tiles)}</div>
    <div class="foot">
      <p id="cover"><b>read {_e(c.get('measured'))} of {_e(c.get('tiles'))} tiles</b>{_e(dark)}</p>
      <p>sessions tier: {_e(c.get('sessions_tier'))}</p>
      <span id="unread">{unread}</span>
    </div>
  </details>
  {live_script}
</div>
"""
