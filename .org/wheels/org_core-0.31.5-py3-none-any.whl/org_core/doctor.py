"""`org doctor` (SPEC.md §8): eighteen checks, each derived from a dated failure.

Every check declares what "broken" looks like. A check that is not implemented
says so in the report — a doctor that ran six checks must never print an
all-clear that reads like eighteen. Some checks need facts only a session with
the sessions port can gather (`list_triggers`, `list_sessions`); Doc supplies
them with `--facts`, and without them those checks report NEEDS_FACTS, not PASS.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .manifest import PLACEHOLDER, enabled_roles

PASS, FAIL, DEAD, BLOCKED, UNREACHABLE, NEEDS_FACTS, NOT_IMPLEMENTED = (
    "PASS", "FAIL", "DEAD", "BLOCKED", "UNREACHABLE", "NEEDS_FACTS", "NOT_IMPLEMENTED",
)
BAD = {FAIL, DEAD}


@dataclass
class Finding:
    status: str
    text: str


@dataclass
class Check:
    n: int
    id: str
    title: str
    broken_looks_like: str
    impl: Callable[["Ctx"], list[Finding]] | None = None
    needs_facts: tuple[str, ...] = ()
    phase: str = "P2"


@dataclass
class Ctx:
    repo: Path
    manifest: dict[str, Any]
    facts: dict[str, Any] = field(default_factory=dict)
    now: dt.datetime = field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    _board_cache: dict[str, Any] = field(default_factory=dict)
    # a dead-role drill (SPEC §7): keys the doctor must read as absent, without touching the live board
    drill_absent: set[str] = field(default_factory=set)

    # --- cadence -----------------------------------------------------------
    def period_hours(self, role_id: str) -> float | None:
        entry = self.manifest["roles"][role_id]
        if entry.get("period_hours"):
            return float(entry["period_hours"])
        return cron_period_hours(entry.get("cadence", ""))

    def tolerance(self, role_id: str) -> float:
        return float(self.manifest["roles"][role_id].get("tolerance", 1.5))

    def report_key(self, role_id: str) -> str:
        return self.manifest["roles"][role_id].get("report_key") or f"roles/{role_id}/last-run"

    # --- the coordination port ---------------------------------------------
    def switchboard_env(self) -> dict[str, str]:
        co = self.manifest["ports"]["coordination"]
        env = dict(os.environ)
        env["SWITCHBOARD_WORKSPACE"] = co["workspace"]
        env["SWITCHBOARD_URL"] = co["url"]
        return env

    def record(self, key: str) -> Any:
        """The read layer every check uses for a role record. The dead-role drill injects absence HERE,
        above `board_get`, so it works whether the board is the live hub or a test stub."""
        if key in self.drill_absent:
            return None
        return self.board_get(key)

    def board_get(self, key: str) -> Any:
        """The parsed value at a board key, None if no entry, or raises UnreachablePort."""
        if key in self._board_cache:
            return self._board_cache[key]
        if shutil.which("switchboard") is None:
            raise UnreachablePort("coordination: `switchboard` is not on PATH")
        try:
            out = subprocess.run(["switchboard", "--json", "board", "get", key], capture_output=True, text=True, timeout=30, env=self.switchboard_env())
        except subprocess.TimeoutExpired as e:
            raise UnreachablePort("coordination: switchboard timed out") from e
        text = (out.stdout or "").strip()
        if out.returncode != 0 or not text:
            if "no entry" in (out.stdout + out.stderr):
                self._board_cache[key] = None
                return None
            raise UnreachablePort(f"coordination: board get {key} failed: {(out.stderr or out.stdout).strip()[:200]}")
        if text.startswith("no entry"):
            self._board_cache[key] = None
            return None
        try:
            rec = json.loads(text)
        except json.JSONDecodeError as e:
            raise UnreachablePort(f"coordination: board get {key} returned non-JSON") from e
        self._board_cache[key] = rec
        return rec

    def board_list(self) -> list[dict[str, Any]]:
        if "__list__" in self._board_cache:
            return self._board_cache["__list__"]
        if shutil.which("switchboard") is None:
            raise UnreachablePort("coordination: `switchboard` is not on PATH")
        out = subprocess.run(["switchboard", "--json", "board", "list"], capture_output=True, text=True, timeout=30, env=self.switchboard_env())
        if out.returncode != 0:
            raise UnreachablePort(f"coordination: board list failed: {(out.stderr or out.stdout).strip()[:200]}")
        try:
            rows = json.loads(out.stdout or "[]")
        except json.JSONDecodeError as e:
            raise UnreachablePort("coordination: board list returned non-JSON") from e
        self._board_cache["__list__"] = rows
        return rows


class UnreachablePort(Exception):
    pass


def cron_period_hours(cadence: str) -> float | None:
    """The period of the cron shapes this org uses; None for shapes it cannot read (declare period_hours)."""
    if not cadence or cadence in ("on-demand", "on-wake"):
        return None
    parts = cadence.split()
    if len(parts) != 5:
        return None
    minute, hour, dom, month, dow = parts
    if dom != "*" or month != "*":
        return None
    if hour == "*" and minute.isdigit():
        return 1.0
    m = re.fullmatch(r"\*/(\d+)", hour)
    if m and minute.isdigit() and dow == "*":
        return float(m.group(1))
    if minute.isdigit() and hour.isdigit():
        if dow == "*":
            return 24.0
        if re.fullmatch(r"\d", dow):
            return 168.0
    return None


def parse_ts(s: str | None) -> dt.datetime | None:
    if not s:
        return None
    s = s.strip().replace("Z", "+00:00")
    try:
        d = dt.datetime.fromisoformat(s)
    except ValueError:
        m = re.match(r"(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}))?", s)
        if not m:
            return None
        d = dt.datetime.fromisoformat(m.group(1) + ("T" + m.group(2) if m.group(2) else "T00:00"))
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    return d


def _record_value(rec: Any) -> dict[str, Any] | None:
    if rec is None:
        return None
    v = rec.get("value") if isinstance(rec, dict) else None
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            return {"_raw": v}
    return v if isinstance(v, dict) else None


def clock_roles(ctx: Ctx) -> list[str]:
    return [r for r in enabled_roles(ctx.manifest) if ctx.period_hours(r) is not None]


# --- check implementations ---------------------------------------------------

def _unfinished(ctx: Ctx, role: str, value: dict[str, Any], hub_at: dt.datetime) -> Finding | None:
    """A record opened at step 1 (`status: in_progress`, Lucille's lesson of 2026-09-19: a record written last is never written
    when the session ends first) that no step 3 overwrote within the role's expected run."""
    if str(value.get("status") or "") != "in_progress":
        return None
    expected = float((ctx.manifest["roles"].get(role) or {}).get("expected_run_minutes") or 120)
    minutes = (ctx.now - hub_at).total_seconds() / 60
    if minutes > expected:
        return Finding(FAIL, f"{role}: opened a record at {hub_at.isoformat(timespec='minutes')} (`status: in_progress`) and never finished it — the session ended before its last step, {minutes:.0f} min ago (expected run {expected:.0f} min)")
    return Finding(PASS, f"{role}: running — record opened {minutes:.0f} min ago, not yet finished")


def check_records_fresh(ctx: Ctx) -> list[Finding]:
    out: list[Finding] = []
    clocked = clock_roles(ctx)
    for role in clocked:
        key = ctx.report_key(role)
        rec = ctx.record(key)
        period = ctx.period_hours(role) or 0
        window = dt.timedelta(hours=period * ctx.tolerance(role))
        if rec is None:
            out.append(_missing_record(ctx, role, key, window))
            continue
        hub_at = parse_ts(rec.get("updated_at"))
        value = _record_value(rec) or {}
        claimed_at = parse_ts(value.get("at"))
        if hub_at is None:
            out.append(Finding(FAIL, f"{role}: record at {key} carries no hub timestamp"))
            continue
        unfinished = _unfinished(ctx, role, value, hub_at)
        if unfinished:
            out.append(unfinished)
            continue
        age = ctx.now - hub_at
        if age > window:
            out.append(Finding(DEAD, f"{role}: last record {hub_at.isoformat(timespec='minutes')} is {age.total_seconds()/3600:.1f}h old; expected within {window.total_seconds()/3600:.1f}h"))
        else:
            note = ""
            if claimed_at and abs((claimed_at - hub_at).total_seconds()) > 900:
                note = f" (its own `at` {claimed_at.isoformat(timespec='minutes')} disagrees with the hub's {hub_at.isoformat(timespec='minutes')} by >15 min — a run time that is not the run time)"
            out.append(Finding(PASS, f"{role}: record {age.total_seconds()/3600:.1f}h old{note}"))
    # presence, for the roles no cadence ages: a role with no cadence was aged by nothing, and the one role that most needed
    # the check was the one exempt from it (Lucille, 2026-09-19: `roles/ceo/last-run` absent for four days, found by listing the board)
    for role in enabled_roles(ctx.manifest):
        if role in clocked or (ctx.manifest["roles"].get(role) or {}).get("runtime") not in (None, "session"):
            continue
        key = ctx.report_key(role)
        rec = ctx.record(key)
        if rec is None:
            out.append(Finding(DEAD, f"{role}: no record at all at {key} — a role with no cadence is aged by nothing, so this is a presence reading: never written, or written with a one-day TTL (the MCP `board_set`) and expired — the board cannot tell, and a write after an expiry returns revision 1 like a first write"))
            continue
        hub_at = parse_ts(rec.get("updated_at"))
        value = _record_value(rec) or {}
        if hub_at is None:
            out.append(Finding(FAIL, f"{role}: record at {key} carries no hub timestamp"))
            continue
        out.append(_unfinished(ctx, role, value, hub_at) or Finding(PASS, f"{role}: record {(ctx.now - hub_at).total_seconds()/3600:.1f}h old (no cadence: presence only)"))
    if not out:
        out.append(Finding(FAIL, "no clock-driven role is enabled, so this check has nothing to watch"))
    return out


def _missing_record(ctx: Ctx, role: str, key: str, window: dt.timedelta) -> Finding:
    """A missing record read against the routine, when trigger facts are present: a routine that
    fired and left no record is 'ran and could not report'; one created within the window and
    never fired is waiting for its first fire, not dead (measured 2026-09-17: four NumeroTech
    roles created that morning read DEAD the same evening, a day before their first fire)."""
    triggers = ctx.facts.get("triggers") if isinstance(ctx.facts, dict) else None
    t = None
    if triggers is not None:
        t = _trigger_for(role, ctx.manifest["roles"][role].get("name", role), triggers, _org_id(ctx))
    if t is None:
        return Finding(DEAD, f"{role}: no record at {key} — never ran, ran and could not report, or wrote with a one-day TTL that expired; from here those are the same (a write after an expiry returns revision 1 like a first write)")
    tid = t.get("id")
    last = t.get("last_run") or {}
    fired_at = last.get("fired_at") or t.get("last_fired_at")
    created = parse_ts(t.get("created_at"))
    if fired_at:
        return Finding(DEAD, f"{role}: no record at {key} — routine {tid} fired at {str(fired_at)[:16]}Z and the run wrote nothing; ran and could not report")
    if not t.get("enabled", False):
        return Finding(DEAD, f"{role}: no record at {key} — routine {tid} is disabled and has never fired")
    if created is not None and ctx.now - created <= window:
        return Finding(PASS, f"{role}: no record yet — routine {tid} created {created.isoformat(timespec='minutes')} has not fired; first fire {t.get('next_run_at') or 'unscheduled'}")
    return Finding(DEAD, f"{role}: no record at {key} — routine {tid} created {created.isoformat(timespec='minutes') if created else '?'} has never fired within {window.total_seconds()/3600:.1f}h; the clock is not running")


def check_blocked_surfaced(ctx: Ctx) -> list[Finding]:
    out: list[Finding] = []
    for role in clock_roles(ctx):
        rec = ctx.record(ctx.report_key(role))
        value = _record_value(rec)
        if value is None:
            continue
        if "blocked" not in value:
            out.append(Finding(FAIL, f"{role}: record has no `blocked` field — the one channel that works between sessions is missing"))
        elif value["blocked"]:
            out.append(Finding(BLOCKED, f"{role}: {str(value['blocked'])[:300]}"))
        else:
            out.append(Finding(PASS, f"{role}: not blocked"))
    return out or [Finding(PASS, "no records to read (see check 1)")]


def _facts(ctx: Ctx, name: str) -> Any:
    if name not in ctx.facts:
        raise NeedsFacts(name)
    return ctx.facts[name]


class NeedsFacts(Exception):
    pass


ORG_TAG = " · "   # routine names end in "· <org id>" (routine.spec); two orgs can share one account


def _tag_org(t: dict[str, Any]) -> str | None:
    """The org a routine name is tagged with: the first word after the tag, so that
    "Marshal — dispatcher · numerotech (bound)" is numerotech's (measured 2026-09-17: the org's
    CEO suffixed two dispatcher routines, and an equality test on the whole tag matched neither)."""
    tn = str(t.get("name", ""))
    if ORG_TAG not in tn:
        return None
    tag = tn.rsplit(ORG_TAG, 1)[1].strip().lower()
    return re.split(r"[\s(\[]", tag, 1)[0]


def _trigger_for(role: str, name: str, triggers: list[dict[str, Any]], org: str | None = None) -> dict[str, Any] | None:
    """The trigger named for a role: the enabled, most recently created one tagged with this org;
    else an untagged legacy one whose name carries both the role and the name.

    Never a trigger tagged with another org — measured 2026-09-17, one account carried
    "Doc — doctor · lucille" and "Doc — doctor · numerotech" side by side, and a
    substring match on "doc" alone returned whichever came first. And never a trigger that
    merely mentions the name: the same day, an untagged "Check Marshal's first bound fire"
    (the CEO's own check-in, bound to the CEO's session) was read as the dispatcher's, so
    check 4 reported the CEO's session as Marshal's.
    """
    needles = {role.lower(), name.lower()}

    def mentions_any(t: dict[str, Any]) -> bool:
        tn = str(t.get("name", "")).lower()
        return any(n in tn for n in needles)

    def legacy_named(t: dict[str, Any]) -> bool:
        # Lucille's pre-tag names: "Vera — verifier", "registrar (Nora)", "dispatch hourly (Marshal)".
        # A name that merely mentions the person ("Check Marshal's first bound fire") is not one.
        tn = str(t.get("name", "")).lower()
        r, n = role.lower(), name.lower()
        if r in tn and n in tn:
            return True
        return f"({n})" in tn or tn.startswith(f"{n} —") or tn.startswith(f"{n} -")

    if org:
        tagged = [t for t in triggers if _tag_org(t) == org.lower() and mentions_any(t)]
        if tagged:
            tagged.sort(key=lambda t: (bool(t.get("enabled")), str(t.get("created_at") or "")), reverse=True)
            return tagged[0]
    for t in triggers:
        if _tag_org(t) is None and legacy_named(t):
            return t
    return None


def _org_id(ctx: Ctx) -> str | None:
    return (ctx.manifest.get("org") or {}).get("id")


def check_triggers(ctx: Ctx) -> list[Finding]:
    triggers = _facts(ctx, "triggers")
    out: list[Finding] = []
    fires_fresh: list[str] = []
    for role in clock_roles(ctx):
        entry = ctx.manifest["roles"][role]
        if entry.get("runtime") == "spawned":
            continue
        t = _trigger_for(role, entry["name"], triggers, _org_id(ctx))
        if t is None:
            out.append(Finding(FAIL, f"{role}: no trigger named for it in the org account"))
            continue
        problems = []
        if not t.get("enabled", False):
            problems.append("disabled")
        if entry.get("cadence") and t.get("cron_expression") and t["cron_expression"].split() != entry["cadence"].split():
            problems.append(f"cadence {t['cron_expression']!r} vs manifest {entry['cadence']!r}")
        cfg = (t.get("session_request") or {}).get("config") or {}
        if entry.get("runtime") == "fresh" and not cfg.get("sources"):
            problems.append("sources: [] — fires into a session with no checkout")
        if entry.get("runtime") == "session" and not t.get("persistent_session_id"):
            fires_fresh.append(role)
        last = t.get("last_run") or {}
        if last and last.get("status") and not str(last["status"]).endswith("SUCCEEDED"):
            problems.append(f"last_run {last['status']}")
        if problems or role not in fires_fresh:
            out.append(Finding(FAIL if problems else PASS, f"{role}: {t.get('id')} " + ("; ".join(problems) if problems else "matches")))
    if fires_fresh:
        out.append(Finding(FAIL, declared_session_fires_fresh(fires_fresh)))
    return out


def declared_session_fires_fresh(roles: list[str]) -> str:
    """One line for every role the manifest declares `runtime: session` whose routine fires a fresh session per run.
    Both orgs read six such roles in check 3 and six more in check 4 every day from 2026-09-17 (row 98): a standing
    gap the org cannot clear by itself — the routines are the account holder's (decision 7) — printed as twelve deaths.
    The way out is named here so the operator file can carry it as one item, not twelve."""
    return (f"{len(roles)} role(s) declared `runtime: session` fire a fresh session per run: {', '.join(roles)} — "
            f"rebind each routine to a persistent session (the account holder's act, decision 7) or declare `runtime: fresh` "
            f"in org.yaml; either clears this line, and until then their listeners cannot exist")


def check_sessions_alive(ctx: Ctx) -> list[Finding]:
    """Check 4. The listener half reads the tempo facts alone and prints first: NumeroTech 2026-09-20 had a dispatcher
    alive and unroutable for ~14 h — record fresh, `coord/tempo/agents` entry stale — while this check read NEEDS_FACTS,
    because `_facts(ctx, "triggers")` raised before the roster half ever ran (row 112)."""
    listening = _listening_findings(ctx)
    try:
        triggers = _facts(ctx, "triggers")
        sessions = {s.get("id"): s for s in _facts(ctx, "sessions")}
    except NeedsFacts as e:
        if listening:
            return listening + [Finding(NEEDS_FACTS, f"the bound-session half needs `{e}` facts from a session holding the sessions port; the listener half above read from the tempo facts")]
        raise
    out: list[Finding] = []
    fires_fresh: list[str] = []
    for role in enabled_roles(ctx.manifest):
        entry = ctx.manifest["roles"][role]
        if entry.get("runtime") != "session":
            continue
        t = _trigger_for(role, entry["name"], triggers, _org_id(ctx))
        sid = (t or {}).get("persistent_session_id")
        if not sid:
            # a role on cadence `on-wake` is woken by a person or the hub, never by a cron trigger; faulting it for
            # lacking one read NumeroTech's CEO as broken on 2026-09-17 while he was working
            if str(entry.get("cadence") or "").strip() in ("on-wake", "on-demand", ""):
                out.append(Finding(PASS, f"{role}: on-wake — woken by a person or the hub, no trigger required (a poke-only trigger bound to its session would let the doctor see that session)"))
            elif t is None:
                out.append(Finding(FAIL, f"{role}: no trigger binds a persistent session"))
            else:
                fires_fresh.append(role)
            continue
        s = sessions.get(sid)
        if s is None:
            out.append(Finding(NEEDS_FACTS, f"{role}: bound session {sid} is not among the {len(sessions)} row(s) read — dead, another account, or "
                               "simply older than the newest-N a listing returns, which is what a persistent session becomes by being persistent "
                               "(NumeroTech 2026-09-21: both bound sessions were alive and in no listing this account could take). Call the tool "
                               "ending in `__get_session` on the id and append its row to `sessions`; a FAIL here without that call is a guess"))
        elif str(s.get("session_status", "")).endswith("ARCHIVED"):
            out.append(Finding(FAIL, f"{role}: bound session {sid} is archived; the trigger fires into a dead conversation"))
        else:
            out.append(Finding(PASS, f"{role}: {sid} {s.get('session_status')}"))
    if fires_fresh:
        out.append(Finding(FAIL, declared_session_fires_fresh(fires_fresh)))
    out += [l for l in listening if not any(l.text.startswith(f"{r}:") for r in fires_fresh)]   # a fresh-firing role has no listener to lapse
    return out or [Finding(PASS, "no session-runtime roles enabled")]


def _bound_session_ids(ctx: Ctx) -> dict[str, str]:
    """`role → session id` for every session-runtime role whose trigger fires into a persistent session. Empty when the
    triggers facts are absent: absence of the reading is not a reading."""
    try:
        triggers = _facts(ctx, "triggers")
    except NeedsFacts:
        return {}
    out: dict[str, str] = {}
    for role in enabled_roles(ctx.manifest):
        entry = ctx.manifest["roles"][role]
        if entry.get("runtime") != "session":
            continue
        sid = (_trigger_for(role, entry["name"], triggers, _org_id(ctx)) or {}).get("persistent_session_id")
        if sid:
            out[role] = str(sid)
    return out


def _listening_findings(ctx: Ctx, skip: set[str] = frozenset()) -> list[Finding]:
    """Every persistent role: registered in coord/tempo/agents and on the roster (a listener parked), or not. Read from the
    tempo facts when they carry the roster; silent when they do not — absence of the reading is not a reading."""
    from . import tempo as tp
    try:
        facts = _tempo_facts(ctx)
    except NeedsFacts:
        return []
    out: list[Finding] = []
    for l in tp.listeners(facts, ctx.now):
        if l["role"] not in ctx.manifest["roles"] or not ctx.manifest["roles"][l["role"]].get("enabled", True) or l["role"] in skip:
            continue   # a role whose routine fires fresh sessions has no listener to lapse; the one line above says so
        if not l.get("agent_id"):
            out.append(Finding(FAIL, f"{l['role']}: never registered in {tp.AGENTS_KEY} — no session of it has run `org tempo register`; a DM cannot reach it"))
        elif not l.get("roster_read"):
            out.append(Finding(PASS, f"{l['role']}: registered as {l['agent_id']} ({l['registered_age_hours']}h ago); roster unread, so listening is unknown"))
        elif l["listening"]:
            out.append(Finding(PASS, f"{l['role']}: listening as {l['agent_id']} (parked until {l['listen_until']})"))
        else:
            out.append(Finding(FAIL, f"{l['role']}: registered as {l['agent_id']} but NOT on the roster — its listener lapsed (parked until {l['listen_until']}, registered {l['registered_age_hours']}h ago); unreachable until its cron"))
    return out


def check_on_org_account(ctx: Ctx) -> list[Finding]:
    triggers = _facts(ctx, "triggers")
    expected = clock_roles(ctx)
    seen = sum(1 for r in expected if _trigger_for(r, ctx.manifest["roles"][r]["name"], triggers, _org_id(ctx)))
    if seen == 0 and expected:
        return [Finding(FAIL, f"sees 0 of {len(expected)} declared role triggers — wrong account, or nothing installed yet")]
    return [Finding(PASS if seen == len(expected) else FAIL, f"sees triggers for {seen} of {len(expected)} clock roles")]


def check_ports(ctx: Ctx) -> list[Finding]:
    out: list[Finding] = []
    try:
        rows = ctx.board_list()
        out.append(Finding(PASS, f"coordination: board readable ({len(rows)} keys)"))
    except UnreachablePort as e:
        out.append(Finding(UNREACHABLE, str(e)))
    cli = ctx.manifest["ports"]["work_store"]["cli"].split()
    if shutil.which(cli[0]) is None and not (ctx.repo / cli[-1]).exists():
        out.append(Finding(UNREACHABLE, f"work_store: `{ctx.manifest['ports']['work_store']['cli']}` not found"))
    else:
        try:
            r = subprocess.run([*cli, "validate", "--source", "files"], cwd=ctx.repo, capture_output=True, text=True, timeout=120)
            out.append(Finding(PASS if r.returncode == 0 else FAIL, "work_store: validate " + (r.stdout or r.stderr).strip().splitlines()[-1][:160] if (r.stdout or r.stderr).strip() else f"work_store: validate exit {r.returncode}"))
        except Exception as e:  # noqa: BLE001 — any failure to run the CLI is the finding
            out.append(Finding(UNREACHABLE, f"work_store: {e}"))
    out.append(Finding(PASS if shutil.which("repoctx") else UNREACHABLE, "code_context: repoctx " + ("on PATH" if shutil.which("repoctx") else "not on PATH")))
    out.append(Finding(PASS if shutil.which("gh") else UNREACHABLE, "vcs: gh " + ("on PATH" if shutil.which("gh") else "not on PATH")))
    out.append(probe_tickets(ctx))
    out.append(probe_prod_read(ctx))
    out.append(probe_checks(ctx))
    out.append(probe_suite(ctx))
    return out


def probe_suite(ctx: Ctx) -> Finding:
    """The suite this runtime has against what the tree vendors and pins (SPEC §18): every module's version, and the wiring."""
    from . import suite as su
    from .lock import read as read_lock

    try:
        rows = su.check(ctx.repo, ctx.manifest, lock=read_lock(ctx.repo), runtime=True)
    except Exception as e:  # noqa: BLE001 — a probe that cannot run is the finding
        return Finding(UNREACHABLE, f"suite: could not probe: {e}")
    bad = [r for r in rows if r["ok"] is False]
    have = ", ".join(f"{r['id']} {r['found']}" for r in rows if r.get("policy") in ("vendored", "pinned", "tracking") and r.get("found"))
    if bad:
        return Finding(FAIL, f"suite: {len(bad)} of {len(rows)} rows bad — " + "; ".join(f"{r['id']}: {r['why']}" for r in bad[:5]) + (f" (present: {have})" if have else ""))
    return Finding(PASS, f"suite: {have or 'no pip modules enabled'}; wiring ok")


def _run(cmd, cwd, timeout=60):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)


def unfilled_value(value: str) -> bool:
    """True when a manifest value is still the `<...>` marker `org init` wrote.

    A probe must never read one as a declaration. Measured 2026-09-22 against
    0.24.2: `prod_read` returned PASS — "declared <how production is read,
    read-only> — nothing to probe" — for a manifest nobody had filled in.
    `validate` refuses such a manifest since 0.25.0, so this is the second line:
    it catches a placeholder that arrives by any other route.
    """
    return bool(PLACEHOLDER.search(str(value)))


def probe_tickets(ctx: Ctx, run=None, gh_present: bool | None = None) -> Finding:
    """The tickets port answers, or says why not. Silence here let NumeroTech's missing `ticket` label go unread on 2026-09-17."""
    from . import tickets as tk

    port = ctx.manifest["ports"].get("tickets") or {"tool": "absent"}
    tool = port.get("tool", "absent")
    if tool == "github-issues":
        wanted = tk.wanted_labels(port)
        repo = (ctx.manifest.get("org") or {}).get("repo")
        if not repo:
            return Finding(FAIL, "tickets: github-issues declared without org.repo")
        if gh_present is None:
            gh_present = shutil.which("gh") is not None
        if not gh_present:
            return Finding(UNREACHABLE, f"tickets: gh not on PATH — cannot see whether {wanted} exist in {repo}")
        try:
            existing = tk.gh_labels(repo, run or tk._run)
        except Exception as e:  # noqa: BLE001 — any failure to list is the finding
            return Finding(UNREACHABLE, f"tickets: {e}")
        missing = tk.label_plan(existing, wanted)
        tpl = port.get("template")
        tpl_missing = bool(tpl) and not (ctx.repo / str(tpl)).exists()
        if missing or tpl_missing:
            parts = []
            if missing:
                parts.append(f"labels missing in {repo}: {', '.join(missing)} — nothing can be filed under them and nothing read from them")
            if tpl_missing:
                parts.append(f"issue form `{tpl}` missing — a person has no way to file one; `org tickets init` writes it")
            return Finding(FAIL, "tickets: " + "; ".join(parts))
        return Finding(PASS, f"tickets: {len(wanted)} labels exist in {repo}" + (f", form `{tpl}` present" if tpl else ""))
    if tool == "in-app":
        table = port.get("table")
        tables = ctx.facts.get("tables")
        if table and tables is not None:   # a session with the read port measured the store: that decides
            if table in set(tables):
                return Finding(PASS, f"tickets: in-app table `{table}` exists")
            planned = port.get("planned_by")
            return Finding(FAIL, f"tickets: in-app table `{table}` does not exist" + (f" — planned by roadmap item `{planned}`; until it lands there are no tickets here" if planned else ""))
        cli = str(port.get("cli") or "").split()
        if cli:   # an org with its own tool (Lucille): the tool present in the checkout is the port answering
            script = cli[-1]
            if (ctx.repo / script).exists():
                return Finding(PASS, f"tickets: in-app cli `{port.get('cli')}` present")
            return Finding(UNREACHABLE, f"tickets: in-app cli `{port.get('cli')}` not found in the checkout")
        if table:
            return Finding(NEEDS_FACTS, f"tickets: in-app table `{table}` — pass --facts with `tables` (public tables the read port sees) to know whether it exists")
        return Finding(FAIL, "tickets: in-app declared with neither a `cli` nor a `table`")
    if unfilled_value(tool):
        return Finding(FAIL, f"tickets: `{tool}` is the marker `org init` wrote, not a declaration")
    return Finding(PASS, f"tickets: declared {tool} — nothing to probe")


def probe_prod_read(ctx: Ctx) -> Finding:
    port = ctx.manifest["ports"].get("prod_read") or {}
    method = str(port.get("method", "absent"))
    if method.startswith("supabase-mcp"):
        tools = ctx.facts.get("tools")
        if tools is None:
            return Finding(NEEDS_FACTS, "prod_read: supabase-mcp — pass --facts with `tools` (the tool names this session holds) to see whether one ending in __execute_sql is held")
        held = [t for t in tools if str(t).endswith("__execute_sql")]
        return Finding(PASS if held else FAIL, "prod_read: supabase-mcp " + (f"held as {held[0]}" if held else "NOT held by this session — no production read is possible from here"))
    if method.startswith("ssh-psql"):
        setup = port.get("setup")
        if setup and (ctx.repo / str(setup)).exists():
            return Finding(PASS, f"prod_read: {method} — setup `{setup}` present (reachability is a session matter)")
        return Finding(UNREACHABLE, f"prod_read: {method} — setup script `{setup}` missing from the checkout")
    if unfilled_value(method):
        return Finding(FAIL, f"prod_read: `{method}` is the marker `org init` wrote, not a declaration — no production read is declared")
    if method == "absent":
        return Finding(PASS, "prod_read: declared absent — nothing to probe")
    if method.startswith("git-ref"):
        # For a library or a tool there is no deployed service, and the production
        # state IS the default branch. That is a true thing to declare and until
        # 0.25.3 there was no way to say it: `absent` is false (there is a
        # production state), and the free-text method 0.25.2 met returned
        # UNREACHABLE forever. Measured 2026-09-22 on the first third-party install
        # (`gald33/roadmap-core`, another account): it declared "origin/main HEAD
        # (no deployed service; the default branch is the production state)",
        # which 0.25.1 passed vacuously and 0.25.2 could not express.
        #
        # Probeable, so it is a real check: the ref has to resolve in this checkout.
        # Broken looks like: `origin/<default_branch>` does not resolve — a shallow
        # or ref-less clone, or a renamed default branch — so the thing the org
        # calls production cannot be read from here.
        #
        # A tool deploys no service, but it does ship: what is built from the branch
        # is production too (the operator, 2026-09-23). For org-core that is the wheel
        # the orgs vendor, and `shipped_wheel` reads it against the ref's source.
        branch = str(ctx.manifest["org"].get("default_branch", "main"))
        ref = f"origin/{branch}"
        try:
            r = _run(["git", "rev-parse", "--verify", "--quiet", f"{ref}^{{commit}}"], cwd=str(ctx.repo))
        except Exception as e:
            return Finding(UNREACHABLE, f"prod_read: {method} — could not run git here ({type(e).__name__})")
        if not (r.returncode == 0 and r.stdout.strip()):
            return Finding(FAIL, f"prod_read: {method} — {ref} does not resolve in this checkout, so what this org calls production cannot be read here")
        head = f"prod_read: {method} — {ref} resolves ({r.stdout.strip()[:8]})"
        wheel = shipped_wheel(ctx.repo, ref)
        if wheel is None:
            return Finding(PASS, f"{head}; the default branch is the production state")
        status, text = wheel
        return Finding(status, f"{head}; {text}")
    # An unrecognised method is not a pass. This probe knows `supabase-mcp`, `ssh-psql`
    # and `absent`; for anything else it has no way to tell working from broken, and
    # saying PASS claims knowledge it does not have. Measured 2026-09-22 against 0.24.2:
    # the old fallthrough returned PASS for the literal string
    # `<how production is read, read-only>`.
    return Finding(UNREACHABLE, f"prod_read: declared `{method}` — this probe knows supabase-mcp, ssh-psql, git-ref and absent, so it cannot check this one")


_WHEEL_RE = re.compile(r"\.org/wheels/org_core-(?P<v>[^-/]+)-py3-none-any\.whl")


def shipped_wheel(repo: Path, ref: str) -> tuple[str, str] | None:
    """The other half of org-core's production: the wheel on `ref` is what `ref`'s source builds.

    org-core ships `main` and the wheel built from it, which every installed org vendors
    and runs — org-core's own install included. The operator, 2026-09-23: "origin/main
    and the wheels are products we create". The `git-ref` probe read only the first half
    (the ref resolves); `main` carried `org_core-0.29.1` while its source declared 0.31.2
    (8fa31bb, measured the same day) and every check passed. The wheel is reproducible
    byte for byte (row 60), so "built from this ref" is checkable file by file.

    Returns None when `ref` is not org-core's source — another org's vendored wheel is
    org-core's product, not that org's, and its provenance is read from org-core. Else
    (status, sentence).

    Broken looks like: PASS while the wheel on `ref` has a version other than the one
    `org_core/__init__.py` declares there, carries a package file whose bytes differ
    from `ref`'s, lacks one `ref` carries, or when `ref` vendors two wheels or none.
    """
    import io
    import zipfile

    from .vendor import _SKIP_DIRS, _SKIP_SUFFIXES

    try:
        ls = subprocess.run(["git", "ls-tree", "-r", "--name-only", ref, "--", "org_core/", ".org/wheels/"],
                            cwd=str(repo), capture_output=True, text=True, timeout=60)
    except Exception as e:
        return UNREACHABLE, f"wheel: could not list {ref} ({type(e).__name__})"
    if ls.returncode != 0:
        return UNREACHABLE, f"wheel: could not list {ref}: {ls.stderr.strip()[:160]}"
    names = ls.stdout.splitlines()
    if "org_core/__init__.py" not in names:
        return None
    source = [n for n in names if n.startswith("org_core/")
              and not any(part in _SKIP_DIRS for part in n.split("/")) and Path(n).suffix not in _SKIP_SUFFIXES]
    wheels = [n for n in names if _WHEEL_RE.fullmatch(n)]
    if len(wheels) != 1:
        return FAIL, (f"wheel: {ref} is org-core's source and vendors {len(wheels)} wheels ({', '.join(wheels) or 'none'}) — "
                      "the product the orgs run is not one artifact on the default branch")

    def blob(path: str) -> bytes | None:
        r = subprocess.run(["git", "show", f"{ref}:{path}"], cwd=str(repo), capture_output=True, timeout=60)
        return r.stdout if r.returncode == 0 else None

    m = re.search(r'__version__\s*=\s*"([^"]+)"', (blob("org_core/__init__.py") or b"").decode("utf-8", "replace"))
    declared = m[1] if m else None
    wheel_v = _WHEEL_RE.fullmatch(wheels[0])["v"]
    if wheel_v != declared:
        return FAIL, (f"wheel: {ref} vendors {wheel_v} while its source declares {declared} — the wheel the orgs run is "
                      f"not the one {ref} builds; re-vendor from {ref} (`org upgrade --repo .`) and commit it")
    data = blob(wheels[0])
    try:
        zf = zipfile.ZipFile(io.BytesIO(data or b""))
    except zipfile.BadZipFile:
        return FAIL, f"wheel: {wheels[0]} on {ref} is not a readable wheel"
    packed = {n: zf.read(n) for n in zf.namelist() if n.startswith("org_core/")}
    differ = sorted(n for n in packed if n in source and packed[n] != blob(n))
    extra = sorted(set(packed) - set(source))
    missing = sorted(set(source) - set(packed))
    if differ or extra or missing:
        parts = [f"{label}: {', '.join(xs[:3])}{' …' if len(xs) > 3 else ''}"
                 for label, xs in (("differs from source", differ), ("not in source", extra), ("missing from the wheel", missing)) if xs]
        return FAIL, (f"wheel: {wheels[0]} is not what {ref} builds — " + "; ".join(parts)
                      + f". An org running it runs code no commit of {ref} carries")
    return PASS, f"wheel: {wheels[0]} is what {ref} builds ({len(packed)} package files, byte for byte)"


def probe_checks(ctx: Ctx) -> Finding:
    from . import checks as ck

    port = ctx.manifest["ports"].get("checks") or {"tool": "absent"}
    tool = port.get("tool", "absent")
    if tool == "checks-core":
        try:
            checks = ck.load_registry(ctx.repo / port.get("registry", ck.DEFAULT_REGISTRY))
            ledger = ck.load_ledger(ctx.repo / port.get("ledger", ck.DEFAULT_LEDGER))
        except (ck.RegistryError, OSError) as e:
            return Finding(FAIL, f"checks: checks-core registry unreadable: {e}")
        problems = ck.ledger_problems(checks, ledger)
        return Finding(FAIL if problems else PASS, f"checks: checks-core {len(checks)} checks, " + ("; ".join(problems) if problems else "ledger consistent"))
    if tool == "in-app":
        runner = port.get("runner")
        if runner and (ctx.repo / str(runner)).exists():
            return Finding(PASS, f"checks: in-app runner `{runner}` present")
        return Finding(UNREACHABLE, f"checks: in-app runner `{runner}` missing from the checkout")
    if unfilled_value(tool):
        return Finding(FAIL, f"checks: `{tool}` is the marker `org init` wrote, not a declaration")
    return Finding(PASS, "checks: declared absent — nothing to probe")


def check_board_expiring(ctx: Ctx) -> list[Finding]:
    # only the RECURRING record keys: per-PR and per-item keys (roles/reviewer/pr-1529, roles/builder/<item>) are
    # one-shot by design and expiring is their normal end — flagging them taught a false alarm on the first live run
    rows = ctx.board_list()
    recurring = [r for r in rows if str(r.get("key", "")).startswith("roles/") and str(r.get("key", "")).endswith("/last-run")]
    soon = [r for r in recurring if 0 < float(r.get("expires_in", 0) or 0) < 86400]
    if not soon:
        return [Finding(PASS, f"{len(recurring)} recurring role keys, none expiring within 24h")]
    return [Finding(FAIL, f"{r['key']} expires in {float(r['expires_in'])/3600:.1f}h and nothing has refreshed it") for r in soon]


def check_knobs(ctx: Ctx) -> list[Finding]:
    rows = [r for r in ctx.board_list() if str(r.get("key", "")).startswith("org/knobs/")]
    if not rows:
        return [Finding(PASS, "no runtime knob overrides active")]
    out = []
    ranges = ctx.manifest.get("knobs", {})
    for r in rows:
        name = r["key"].split("org/knobs/", 1)[1]
        v = _record_value(r) or {}
        rng = (ranges.get(name) or {}).get("range")
        val = v.get("value")
        bad = rng is not None and isinstance(val, (int, float)) and not (rng[0] <= val <= rng[1])
        out.append(Finding(FAIL if bad else PASS, f"{name}={val!r} reason={v.get('reason','?')!r} expires in {float(r.get('expires_in',0) or 0)/3600:.1f}h" + (" — OUTSIDE its declared range" if bad else "")))
    return out


# Lucille writes `account manager` and `checks watch` with a space where the role id has a hyphen; accept both
SECTION_RE = re.compile(r"^### (?P<name>[^—\n]+) — (?P<role>[A-Za-z][A-Za-z -]*[A-Za-z]) · (?P<label>.+)$", re.M)   # either case: `Link — CEO · …` read as "no section" (NumeroTech 2026-09-20, row 112)
LAST_RUN_RE = re.compile(r"^- \*\*last run:\*\* (?P<when>[^\n]+)$", re.M)


def _open_prs_touching(ctx: Ctx, rel: str) -> list[str]:
    """Open PRs (from the tempo facts, if present) whose files include `rel` — the difference between 'never ran' and
    'ran, and the stamp is in a pull request nobody merged' (measured 2026-09-19, row 65)."""
    from . import tempo as tp
    facts = ctx.facts.get("tempo") if isinstance(ctx.facts.get("tempo"), dict) else None
    if facts is None:
        try:
            facts = tp.latest_facts(ctx.repo)
        except Exception:  # noqa: BLE001 — a broken facts file must not break an unrelated check
            facts = None
    if not facts:
        return []
    out = []
    for p in sorted(facts.get("prs", []), key=lambda p: p.get("opened_at") or ""):
        if p.get("state") == "open" and not p.get("draft") and rel in (p.get("files") or []):
            age = tp.hours(p.get("opened_at"), ctx.now.isoformat())
            out.append(f"#{p['number']} ({p.get('author_role') or 'unknown'}, open {age}h)")
    return out


def check_operator_file(ctx: Ctx) -> list[Finding]:
    rel = ctx.manifest["ports"]["operator_surface"]
    p = ctx.repo / rel
    if not p.exists():
        return [Finding(FAIL, f"{rel} does not exist — the operator has nothing to read")]
    text = p.read_text()
    sections = {m["role"].lower().replace(" ", "-"): (m.start(), m["name"].strip()) for m in SECTION_RE.finditer(text)}   # `CEO` is `ceo`
    unmerged = _open_prs_touching(ctx, rel)
    out: list[Finding] = []
    for role in clock_roles(ctx):
        if role not in sections:
            out.append(Finding(FAIL, f"{role}: no section in {rel}"))
            continue
        start = sections[role][0]
        tail = text[start:start + 2000]
        m = LAST_RUN_RE.search(tail)
        when_text = (m["when"] if m else "").strip()
        if when_text.lower().startswith("never"):
            rest = when_text[5:].lstrip(" —-:").strip()
            out.append(Finding(FAIL, (f"{role}: never ran per main — {rest[:140]}" if rest else f"{role}: never ran per main") + " (since 0.19.0 the chair renders this file from the board: `org operator render`; a `never` beside a live record is the chair not rendering)"))
            continue
        when = parse_ts(when_text) if m else None
        if when is None:
            out.append(Finding(FAIL, f"{role}: section has no readable `last run` date"))
            continue
        window = dt.timedelta(hours=(ctx.period_hours(role) or 24) * ctx.tolerance(role))
        age = ctx.now - when
        out.append(Finding(FAIL if age > window else PASS, f"{role}: stamped {when.date()} ({age.total_seconds()/3600:.0f}h ago)"))
    stale = any(f.status == FAIL for f in out)
    out.append(_dashboard_finding(ctx, rel))
    if unmerged and stale:
        out.append(Finding(FAIL, f"{rel} is rewritten in open " + ", ".join(unmerged[:6]) + " — a stamp in an unmerged PR is not on main; 'never ran per main' above may be 'ran, unmerged'"))
    return out


def _last_commit(ctx: Ctx, rel: str) -> dt.datetime | None:
    try:
        r = _run(["git", "log", "-1", "--format=%cI", "--", rel], cwd=ctx.repo, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return None
    return parse_ts(r.stdout.strip()) if r.returncode == 0 and r.stdout.strip() else None


def _dashboard_finding(ctx: Ctx, operator_rel: str) -> Finding:
    """The org's page, beside the operator file it rides with (0.25.4).

    The chair re-reads the page whenever the render changed the operator file and
    commits both together, so on main the page's last commit is never older than
    the file's. Broken looks like: no page at `org.paths.dashboard`, or a page whose
    last commit predates the operator file's — the chair rendering without
    `--dashboard`, or committing one file and not the other. Folded into check 16
    rather than numbered, so `ran N of 21` still counts what it always counted.
    """
    rel = (ctx.manifest.get("org", {}).get("paths", {}) or {}).get("dashboard", "docs/human/dashboard.html")
    if not (ctx.repo / rel).is_file():
        return Finding(FAIL, f"{rel}: no page — the chair's step 4 renders it with `org operator render --dashboard` and commits it with the operator file")
    page, surface = _last_commit(ctx, rel), _last_commit(ctx, operator_rel)
    if page and surface and page < surface:
        return Finding(FAIL, f"{rel}: last committed {page.isoformat(timespec='minutes')}, before {operator_rel} ({surface.isoformat(timespec='minutes')}) — the page is behind the file it rides with")
    return Finding(PASS, f"{rel}: present" + (f", committed {page.isoformat(timespec='minutes')}" if page else ", not committed yet"))


def check_self(ctx: Ctx) -> list[Finding]:
    key = ctx.manifest["roles"].get("doctor", {}).get("report_key") or "roles/doctor/last-run"
    rec = ctx.record(key)
    if rec is None:
        return [Finding(FAIL, f"no previous doctor record at {key} — first run, or the last one died; either way say so")]
    hub_at = parse_ts(rec.get("updated_at"))
    v = rec.get("value")
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except json.JSONDecodeError:
            v = {}
    v = v if isinstance(v, dict) else {}
    if str(v.get("status") or "") == "in_progress":
        # NumeroTech 2026-09-20 (row 112): step 1 opens the placeholder minutes before step 3 runs this check, and the
        # board keeps one record per key, so "a previous record exists" was reading the run's own placeholder
        at = parse_ts(v.get("at")) or hub_at
        age_h = round((ctx.now - at).total_seconds() / 3600, 1) if at else None
        prev = _last_ledger_run(ctx)
        where = f"the last finished run in .org/runs/doctor.jsonl started {prev}" if prev else "no finished run in .org/runs/doctor.jsonl"
        if age_h is not None and age_h < 6:
            return [Finding(FAIL, f"the record at {key} is this run's own placeholder (status in_progress, {age_h}h old) — the previous run's record is gone from the board; {where}")]
        return [Finding(FAIL, f"the record at {key} is a placeholder a previous run opened and never finished (status in_progress, {age_h}h old) — that run died before its step 3; {where}")]
    return [Finding(PASS, f"previous doctor record {hub_at.isoformat(timespec='minutes') if hub_at else '?'}" + (f", finished ({v.get('status')})" if v.get("status") else ""))]


def _last_ledger_run(ctx: Ctx) -> str | None:
    """The `started_at` of the newest row in .org/runs/doctor.jsonl — the durable half of a run the board has overwritten."""
    p = ctx.repo / ".org" / "runs" / "doctor.jsonl"
    if not p.is_file():
        return None
    last = None
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(row, dict) and row.get("started_at"):
            last = str(row["started_at"])
    return last


def check_checks_registry(ctx: Ctx) -> list[Finding]:
    from . import checks as ck

    port = ctx.manifest["ports"].get("checks") or {"tool": "absent"}
    tool = port.get("tool", "absent")
    if tool == "absent":
        return [Finding(PASS, "checks port declared absent — no production assertion exists for this org; the verifier records could_not_reach: [checks]")]
    if tool != "checks-core":
        return [Finding(NOT_IMPLEMENTED, f"checks tool `{tool}` is read by the checks-watch role over its declared invocation, not by the doctor")]
    today = ctx.now.date()
    try:
        checks = ck.load_registry(ctx.repo / port.get("registry", ck.DEFAULT_REGISTRY))
        ledger = ck.load_ledger(ctx.repo / port.get("ledger", ck.DEFAULT_LEDGER))
    except ck.RegistryError as e:
        return [Finding(FAIL, f"registry unreadable: {e}")]
    out = [Finding(FAIL, p) for p in ck.ledger_problems(checks, ledger)]
    history = ck.read_results(ctx.repo / port.get("results", ck.DEFAULT_RESULTS))
    if not history:
        unmerged = _open_prs_touching(ctx, port.get("results", ck.DEFAULT_RESULTS))
        out.append(Finding(FAIL, f"{len(checks)} checks declared and no results log on main" + (" — the log waits in open " + ", ".join(unmerged[:4]) if unmerged else ": the registry has never been run")))
        return out
    last = max(r["date"] for r in history)
    age = (today - dt.date.fromisoformat(last)).days
    out.append(Finding(FAIL if age > 2 else PASS, f"registry last run {last} ({age}d ago)"))
    rep = ck.report(checks, history, today, ctx.repo / "roadmap" / "items")
    c = rep["counts"]
    out.append(Finding(PASS, f"pass {c['pass']} fail {c['fail']} (high {rep['high']}) pending {c['pending']} expired {c['expired']} inconclusive {c['inconclusive']} error {c['error']}"))
    for cid in rep["failures_without_item"]:
        out.append(Finding(FAIL, f"{cid}: failing with no owning roadmap item"))
    for line in rep["vacuous_unflagged"]:
        out.append(Finding(FAIL, line))
    for cid in rep["expired_while_red"]:
        out.append(Finding(FAIL, f"{cid}: expired while red — it will never be reported again"))
    for line in rep["worsening"]:
        out.append(Finding(FAIL, f"worsening: {line}"))
    if rep["oldest_failure"] and rep["oldest_failure"]["days"] is not None:
        out.append(Finding(PASS, f"oldest failure {rep['oldest_failure']['id']}, red {rep['oldest_failure']['days']}d"))
    return out


def _gh_json(path: str) -> Any:
    """One REST call through gh; GraphQL is not reachable from a Claude Code session. Tests replace this."""
    if shutil.which("gh") is None:
        raise UnreachablePort("gh not on PATH")
    p = subprocess.run(["gh", "api", path], capture_output=True, text=True, timeout=60)
    if p.returncode != 0:
        raise UnreachablePort(f"gh api {path}: {(p.stderr or p.stdout).strip()[:200]}")
    return json.loads(p.stdout or "null")


QUEUED_ALARM_HOURS = 2.0   # a job that no runner picks up within this reads as an alarm, not as pending


def check_own_ci(ctx: Ctx) -> list[Finding]:
    """Check 13: the org's own workflows on the default branch — red for N runs is an alarm nobody answered."""
    slug = ctx.manifest["org"]["repo"]
    branch = ctx.manifest["org"]["default_branch"]
    try:
        runs = (_gh_json(f"repos/{slug}/actions/runs?branch={branch}&per_page=100") or {}).get("workflow_runs", [])
    except UnreachablePort as e:
        return [Finding(UNREACHABLE, f"gh: {e}")]
    by_wf: dict[str, list[dict[str, Any]]] = {}
    for r in runs:   # newest first, as the API returns them
        by_wf.setdefault(str(r.get("name") or r.get("workflow_id")), []).append(r)
    out: list[Finding] = []
    for name, rs in sorted(by_wf.items()):
        done = [r for r in rs if r.get("status") == "completed"]
        pending = [r for r in rs if r.get("status") in ("queued", "waiting", "pending", "requested")]
        if pending:   # org-core PR #2, 2026-09-20: two jobs queued for hours because no runner served the repository — and only completed runs were read
            oldest = min((r.get("created_at") or "") for r in pending)
            age_h = round((ctx.now - parse_ts(oldest)).total_seconds() / 3600, 1) if parse_ts(oldest) else None
            if age_h is not None and age_h >= QUEUED_ALARM_HOURS:
                out.append(Finding(FAIL, f"{name}: {len(pending)} run(s) queued on {branch}, oldest {age_h}h — no runner serves this repository, or the queue is stuck; a queue is not a green"))
                continue
        if not done:
            if pending:
                out.append(Finding(PASS, f"{name}: {len(pending)} run(s) queued on {branch}, none completed yet"))
            continue
        streak = 0
        for r in done:
            if r.get("conclusion") in ("failure", "timed_out", "startup_failure"):
                streak += 1
            else:
                break
        if streak:
            out.append(Finding(FAIL, f"{name}: red for {streak} run(s) on {branch}, latest {done[0].get('created_at')}"))
        else:
            out.append(Finding(PASS, f"{name}: {done[0].get('conclusion')} at {done[0].get('created_at')}"))
    out += _scheduled_findings(ctx, by_wf, branch, len(runs))
    return out or [Finding(PASS, f"no completed workflow runs on {branch}")]


def scheduled_workflows(repo: Path) -> dict[str, tuple[str, float | None, str]]:
    """`name → (cron, period hours, workflow file)` for every workflow under .github/workflows with an `on.schedule`.
    PyYAML reads the bare key `on` as the boolean True (YAML 1.1), so both spellings are looked up. The file name is what
    the per-workflow runs endpoint takes, and that endpoint is the only reading a busy org does not drown (row 115)."""
    import yaml
    out: dict[str, tuple[str, float | None, str]] = {}
    d = repo / ".github" / "workflows"
    if not d.is_dir():
        return out
    for p in sorted(list(d.glob("*.yml")) + list(d.glob("*.yaml"))):
        try:
            doc = yaml.safe_load(p.read_text()) or {}
        except (OSError, yaml.YAMLError):
            continue
        if not isinstance(doc, dict):
            continue
        on = doc.get("on") if "on" in doc else doc.get(True)
        sched = (on or {}).get("schedule") if isinstance(on, dict) else None
        crons = [str(x.get("cron")) for x in sched or [] if isinstance(x, dict) and x.get("cron")]
        if crons:
            periods = [cron_period_hours(c) for c in crons]
            out[str(doc.get("name") or p.name)] = (crons[0], min((h for h in periods if h), default=None), p.name)
    return out


SCHEDULE_LATE_FLOOR_HOURS = 24.0   # GitHub creates scheduled runs hours late (Lucille 2026-09-19: hourly cron, median gap 3.02h, max 12.66h)


def _scheduled_findings(ctx: Ctx, by_wf: dict[str, list[dict[str, Any]]], branch: str, read: int) -> list[Finding]:
    """A scheduled workflow whose newest scheduled run is older than the larger of 3× its period and 24h has stopped —
    and a stopped schedule looks exactly like a quiet one (Lucille 2026-09-19, L5: `roadmap-sync` died at checkout for
    two hours under the same red badge as its drift assertion; the sweep the org built to watch PRs had no such reading
    of its own).

    Each schedule is read from its OWN runs (`workflows/<file>/runs?event=schedule`), never from the branch's newest 100,
    whose span is set by how busy the repository is rather than by the question being asked. Corrected after Reed's review
    of Lucille #1664: that window was 36.7 h there on 2026-09-21 and did hold a run of each hourly schedule, so both
    versions FAIL on the one stopped nightly and this changed the REASON, not that day's verdict — "the window reads a
    healthy nightly as stopped" is what it does once the span falls under the cadence, which is a property of a busier day
    and was not the state measured (row 115). The window is the fallback when the per-workflow endpoint cannot be read, and
    then a miss is UNREACHABLE rather than FAIL — a false alarm here teaches the org to ignore the reading that exists to
    be believed. The whole check needs `gh`, which standard Lucille containers do not carry, so most sessions there read
    UNREACHABLE and cannot take this reading at all."""
    slug = ctx.manifest["org"]["repo"]
    try:   # one call for every workflow's state: `active`, `disabled_manually`, `disabled_inactivity`, `disabled_fork`
        state = {str(w.get("path") or "").rsplit("/", 1)[-1]: str(w.get("state") or "")
                 for w in (_gh_json(f"repos/{slug}/actions/workflows?per_page=100") or {}).get("workflows", [])}
    except UnreachablePort:
        state = {}
    out: list[Finding] = []
    for name, (cron, period, file) in scheduled_workflows(ctx.repo).items():
        st = state.get(file, "")
        off = bool(st) and st != "active"
        own, source = True, f"its own scheduled runs (`{file}`)"
        try:
            fired = (_gh_json(f"repos/{slug}/actions/workflows/{file}/runs?event=schedule&per_page=1") or {}).get("workflow_runs", [])
        except UnreachablePort as e:
            own = False
            fired = [r for r in by_wf.get(name, []) if r.get("event") == "schedule"]
            source = f"the newest {read} run(s) on {branch}, its own run list being unreadable ({e})"
        newest = max((r.get("created_at") or "" for r in fired), default="")
        at = parse_ts(newest) if newest else None
        bar = max(3 * period, SCHEDULE_LATE_FLOOR_HOURS) if period else SCHEDULE_LATE_FLOOR_HOURS
        if at is None:
            out.append(Finding(FAIL if own else UNREACHABLE,
                               f"{name}: scheduled (`{cron}`) and no scheduled run in {source}"
                               + (f"; the workflow is `{st}`" if off else "")
                               + (" — the schedule has stopped, or was never enabled; a stopped schedule is silent" if own
                                  else " — that window is the wrong instrument for this question on a busy org; this is not a reading that it stopped")))
            continue
        age = round((ctx.now - at).total_seconds() / 3600, 1)
        if off:   # the state says why, and a disabled schedule never comes back on its own (Lucille 2026-09-21, row 115)
            out.append(Finding(FAIL, f"{name}: scheduled (`{cron}`) and the workflow is `{st}` — nothing fires it; last scheduled run {age}h ago per {source}. "
                               "A person disables one after it goes red and GitHub disables one itself after 60 days without repository activity "
                               "(`disabled_inactivity`); either way the schedule is silent, not quiet, and only a person turns it back on"))
        elif age > bar:
            out.append(Finding(FAIL, f"{name}: scheduled (`{cron}`, every {period:g}h) and last fired {age}h ago per {source} — over {bar:g}h, the larger of 3× the period and 24h, because GitHub itself creates scheduled runs hours late; nothing fired it since"))
        else:
            out.append(Finding(PASS, f"{name}: scheduled (`{cron}`), last fired {age}h ago per {source}"))
    return out


def _tempo_facts(ctx: Ctx) -> dict[str, Any]:
    """Tempo facts: passed in (`--facts` with a `tempo` key), else the committed files under .org/tempo, else NEEDS_FACTS —
    the doctor does not spend two minutes of gh calls on its own; Doc's skill runs `org tempo gather` first."""
    from . import tempo as tp
    if isinstance(ctx.facts.get("tempo"), dict):
        facts = ctx.facts["tempo"]
    elif ctx.facts.get("kind") == "tempo-facts":   # `--facts` given a gather's own file (Reed passed one and got the committed file, 2026-09-19)
        facts = ctx.facts
    else:
        facts = tp.latest_facts(ctx.repo)
    if not facts:
        raise NeedsFacts("tempo")
    if ctx.manifest:   # the targets follow the manifest as it is now (the CEO's clock, `tempo.targets`), not the gather-time copy
        facts = dict(facts, targets=tp.targets(ctx.manifest, ctx.now))
    return facts


def check_ceo_chair(ctx: Ctx) -> list[Finding]:
    """Check 14: open PRs with a SOUND verdict vs time since the last merge vs the CEO's record — the failure no producing role can show."""
    from . import tempo as tp
    facts = _tempo_facts(ctx)
    rep = tp.report(facts, ctx.now)
    c = rep["cycle"]
    tgt = rep["targets"].get("verdict_to_merge", 4)
    sound = [p for p in c["open"] if p.get("verdict") == "SOUND"]
    stale = [p for p in sound if (p["hours_since_verdict"] or 0) > tgt]
    ceo_key = ctx.report_key("ceo") if "ceo" in ctx.manifest["roles"] else "roles/ceo/last-run"
    rec = tp._latest_records(facts.get("board", [])).get(ceo_key)
    age = tp.hours(tp._record_at(rec), ctx.now.isoformat()) if rec else None
    no_v, unsound = c.get("merged_without_verdict") or [], c.get("merged_on_unsound") or []
    line = (f"QUEUE {len(sound)} SOUND PR(s) open, {len(stale)} past {tgt}h" + (" (" + ", ".join(f"#{p['number']} {p['hours_since_verdict']}h" for p in stale[:6]) + ")" if stale else "")
            + f"; last merge {c['hours_since_last_merge']}h ago; CEO record " + (f"{age}h old" if rec else "ABSENT — the chair has never written, or its record expired (Lucille, 2026-09-19: absent four days inside a PASS)")
            + f"; facts {facts.get('gathered_at')}")   # the reading is only as live as the file it came from (Reed on #208, 2026-09-19)
    out = [Finding(FAIL if (stale or rec is None) else PASS, line)]
    if no_v or unsound:   # row 96: the chair merging on green alone, or over an UNSOUND — the contract says never
        chair = _chair_merged(facts, ceo_key)
        by_chair = [p for p in no_v if p["number"] in chair]
        who = (f" — {len(by_chair)} of them named in the chair's own `merged:` records" if by_chair else "") + (
            f"; the other {len(no_v) - len(by_chair)} by the account (chair or operator: `merged_by` is one login for both, the chair's record decides; NumeroTech 2026-09-21, row 112)" if len(no_v) > len(by_chair) else "")
        out.append(Finding(FAIL, f"MERGED ON GREEN: {len(no_v)} of {c.get('merged')} merge(s) since {facts.get('since')} carried no reviewer verdict at merge"
                           + (" (" + ", ".join(f"#{p['number']} {p['kind']}" for p in no_v[-6:]) + ")" if no_v else "") + who
                           + (f"; {len(unsound)} merged over a last verdict of UNSOUND (" + ", ".join(f"#{p['number']}" for p in unsound[:6]) + ")" if unsound else "")
                           + " — the chair's contract is a verdict pinned to the head, never green alone"))
    return out


def _chair_merged(facts: dict[str, Any], ceo_key: str) -> set[int]:
    """Every PR the chair's own records say it merged: the board's latest record plus the committed run ledger — the only
    reading that tells the chair's merge from the operator's under one account."""
    from . import tempo as tp
    nums: set[int] = set()
    for r in facts.get("board", []):
        if r.get("key") == ceo_key:
            v = r.get("value") if isinstance(r.get("value"), dict) else {}
            for f in ("merged", "merged_prs", "merges"):
                nums.update(tp.pr_numbers(v.get(f)))
    for r in facts.get("runs", []):
        if r.get("role") == "ceo":
            for f in ("merged", "merged_prs", "merges"):
                nums.update(tp.pr_numbers(r.get(f)))
    return nums


def check_actuator(ctx: Ctx) -> list[Finding]:
    """Check 20: the actuator's heartbeat, lease, chain and cost (SPEC §13.3). An org that declared `tempo.actuator` and has
    no heartbeat has not performed the manual step; a heartbeat older than its own next_wake_at is a broken chain;
    context over the rotate threshold is an operator act (rebind the floor routine to a fresh session)."""
    from . import actuator as ac
    from . import tempo as tp
    facts = _tempo_facts(ctx)
    cfg = ac.org_tempo(ctx.manifest)
    board = facts.get("board", [])
    hb = ac.heartbeat(board, cfg)
    rows = ac.ledger_rows(board, cfg)
    out: list[Finding] = []
    if not hb:
        if rows:
            out.append(Finding(DEAD, f"actuator: heartbeat absent; last ledger row {rows[-1].get('at')} ({tp.hours(rows[-1].get('at'), ctx.now.isoformat())}h ago) — the chain died or the session ended"))
        else:
            out.append(Finding(FAIL, f"actuator ({cfg['actuator']}): no heartbeat and no ledger row ever — the four-call wake is not running; `org routine {cfg['actuator']}` prints the prompt its routine needs"))
        return out
    age_h = tp.hours(hb.get("at"), ctx.now.isoformat()) or 0
    nxt = hb.get("next_wake_at")
    late_min = ((tp.hours(nxt, ctx.now.isoformat()) or 0) * 60) if nxt else None
    if late_min is not None and late_min > float(cfg["hold_if_cron_due_within_minutes"]):
        newer = [r for r in rows if str(r.get("at")) > str(hb.get("at"))]
        if not newer:
            out.append(Finding(FAIL, f"CHAIN: expected wake {nxt}, {late_min:.0f} min late and no newer row — the send_later chain broke; the cron floor is the next wake"))
    if age_h > 25:
        out.append(Finding(DEAD, f"actuator: heartbeat {hb.get('at')} is {age_h:.1f}h old — past the hourly floor by a day"))
    toks = hb.get("context_tokens")
    if toks and int(toks) > int(cfg["rotate_at_tokens"]):
        out.append(Finding(FAIL, f"ROTATE actuator: {toks} tokens > {cfg['rotate_at_tokens']} — every wake now costs its whole context; the operator rebinds the floor routine to a fresh session (UI)"))
    for t in facts.get("triggers", []) or []:
        lr = t.get("last_run") or {}
        if t.get("persistent_session_id") and hb.get("session_id") and lr.get("session_id") and ac._sid(lr["session_id"]) != ac._sid(hb["session_id"]) and str(t.get("name", "")).startswith(str((ctx.manifest["roles"].get(cfg["actuator"]) or {}).get("name", ""))):
            out.append(Finding(FAIL, f"UNBOUND: floor routine {t.get('id')} last fired into {lr['session_id']} but the heartbeat is from {hb['session_id']}"))
    by_sid = {}
    for sess in facts.get("sessions") or []:
        by_sid[ac._sid(sess.get("id"))] = sess
    for l in tp.listeners(facts, ctx.now):
        sid = l.get("session_id")
        sess = by_sid.get(ac._sid(sid)) if sid else None
        toks = (sess or {}).get("context_tokens") or ((sess or {}).get("external_metadata") or {}).get("context_usage", {}).get("used_tokens")
        if toks and int(toks) > int(cfg["rotate_at_tokens"]):
            out.append(Finding(FAIL, f"ROTATE {l['role']}: session {sid} at {toks} tokens > {cfg['rotate_at_tokens']} — every wake now costs its whole context; start a fresh session and re-register"))
    series = ac.wake_cost_series(board, cfg)
    if series:
        last = series[-1]
        out.append(Finding(PASS, f"WAKE-COST: ${last['usd']} last wake ({last.get('context_tokens')} tokens), {len(rows)} rows, {sum(1 for r in rows if r.get('idle'))} idle"))
    orph = ac.orphans(facts, ctx.now, cfg)
    for f in orph["fired_no_receiver"]:
        out.append(Finding(FAIL, f"FIRED-NO-RECEIVER {f['role']}: {f['run_id']} {f['age_hours']}h ago, no record echoed it"))
    for r in orph["suppressed"]:
        out.append(Finding(FAIL, f"SUPPRESSED {r}: {orph['losses'].get(r)} wakes lost — the operator decides"))
    if not out or all(f.status == PASS for f in out):
        out.insert(0, Finding(PASS, f"actuator alive: heartbeat {hb.get('at')} ({age_h:.1f}h ago), next wake {nxt or 'cron floor'}, session {hb.get('session_id')}, {toks or '?'} tokens"))
    return out


def check_tempo(ctx: Ctx) -> list[Finding]:
    """Check 19: every edge of finding → dispatch → PR → verdict → merge → verified against its target, the handoffs nobody
    received, and the roles whose events are past target and should have been woken (SPEC §13)."""
    from . import tempo as tp
    facts = _tempo_facts(ctx)
    rep = tp.report(facts, ctx.now)
    out = [Finding(FAIL, s) for s in rep["slow"]]
    a = rep.get("actuator") or {}
    for w in rep["wake_now"]:
        if w["fire"]:
            tag = "UNWOKEN" if a.get("heartbeat") else "WAKE"
            out.append(Finding(FAIL, f"{tag} {w['role']}: {w['why']} — " + ", ".join(f"{e['what']} {e['waiting_hours']}h" for e in w["events"][:4])))
    for u in (a.get("orphans") or {}).get("unforwarded", []):
        if (u.get("age_hours") or 0) > rep["targets"].get("blocked_forwarded", 1):
            out.append(Finding(FAIL, f"UNFORWARDED blocked {u['role']}: {u['age_hours']}h — {u['text'][:100]}"))
    for p in rep["cycle"].get("needing_action") or []:
        # Lucille 2026-09-19 (row 112, L1): every PR check-in chain records SUCCEEDED whether or not a turn ran, and three
        # chains died with their sessions — 66 unwatched PR-hours. The PR's state is the same either way, so read that.
        over = (p["idle_hours"] or 0) > rep["targets"].get("pr_needing_action", 4)
        out.append(Finding(FAIL if over else PASS, f"NEEDING ACTION #{p['number']} ({'; '.join(p['why'])}): idle {p['idle_hours']}h"
                           + (f" — past {rep['targets'].get('pr_needing_action', 4)}h with nobody acting: a spawned builder is gone and nothing re-wakes it for a red, a conflict or a changes-requested review" if over else " (under target)")))
    listening = {l["role"]: l for l in rep.get("listeners") or []}
    for e in rep.get("handoffs_unreceived") or []:
        l = listening.get(e["to"])
        if l and l.get("roster_read") and not l.get("listening"):
            out.append(Finding(FAIL, f"NOT LISTENING {e['to']}: handoff {e['key']} waiting {e['waiting_hours']}h and the receiver has no listener parked — a DM would not reach it"))
    if not out:
        out.append(Finding(PASS, "every edge within target; nothing waiting past target"))
    measured = ", ".join(f"{k} {v['median_hours']}h/{v['n']}" for k, v in rep["edges"].items() if v["n"])
    out.append(Finding(PASS, f"medians: {measured or 'no completed edge yet'}; facts {facts.get('gathered_at')}" + (f" merged from {len(facts['merged_from'])} files" if facts.get("merged_from") else "")))
    return out


def check_suite_in_records(ctx: Ctx) -> list[Finding]:
    """Check 21 (SPEC §18): every role's latest record says which org-core wrote it. A record carrying no `suite` was written by a
    container that ran no setup report; one whose `suite.org_core` is behind the lock was written by a container whose hook did
    not install the tree's wheel (rows 87, 88: both restarted NumeroTech sessions sat on 0.8.0 for a day, visible only in the
    roles' own records)."""
    from .lock import read as read_lock

    lock = read_lock(ctx.repo) or {}
    want = lock.get("org_core")
    lock_at = parse_ts(lock.get("generated_at"))
    if not want:
        return [Finding(FAIL, "no .org/lock.yaml with an org_core version — this repo was never applied")]
    out: list[Finding] = []
    for role in enabled_roles(ctx.manifest):
        if (ctx.manifest["roles"].get(role) or {}).get("runtime") not in (None, "session", "fresh"):
            continue
        key = ctx.report_key(role)
        rec = ctx.record(key)
        if rec is None:
            continue   # absence is check 1's finding
        value = _record_value(rec) or {}
        hub_at = parse_ts(rec.get("updated_at"))
        suite = value.get("suite")
        predates = bool(lock_at and hub_at and hub_at < lock_at)
        if not isinstance(suite, dict) or "suite" not in value:
            out.append(Finding(PASS if predates else FAIL, f"{role}: record carries no `suite` field" + (f" and predates the lock ({lock_at.isoformat(timespec='minutes')}) — the next run says" if predates else " — written by a skill rendered before 0.16.0, or the field was dropped")))
            continue
        if not suite:
            # `{}`: the capture line itself failed — `org` not on PATH in that container, or a usage error (row 91: 19 rendered
            # lines put --repo after the subcommand and every record would have read this way forever). Never a rollout lag.
            out.append(Finding(FAIL, f"{role}: record carries `suite: {{}}` — the capture line failed in that container (`org` not on PATH, `org setup … status --compact` errored, or SUITE was set without `export`, or the capture and the write ran in two shells — a `VAR=… cmd \"$(python3 …)\"` prefix is not in the environment the `$(…)` runs in, and an export lives in one shell; NumeroTech 2026-09-21, row 112); the record says nothing about what it ran, and no restart changes that"))
            continue
        if suite.get("report") == "absent":
            out.append(Finding(PASS if predates else FAIL, f"{role}: record says the setup never ran in its container (`suite.report: absent`)" + (" and predates the lock — the next run says" if predates else " — the hook is not wired there, or the container started before the install")))
            continue
        got = suite.get("org_core")
        if got == want:
            others = ", ".join(f"{k} {v}" for k, v in suite.items() if k != "org_core" and v)
            out.append(Finding(PASS, f"{role}: org-core {got}" + (f"; {others}" if others else "")))
        elif lock_at and hub_at and hub_at < lock_at:
            out.append(Finding(PASS, f"{role}: org-core {got} in a record that predates the lock's {want} ({lock_at.isoformat(timespec='minutes')}) — the next run says"))
        else:
            out.append(Finding(FAIL, f"{role}: record written by org-core {got or 'none'} while the lock is {want} — its container's hook did not install the tree's wheel (rows 87, 88); a restart alone does not fix a branch whose hook is behind"))
    if not out:
        out.append(Finding(PASS, "no role record to read yet"))
    return out


# --- 7, 8: the work store — drift, and claims nobody released (SPEC §8 rows 7 and 8) ----------------------------

#: Mirrors roadmap-core 0.3.2 `graph.STALE_CLAIM_DAYS` / `VERIFYING_CLAIM_DAYS`: a `verifying` item keeps its claim on
#: purpose (the session that shipped holds it until the effect is read), so its bar is longer, never shorter.
CLAIM_DAYS_DEFAULT = 3.0
CLAIM_DAYS_BY_STATUS = {"verifying": 14.0}
_VALIDATE_RE = re.compile(r"(\d+) item\(s\), (\d+) arc\(s\)")
_DIVERGENCE_RE = re.compile(r"(\d+) divergence\(s\)")
_RED = ("failure", "timed_out", "startup_failure")


def _work_store(ctx: Ctx) -> dict[str, Any] | None:
    port = ctx.manifest["ports"].get("work_store") or {}
    return port if port.get("tool") == "roadmap-core" else None


def _items_dir(ctx: Ctx, port: dict[str, Any]) -> Path:
    return ctx.repo / str(port.get("files") or "roadmap/") / "items"


def _store_cli(ctx: Ctx, port: dict[str, Any], *args: str, timeout: int = 60) -> subprocess.CompletedProcess | None:
    """One roadmap-core invocation in the org's checkout, by the manifest's `cli` (`roadmap`, or Lucille's
    `python scripts/roadmap.py`). None when the tool itself cannot start. `ROADMAP_REPO_ROOT` is pinned to the checkout:
    roadmap-core walks up from cwd for `roadmap/items`, and a stray cwd would read another project's backlog as this one's."""
    cli = str(port.get("cli") or "roadmap").split()
    env = dict(os.environ, ROADMAP_REPO_ROOT=str(ctx.repo))
    try:
        return subprocess.run([*cli, *args], cwd=ctx.repo, capture_output=True, text=True, timeout=timeout, env=env)
    except FileNotFoundError:
        return None
    except subprocess.TimeoutExpired as e:
        raise UnreachablePort(f"work_store: `{' '.join(cli)} {' '.join(args)}` did not answer in {timeout}s") from e


def _first_lines(p: subprocess.CompletedProcess | None, n: int = 2) -> str:
    if p is None:
        return "the tool could not start"
    lines = [ln.strip() for ln in ((p.stderr or "") + "\n" + (p.stdout or "")).splitlines() if ln.strip()]
    return " / ".join(lines[:n])[:300] or f"exit {p.returncode}, no output"


def _days_ago(ctx: Ctx, at: str | None) -> float | None:
    t = parse_ts(at)
    return round((ctx.now - t).total_seconds() / 86400, 1) if t else None


def check_store_drift(ctx: Ctx) -> list[Finding]:
    """Check 7: the work store against the committed files.

    Files mode (the store IS the files): `validate --source files`, then `sync --source files --check` — a stale
    ROADMAP.md is the artifact every session reads offering work that is not there. Served mode: the artifact is
    rendered FROM the store, so `sync --check` against the files is not drift (Lucille 2026-09-20: `validate` ok,
    `sync --source files --check` "ARCS.md is stale", and only `diff` measures the store against the files). `diff`
    needs the credential; without it the org's own sync workflow is the gate that ran `diff`, and its red streak is
    the drift's age — 20 red runs of roadmap-sync went unanswered on 2026-09-15, and on 2026-09-19 the same red
    meant the job died at checkout, so a red streak names both readings and `diff` decides between them."""
    port = _work_store(ctx)
    if port is None:
        return [Finding(PASS, "work_store: not roadmap-core — nothing to probe")]
    cli = str(port.get("cli") or "roadmap")
    items = _items_dir(ctx, port)
    if not items.is_dir():
        return [Finding(FAIL, f"work_store: `{items.relative_to(ctx.repo)}` does not exist — no items for `{cli}` to read")]
    try:
        v = _store_cli(ctx, port, "validate", "--source", "files")
        if v is None:
            return [Finding(UNREACHABLE, f"work_store: `{cli}` cannot start in this container — is the suite's roadmap-core installed?")]
        if v.returncode != 0:
            return [Finding(FAIL, f"work_store: `{cli} validate --source files` failed: {_first_lines(v)}")]
        m = _VALIDATE_RE.search(v.stdout or "")
        counts = f"{m.group(1)} item(s), {m.group(2)} arc(s)" if m else "validate ok"
        if str(port.get("mode") or "files") == "files":
            s = _store_cli(ctx, port, "sync", "--source", "files", "--check")
            if s is None or s.returncode != 0:
                return [Finding(FAIL, f"DRIFT files mode: {counts}, generated view stale — {_first_lines(s)}; `{cli} sync --source files` and commit, or the file offers work that is not there")]
            return [Finding(PASS, f"files mode: {counts}; ROADMAP.md and ARCS.md current")]
        cred = str(port.get("credential") or "")
        if cred and os.environ.get(cred):
            d = _store_cli(ctx, port, "diff", timeout=120)
            if d is None:
                return [Finding(UNREACHABLE, f"work_store: `{cli}` cannot start in this container")]
            if d.returncode == 0:
                return [Finding(PASS, f"served mode: {counts}; `{cli} diff`: db and files agree")]
            n = _DIVERGENCE_RE.search(d.stderr or "")
            rows = [ln[len("drift: "):].strip() for ln in (d.stderr or "").splitlines() if ln.startswith("drift:")]
            if not rows and not n:
                return [Finding(UNREACHABLE, f"served mode: {counts}; `{cli} diff` failed without a divergence count: {_first_lines(d)}")]
            return [Finding(FAIL, f"DRIFT {n.group(1) if n else len(rows)} row(s) between the store and the files: " + "; ".join(rows[:3])
                            + (" …" if len(rows) > 3 else "") + f" — `{cli} pull` / `push` closes it, and the sync workflow should have")]
    except UnreachablePort as e:
        return [Finding(UNREACHABLE, str(e))]
    wf = str(port.get("sync_workflow") or "")
    if not wf:
        return [Finding(NEEDS_FACTS, f"served mode: {counts}; `{cli} diff` needs `{cred or 'the store credential'}` in this session, and no `sync_workflow` is declared to read instead")]
    slug, branch = ctx.manifest["org"]["repo"], ctx.manifest["org"]["default_branch"]
    try:
        runs = (_gh_json(f"repos/{slug}/actions/workflows/{wf}/runs?branch={branch}&per_page=30") or {}).get("workflow_runs", [])
    except UnreachablePort as e:
        return [Finding(UNREACHABLE, f"served mode: {counts}; no `{cred}` here and gh: {e} — the drift is unread")]
    done = [r for r in runs if r.get("status") == "completed"]
    if not done:
        return [Finding(NEEDS_FACTS, f"served mode: {counts}; `{wf}` has no completed run on {branch} — the gate has never answered; set `{cred}` for `{cli} diff`")]
    streak: list[dict[str, Any]] = []
    for r in done:   # newest first
        if r.get("conclusion") in _RED:
            streak.append(r)
        else:
            break
    if streak:
        first = streak[-1].get("created_at")
        return [Finding(FAIL, f"DRIFT per `{wf}`: red for {len(streak)} run(s) on {branch}, first red {first} ({_days_ago(ctx, first)}d ago) — "
                        f"the store and the files disagree, or the gate died before its body; `{cli} diff` with `{cred}` decides, and nobody answered the red")]
    latest = done[0].get("created_at")
    return [Finding(PASS, f"served mode: {counts}; `{wf}` green at {latest} ({_days_ago(ctx, latest)}d ago) — the org's own gate ran `diff`; no `{cred}` here to run it again")]


def _claims(items: Path) -> list[dict[str, Any]]:
    """`claim:` blocks from the committed items — the half of a claim another session can see (`claim: null` is none)."""
    import yaml
    out = []
    for p in sorted(items.glob("*.yaml")):
        try:
            doc = yaml.safe_load(p.read_text()) or {}
        except (OSError, yaml.YAMLError):
            continue
        claim = doc.get("claim") if isinstance(doc, dict) else None
        if isinstance(claim, dict) and claim.get("by"):
            out.append({"key": str(doc.get("id") or p.stem), "by": str(claim["by"]), "at": str(claim.get("at") or "") or None, "status": str(doc.get("status") or "")})
    return out


def _tempo_facts_or_none(ctx: Ctx) -> dict[str, Any] | None:
    try:
        return _tempo_facts(ctx)
    except Exception:  # noqa: BLE001 — absent or broken facts must not break a check that has gh
        return None


def _pr_on_branch(slug: str, branch: str, facts: dict[str, Any] | None, ask_gh: bool = True) -> tuple[dict[str, Any] | None, str, str | None]:
    """The PR on a holder's branch: (pr, where the answer came from, gh's refusal if any). A merged PR in the tempo
    facts is final (no call); anything else is asked of gh, because `pulls?head=<owner>:<branch>` is exact where the
    facts only cover their gather window; when gh is unreachable an open/closed row in the facts stands in, dated, and
    the refusal is returned so the caller stops asking."""
    hits = [p for p in (facts or {}).get("prs", []) if p.get("head_ref") == branch and (p.get("repo") in (None, slug))]
    merged = [p for p in hits if p.get("merged_at")]
    if merged:
        return max(merged, key=lambda p: p["merged_at"]), "facts", None
    if not ask_gh:   # gh already refused once this run: the facts are all there is
        return (max(hits, key=lambda p: p.get("updated_at") or "") if hits else None), f"facts gathered {(facts or {}).get('gathered_at')}", None
    try:
        owner = slug.split("/")[0]
        rows = _gh_json(f"repos/{slug}/pulls?state=all&head={owner}:{branch}&per_page=10") or []
    except UnreachablePort as e:
        if hits:
            return max(hits, key=lambda p: p.get("updated_at") or ""), f"facts gathered {(facts or {}).get('gathered_at')}", str(e)
        raise
    prs = [{"number": r.get("number"), "state": r.get("state"), "merged_at": r.get("merged_at"), "closed_at": r.get("closed_at")} for r in rows]
    merged = [p for p in prs if p.get("merged_at")]
    if merged:
        return max(merged, key=lambda p: p["merged_at"]), "gh", None
    opened = [p for p in prs if p.get("state") == "open"]
    if opened:
        return opened[0], "gh", None
    return (prs[0] if prs else None), "gh", None


def check_stale_claims(ctx: Ctx) -> list[Finding]:
    """Check 8: claims whose holder branch already merged a PR, closed it unmerged, or has held past roadmap-core's own
    bar (3d; `verifying` 14d) — reported, never released. Lucille's `roadmap_claim_audit.py` rule: inferring "finished"
    from a merge is exactly the guess worth not making, so the release is the holder's or the operator's act. A
    `verifying` item held by a merged branch under 14d is the documented shape (the shipper holds until the effect is
    read), not a finding. Reads the committed `claim:` blocks — the only half of a claim a checkout can see."""
    port = _work_store(ctx)
    if port is None:
        return [Finding(PASS, "work_store: not roadmap-core — no claims to read")]
    items = _items_dir(ctx, port)
    cli = str(port.get("cli") or "roadmap")
    return _shipped_findings(ctx, items, cli) + _claim_findings(ctx, items, cli)


def _default_ref(ctx: Ctx, git: Any) -> str:
    """`origin/<default_branch>` when the checkout has it — what the dispatcher offers from is what main says, not what
    this branch says — else HEAD, named in every line so the reader knows which."""
    branch = str((ctx.manifest.get("org") or {}).get("default_branch") or "main")
    for ref in (f"origin/{branch}", "HEAD"):
        try:
            git("rev-parse", "--verify", "-q", f"{ref}^{{commit}}")
            return ref
        except RuntimeError:
            continue
    raise RuntimeError("no commit to read at origin/%s or HEAD" % branch)


def _shipped_findings(ctx: Ctx, items: Path, cli: str) -> list[Finding]:
    """Row 111: `ready` items a merged commit already worked, read at the default branch (Lucille's
    `roadmap_status_audit.py`, ported to shipped.py). Measured 2026-09-21 on Lucille: 9 of the 14 items offered at
    `priority: now` had a merged commit touching the item and files outside roadmap/, four of which had each cost a
    builder run to rediscover. Reported, never moved: reading the commit and setting the status is the holder's or
    the operator's act."""
    from . import shipped as sh
    if not items.is_dir():
        return []
    rel = items.relative_to(ctx.repo)
    here = sh.ready_keys(items)
    try:
        git = sh.git_runner(ctx.repo)
        ref = _default_ref(ctx, git)
        keys = sh.ready_keys_at(git, ref, items_dir=f"{rel}/")
        if not keys:
            return [Finding(PASS, f"no `ready` item in {rel} at {ref} to audit for shipped work")]
        found, undetermined, examined = sh.audit(git, ref, keys)
    except (RuntimeError, OSError) as e:
        return [Finding(UNREACHABLE, f"shipped-but-ready unread: {str(e)[:160]} — {len(here)} `ready` item(s) in the working tree unexamined")]
    out: list[Finding] = []
    for s in found:
        c = s.attributing[-1]
        more = f" (+{len(s.attributing) - 1} earlier commit(s))" if len(s.attributing) > 1 else ""
        out.append(Finding(FAIL, f"SHIPPED? {s.key} reads {s.status or '?'} at {ref}: {c.sha[:7]} {c.date} \"{c.subject[:70]}\" changed {len(c.outside)} file(s) outside roadmap/{more}"
                           f" — the status never moved; read the commit, then `{cli} status {s.key} verifying|done` is the holder's or the operator's act"))
    if undetermined:
        out.append(Finding(UNREACHABLE, f"{len(undetermined)} of {examined} `ready` item(s) undetermined at {ref}: the history does not reach the commit that added them"
                           f" (a shallow checkout reads every file at its boundary as ADDED, so it can only reassure; `git fetch --unshallow origin`): " + ", ".join(undetermined[:8]) + (" …" if len(undetermined) > 8 else "")))
    if not found and examined > len(undetermined):
        out.append(Finding(PASS, f"{examined - len(undetermined)} `ready` item(s) at {ref}: none worked by a merged commit outside roadmap/"))
    return out


def _claim_findings(ctx: Ctx, items: Path, cli: str) -> list[Finding]:
    claims = _claims(items) if items.is_dir() else []
    rel = items.relative_to(ctx.repo)
    if not claims:
        return [Finding(PASS, f"no claims in {rel} (a committed `claim:` block is the half another session can see)")]
    slug = ctx.manifest["org"]["repo"]
    facts = _tempo_facts_or_none(ctx)
    out: list[Finding] = []
    unreachable: str | None = None
    unread = 0
    for c in claims:
        age = _days_ago(ctx, c["at"])
        limit = CLAIM_DAYS_BY_STATUS.get(c["status"], CLAIM_DAYS_DEFAULT)
        held = f"{c['key']} held by {c['by']}" + (f" for {age}d" if age is not None else " (no `at`)") + (f", {c['status']}" if c["status"] else "")
        if c["status"] == "done":
            out.append(Finding(PASS, f"{held} — done; the claim is moot until `{cli} prune`"))
            continue
        pr, via = None, ""
        try:
            pr, via, refused = _pr_on_branch(slug, c["by"], facts, ask_gh=unreachable is None)
            unreachable = unreachable or refused
        except UnreachablePort as e:
            unreachable = str(e)
        if pr is None and unreachable is not None:
            unread += 1
        if pr and pr.get("merged_at"):
            if c["status"] == "verifying" and age is not None and age < limit:
                out.append(Finding(PASS, f"{held}: #{pr['number']} merged {pr['merged_at']} — held through verifying, under {limit:g}d"))
            else:
                out.append(Finding(FAIL, f"STALE {held}: #{pr['number']} merged {pr['merged_at']}" + (f" (per {via})" if via != "gh" else "")
                                   + f" — reported, never released; `{cli} release {c['key']}` is the holder's or the operator's act"))
        elif pr and pr.get("state") == "closed":
            out.append(Finding(FAIL, f"ABANDONED {held}: #{pr['number']} closed unmerged {pr.get('closed_at')}" + (f" (per {via})" if via != "gh" else "") + " — the hold outlived its branch"))
        elif age is not None and age >= limit:
            out.append(Finding(FAIL, f"HELD {held} (over {limit:g}d): " + (f"#{pr['number']} open" if pr else ("PR state unread" if unreachable else "no PR on that branch"))
                               + " — a session that never released, or a build still running; the holder decides, `show` before `--force`"))
        else:
            out.append(Finding(PASS, f"{held}: " + (f"#{pr['number']} open" if pr else ("PR state unread" if unreachable else "no PR yet"))))
    if unreachable:
        out.append(Finding(UNREACHABLE, f"gh: {unreachable} — merged-PR state unread for {unread} claim(s); the age rule above still applied"))
    return out


# --- 11: budget — the money nobody read (SPEC §8 row 11; row 97) ------------------------------------------------

BLOCKED_ALARM_HOURS = 2.0   # a session waiting on a permission prompt this long has nobody present to answer it


def _num(v: Any) -> float | None:
    """A ceiling from the manifest: a number, or a numeric string; a placeholder like `<from the ledger>` is None."""
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _session_row(s: dict[str, Any]) -> dict[str, Any]:
    """Flatten one list_sessions / get_session row (wrapped in `ccr` or not)."""
    c = s.get("ccr", s) if isinstance(s, dict) else {}
    em = c.get("external_metadata") or {}
    sc = c.get("session_context") or {}
    urls = []
    for x in (sc.get("sources") or c.get("sources") or []):   # the raw row nests {git_repository: {url}}; a gather's projection may keep "owner/repo"
        u = str(((x or {}).get("git_repository") or {}).get("url") or "") if isinstance(x, dict) else str(x or "")
        if u and "://" not in u and u.count("/") == 1:
            u = "https://github.com/" + u
        if u:
            urls.append(u)
    cost = (em.get("usage") or {}).get("cost_usd", c.get("cost_usd", (c.get("usage") or {}).get("cost_usd")))
    tokens = (em.get("context_usage") or {}).get("used_tokens", c.get("context_tokens", c.get("used_tokens")))
    return {"id": c.get("id"), "title": str(c.get("title") or ""), "tags": [str(t) for t in (c.get("tags") or [])],
            "repos": [u.lower().rstrip("/") for u in urls if u], "model": sc.get("model") or c.get("configured_model") or c.get("model"),
            "status": str(c.get("session_status") or ""), "bucket": str(c.get("status_bucket") or ""),
            "created_at": c.get("created_at"), "updated_at": c.get("updated_at"),
            "cost": float(cost or 0.0), "cost_known": cost is not None,
            "tokens": int(tokens or 0), "tokens_known": tokens is not None,
            "needs": str(((em.get("post_turn_summary") or {}).get("needs_action")) or ((c.get("post_turn_summary") or {}).get("needs_action")) or "")}


def _role_of(row: dict[str, Any], manifest: dict[str, Any]) -> str:
    for t in row["tags"]:
        if t.startswith("role:") and t[5:] in manifest["roles"]:
            return t[5:]
        if t in manifest["roles"]:   # the bare vocabulary (`builder`) lived beside `role:builder` from 2026-09-20 (NumeroTech, row 112)
            return t
    head = row["title"].lower()
    for rid, entry in manifest["roles"].items():
        names = [rid.lower()] + [str((entry or {}).get("name") or "").lower()]
        if any(n and (head.startswith(n) or f" {n} " in f" {head} " or f"— {n}" in head or f"- {n}" in head) for n in names):
            return rid
    return "other"


def _this_org(row: dict[str, Any], manifest: dict[str, Any]) -> bool:
    org = manifest.get("org") or {}
    slug = str(org.get("repo") or "").lower()
    if slug and any(u.endswith(slug) or u.endswith(slug + ".git") for u in row["repos"]):
        return True
    return f"org:{org.get('id')}" in row["tags"]


def _sessions_now_and_before(ctx: Ctx) -> tuple[list[dict[str, Any]], str | None, list[dict[str, Any]] | None, str | None]:
    """(sessions, gathered_at, previous sessions ≥ 20 h older or None, their gathered_at). The API gives cumulative cost per
    session and no time series, so a window is the difference between two gathers; without a previous file the reading is
    cumulative and says so."""
    from . import tempo as tp
    now_rows, now_at = None, None
    if isinstance(ctx.facts.get("sessions"), list):
        now_rows, now_at = ctx.facts["sessions"], ctx.facts.get("gathered_at")
    files = []
    d = ctx.repo / tp.FACTS_DIR
    if d.is_dir():
        for p in sorted(d.glob("facts-*.json")):
            try:
                f = json.loads(p.read_text())
            except (OSError, json.JSONDecodeError):
                continue
            if isinstance(f.get("sessions"), list) and f["sessions"]:
                files.append(f)
    if now_rows is None and files:
        now_rows, now_at = files[-1]["sessions"], files[-1].get("gathered_at")
    if now_rows is None:
        raise NeedsFacts("sessions")
    prev, prev_at = None, None
    t_now = parse_ts(now_at) or ctx.now
    for f in reversed(files):
        t = parse_ts(f.get("gathered_at"))
        if t and (t_now - t).total_seconds() >= 20 * 3600:
            prev, prev_at = f["sessions"], f.get("gathered_at")
            break
    return now_rows, now_at, prev, prev_at


def check_budget(ctx: Ctx) -> list[Finding]:
    """Check 11: what the org's sessions cost, per role and in total, against `budget.daily_usd`; sessions over the rotate
    line; sessions stuck on a permission prompt nobody is present to answer. Row 97: US$4,053 across 19 sessions in a day,
    one of them US$1,823 in 24 h while blocked on a production SQL prompt, and no check read any of it."""
    from . import actuator as ac
    rows, at, prev_rows, prev_at = _sessions_now_and_before(ctx)
    prev = {r["id"]: r for r in (_session_row(s) for s in (prev_rows or []))}
    all_rows = [_session_row(s) for s in rows]
    mine = [r for r in all_rows if _this_org(r, ctx.manifest)]
    window_h = round(((parse_ts(at) or ctx.now) - parse_ts(prev_at)).total_seconds() / 3600, 1) if (prev_at and parse_ts(prev_at) and parse_ts(at)) else None
    def spent(r):   # cost in the window, or cumulative when there is no previous gather
        return max(0.0, r["cost"] - prev[r["id"]]["cost"]) if window_h and r["id"] in prev else r["cost"]
    by_role: dict[str, dict[str, Any]] = {}
    for r in mine:
        b = by_role.setdefault(_role_of(r, ctx.manifest), {"n": 0, "spent": 0.0, "cum": 0.0, "max_tokens": 0})
        b["n"] += 1; b["spent"] += spent(r); b["cum"] += r["cost"]; b["max_tokens"] = max(b["max_tokens"], r["tokens"])
    total = sum(b["spent"] for b in by_role.values())
    basis = f"in the {window_h}h since the previous gather ({prev_at})" if window_h else "cumulative per session (no earlier gather with sessions under .org/tempo — the first window starts at the next one)"
    budget = ctx.manifest.get("budget") or {}
    daily = _num(budget.get("daily_usd"))
    out: list[Finding] = []
    # read what is missing BEFORE the figure, so the figure can say so itself: a total that annotates its own
    # incompleteness one finding lower still reads as a verdict on the line a person actually quotes (Reed on #1664)
    unseen = {role: sid for role, sid in _bound_session_ids(ctx).items() if sid not in {r["id"] for r in all_rows}}
    floor = (f"; EXCLUDES {len(unseen)} bound session(s) the listing did not hold (" + ", ".join(sorted(unseen)) + ") — a floor, not the spend") if unseen else ""
    table = ", ".join(f"{role} {b['n']}× ${b['spent']:.0f}" for role, b in sorted(by_role.items(), key=lambda kv: -kv[1]["spent"]))
    if mine and not any(r["cost_known"] for r in mine):
        # NumeroTech #226 review (2026-09-20): the org's own list_sessions rows carried no usage.cost_usd and used_tokens 0,
        # so SPEND printed $0 and ROTATE could never fire — a $0 that is the shape, not the spend, is the vacuous pass
        out.append(Finding(NEEDS_FACTS, f"SPEND unread: none of the {len(mine)} session rows of this org carries a cost (usage.cost_usd, or cost_usd on a gather's projection)"
                           + ("; tokens unread too, so ROTATE cannot fire" if not any(r["tokens_known"] for r in mine) else "")
                           + " — save the raw list_sessions result as the facts' `sessions`; a $0 here would be the shape, not the spend"))
    elif daily is None:
        out.append(Finding(NEEDS_FACTS if unseen else PASS, f"SPEND {ctx.manifest['org']['id']}: ${total:.0f} {basis} — {table or 'no sessions of this org'}{floor}; no numeric ceiling: budget.daily_usd is {budget.get('daily_usd')!r} (a reading, not a bar)"))
    else:
        scale = (window_h / 24.0) if window_h else 1.0
        limit = daily * scale
        pct = (total / limit * 100) if limit else 0
        line = f"BUDGET {ctx.manifest['org']['id']}: ${total:.0f} {basis} vs ${limit:.0f} ({pct:.0f}% of daily_usd {daily:g}{' scaled to the window' if window_h else ''}) — {table or 'no sessions of this org'}{floor}"
        # under the ceiling on an incomplete population is not a pass: one unseen persistent session has been an order
        # of magnitude above the whole visible total (NumeroTech 2026-09-21), so the percentage cannot settle it
        out.append(Finding(FAIL if pct >= 100 else (NEEDS_FACTS if unseen else PASS),
                           line + ("" if pct < 80 else f"; at_80_percent={budget.get('at_80_percent', 'warn')}, at_100_percent={budget.get('at_100_percent', 'warn')}")))
    if unseen:   # row 115: the org's largest number read from a listing that cannot hold it
        out.append(Finding(NEEDS_FACTS, f"UNSEEN: {len(unseen)} bound session(s) are absent from the {len(all_rows)} row(s) read — "
                           + ", ".join(f"{role} {sid}" for role, sid in sorted(unseen.items()))
                           + ". A persistent session ages out of a newest-N listing precisely by being long-lived, and it is the org's largest "
                             "number while it does (NumeroTech 2026-09-21: the dispatcher's bound session at US$5,462 cumulative, +US$3,200 in 24h, "
                             "in no listing this account could take). Call the tool ending in `__get_session` on each id and append its row to the "
                             "facts' `sessions`; every figure above excludes them until you do"))
    rotate_at = int(ac.org_tempo(ctx.manifest)["rotate_at_tokens"])
    ended_on_a_question: list[tuple[float, dict[str, Any]]] = []
    for r in mine:
        if r["status"].endswith("ARCHIVED"):
            continue
        age = round((ctx.now - (parse_ts(r["updated_at"]) or ctx.now)).total_seconds() / 3600, 1)
        if r["tokens"] > rotate_at and age <= 24:   # a session nobody has touched for a day is not paying for its context
            out.append(Finding(FAIL, f"ROTATE {r['title'][:60]}: {r['tokens']} tokens > {rotate_at} (cumulative ${r['cost']:.0f}) — every wake now costs its whole context; rebind to a fresh session"))
        if r["status"].endswith("REQUIRES_ACTION"):   # alive and holding a permission prompt: the Marshal shape (row 97)
            if age >= BLOCKED_ALARM_HOURS:
                out.append(Finding(FAIL, f"BLOCKED {r['title'][:60]}: waiting {age}h on `{r['needs'] or 'a permission prompt'}` (cumulative ${r['cost']:.0f}) — nobody unattended can answer it; a person stops it or answers it"))
        elif r["bucket"].endswith("BLOCKED"):   # a finished session whose last turn was a question — a handoff with no receiver, but not a live cost
            ended_on_a_question.append((age, r))
    recent = sorted((x for x in ended_on_a_question if x[0] <= 48), key=lambda x: x[0])
    if recent:
        out.append(Finding(FAIL, f"ENDED ON A QUESTION: {len(recent)} session(s) in the last 48h finished asking something nobody answered — "
                           + "; ".join(f"{r['title'][:40]} ({a}h: `{r['needs'][:70]}`)" for a, r in recent[:5]) + (" …" if len(recent) > 5 else "")
                           + (f"; {len(ended_on_a_question) - len(recent)} older" if len(ended_on_a_question) > len(recent) else "")))
    elif ended_on_a_question:
        out.append(Finding(PASS, f"{len(ended_on_a_question)} finished session(s) ended on an unanswered question, all older than 48h"))
    others = [r for r in all_rows if r not in mine]
    if others:
        out.append(Finding(PASS, f"account-wide: {len(all_rows)} sessions listed, ${sum(r['cost'] for r in all_rows):.0f} cumulative; {len(others)} of them (${sum(r['cost'] for r in others):.0f}) belong to other orgs or no repository"))
    return out

# --- 15: the operator queue — what waits on a person, and for how long (SPEC §8 row 15, §13.3) --------------------

OPERATOR_QUEUE_ALARM_DAYS = 3.0
WAITING_HEADING_RE = re.compile(r"^##+ +waiting on the operator\b", re.I | re.M)
ISO_DATE_RE = re.compile(r"\b(20\d\d-\d\d-\d\d)(?:[T ](\d\d:\d\d))?")


def _bullets_under(text: str, heading_re: re.Pattern) -> list[str]:
    """The `- ` bullets under a heading, each with its indented continuation lines, up to the next heading."""
    m = heading_re.search(text)
    if not m:
        return []
    body = text[m.end():]
    nxt = re.search(r"^#{1,3} ", body, re.M)
    body = body[: nxt.start()] if nxt else body
    out: list[str] = []
    for line in body.split("\n"):
        if line.startswith("- "):
            out.append(line[2:].strip())
        elif out and line.startswith("  ") and line.strip():
            out[-1] += " " + line.strip()
    return out


SENTENCE_END_RE = re.compile(r"(?<=[.!?])\s")
#: a headline shorter than this is not one. Some bullets open with a bare reference — the first sentence of
#: `**`#1462`** — Reed returned UNSOUND…` is the pull request number and nothing else, which on the page read
#: as a row saying `#1462.` and told the reader nothing (Lucille, 2026-09-22).
HEAD_FLOOR = 35


def _bullet_head(b: str, n: int = 150) -> str:
    """The bullet's own first sentence, extended past a bare reference and cut on a word.

    Flattening the markup and taking the first 90 characters stopped mid-word: the live file produced rows
    reading `Marshal held.` and `Escalated by Marshal (di.`, which is broken text, not a summary."""
    t = " ".join(b.split()).replace("**", "").strip()
    head = t
    for m in SENTENCE_END_RE.finditer(t):
        if m.start() >= HEAD_FLOOR:
            head = t[:m.start() + 1]
            break
    return head if len(head) <= n else head[:n].rsplit(" ", 1)[0].rstrip(" ,;:—-") + "…"


def _bullet_body(b: str, n: int = 260) -> str:
    """What the bullet says after its headline. The headline alone is a label, not a thing a person can act
    on — `#1471 is held by the CEO, not by review.` says nothing about what to do or why it is stuck. The
    body is where the author put that, and dropping it left the page a list of titles (Lucille, 2026-09-22)."""
    t = " ".join(b.split()).replace("**", "").strip()
    head = _bullet_head(b)
    cut = head.endswith("…")                    # the headline stopped mid-sentence; the body continues it
    rest = t[len(head.rstrip("…")):].lstrip(" —-–:;,." if not cut else "").strip()
    if not rest:
        return ""
    body = rest if len(rest) <= n else rest[:n].rsplit(" ", 1)[0].rstrip(" ,;:—-") + "…"
    return ("…" + body) if cut else body


def _grafted(repo: Path) -> set[str]:
    """The commits where a truncated history stops — `.git/shallow`, which is empty for a full clone.

    A `git log -S` answer that IS one of these is "at or before the point this clone stops seeing", not a date:
    from the boundary commit's side every line of the file looks newly added. The shallow FLAG cannot decide
    this (git still calls a deepened clone shallow, and such a clone may genuinely hold the commit), and
    neither can a date — commits seconds apart, or in the same second, compare equal. The identity can."""
    try:
        path = subprocess.run(["git", "rev-parse", "--git-path", "shallow"], cwd=repo, capture_output=True,
                              text=True, timeout=10).stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return set()
    f = (repo / path) if path and not Path(path).is_absolute() else Path(path or "")
    try:
        return {ln.strip() for ln in f.read_text().splitlines() if ln.strip()}
    except OSError:
        return set()


def _introduced_at(repo: Path, rel: str, needle: str) -> dt.datetime | None:
    """When a bullet first appeared in the file: the oldest commit whose diff adds the text (`git log -S`).

    `git log -S` answers from the history it HAS, so in a `--depth 1` clone the oldest commit adding the text
    is the only commit — today's — and an undated bullet that has sat in the file for a week is dated a minute
    ago. Measured 2026-09-22 on a depth-1 clone of Lucille: 13 of 25 operator-queue items read `1 minute` on
    the page. Row 115's shape — a reading taken through a window that structurally excludes its subject,
    answering confidently — so an answer that IS the boundary of a truncated history is refused, not reported."""
    from . import gitfiles as gf
    if not needle or not gf.is_git_repo(repo):
        return None
    try:
        p = subprocess.run(["git", "log", "--reverse", "--format=%H %cI", "-S", needle, "--", rel], cwd=repo, capture_output=True, text=True, timeout=30)
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    first = (p.stdout or "").strip().splitlines()
    if not first:
        return None
    sha, _, when = first[0].partition(" ")
    return None if sha in _grafted(repo) else parse_ts(when)


def check_operator_queue(ctx: Ctx) -> list[Finding]:
    """Check 15: everything that waits on a person, oldest first — the operator file's "Waiting on the operator" bullets
    (dated by the ISO date they carry, else by the commit that introduced them), the actuator's `coord/tempo/operator-queue`
    rows, and the asks in the chair's own `blocked` field. Surfaced here, decided by nobody here: a red line means a
    person has been the blocker for longer than the roles' own clocks (NumeroTech 2026-09-20: one migration question
    carried by five roles' records and the file for a day)."""
    from . import actuator as ac
    from . import tempo as tp
    rel = ctx.manifest["ports"]["operator_surface"]
    p = ctx.repo / rel
    items: list[dict[str, Any]] = []
    # the operator's roadmap arc, when the manifest names one (0.31.4, row 131) — the same reader `org status` uses,
    # so the doctor and the page cannot disagree about what waits on the operator
    arc = tp._operator_arc(ctx.repo, ctx.manifest)
    if arc is not None:
        if not arc["carried"]:
            items.append({"head": f"no item in {arc['dir']} carries the `{arc['arc']}` arc the manifest names — the queue has no surface a person reads", "since": None, "source": "arc", "missing": True})
        for it in arc["items"]:
            items.append({"head": _bullet_head(it["head"]), "since": parse_ts(it["since"]) if it.get("since") else None, "source": "arc"})
        for name in arc["unparsed"]:
            items.append({"head": f"{arc['dir']}/{name} did not parse — whether it carries the `{arc['arc']}` arc is unknown", "since": None, "source": "arc", "unread": True})
    if p.exists():
        text = p.read_text()
        if not WAITING_HEADING_RE.search(text):
            items.append({"head": f"{rel} has no `Waiting on the operator` section — the queue has no surface a person reads", "since": None, "source": "file", "missing": True})
        for b in _bullets_under(text, WAITING_HEADING_RE):
            m = ISO_DATE_RE.search(b)
            raw = b[:48].rsplit(" ", 1)[0] if len(b) > 48 else b   # verbatim text, cut on a word: `git log -S` needs what the file says, markup included
            since = parse_ts(m.group(1) + ("T" + m.group(2) if m.group(2) else "T00:00") + "Z") if m else _introduced_at(ctx.repo, rel, raw)
            items.append({"head": _bullet_head(b), "since": since, "source": "file"})
    elif arc is None:
        # with an operator arc declared, the arc is the surface and a missing operator file is not a missing queue
        items.append({"head": f"{rel} does not exist", "since": None, "source": "file", "missing": True})
    cfg = ac.org_tempo(ctx.manifest)
    try:
        q = _record_value(ctx.record(cfg["operator_queue_key"])) or {}
        for row in (q.get("items") or q.get("queue") or []):
            if isinstance(row, dict):
                items.append({"head": _bullet_head(f"{row.get('role') or '?'}: {row.get('ask') or row.get('what') or ''}"), "since": parse_ts(row.get("event_at") or row.get("forwarded_at")), "source": "queue"})
        ceo_key = ctx.report_key("ceo") if "ceo" in ctx.manifest["roles"] else "roles/ceo/last-run"
        ceo = _record_value(ctx.record(ceo_key)) or {}
        blocked = str(ceo.get("blocked") or "")
        if blocked and blocked.lower() not in ("no", "none", "null"):
            parts = [x.strip() for x in re.split(r"\(\d+\)", blocked) if x.strip()] or [blocked]
            at = parse_ts(ceo.get("at"))
            for part in parts:
                items.append({"head": _bullet_head("chair: " + part), "since": at, "source": "chair"})
    except UnreachablePort as e:
        items.append({"head": f"board unread: {e}", "since": None, "source": "board", "unread": True})
    def age(it):
        return round((ctx.now - it["since"]).total_seconds() / 86400, 1) if it.get("since") else None
    real = [it for it in items if not it.get("missing") and not it.get("unread")]
    real.sort(key=lambda it: -(age(it) or 0))
    out: list[Finding] = []
    for it in items:
        if it.get("missing"):
            out.append(Finding(FAIL, it["head"]))
        if it.get("unread"):
            out.append(Finding(UNREACHABLE, it["head"]))
    old = [it for it in real if (age(it) or 0) >= OPERATOR_QUEUE_ALARM_DAYS]
    n_file = sum(1 for it in real if it["source"] == "file")
    n_arc = sum(1 for it in real if it["source"] == "arc")
    n_q = sum(1 for it in real if it["source"] == "queue")
    n_ch = sum(1 for it in real if it["source"] == "chair")
    if not real:
        out.append(Finding(PASS, "nothing waits on the operator: "
                           + (f"no `ready` item in the `{arc['arc']}` arc, " if arc is not None else "")
                           + "no bullets under the file's section, no queue rows, the chair's blocked field empty"))
        return out
    oldest = real[0]
    head = (f"OPERATOR QUEUE: {len(real)} item(s) — "
            + (f"{n_arc} in the `{arc['arc']}` arc, " if arc is not None else "")
            + f"{n_file} in {rel}, {n_q} in {cfg['operator_queue_key']}, {n_ch} in the chair's blocked field; oldest "
            + (f"{age(oldest)}d" if age(oldest) is not None else "of unknown age") + f": {oldest['head'][:80]}")
    out.append(Finding(FAIL if old else PASS, head))
    for it in old[:6]:
        out.append(Finding(FAIL, f"WAITING ON A PERSON {age(it)}d ({it['source']}): {it['head']} — re-measure its premise from the source before carrying it forward (NumeroTech 2026-09-20: two migrations flagged on four consecutive runs were already applied)"))
    undated = [it for it in real if age(it) is None]
    if undated:
        out.append(Finding(PASS, f"{len(undated)} item(s) carry no date and were introduced by no commit this checkout can see — age unknown"))
    return out

CHECKS: list[Check] = [
    Check(1, "records-fresh", "every enabled clock role's record is younger than cadence × tolerance", "DEAD <role> last=<at> expected=<by> — the same line for 'never ran' and 'ran and could not report'", check_records_fresh),
    Check(2, "blocked-surfaced", "every record has a `blocked` field and it is read", "BLOCKED <role>: <text> — or a record with no such field", check_blocked_surfaced),
    Check(3, "triggers-match-manifest", "each enabled clock role has an enabled trigger: cadence, runtime, sources, last_run", "TRIGGER <role>: missing / cadence mismatch / sources: [] / last_run FAILED", check_triggers, needs_facts=("triggers",)),
    Check(4, "session-roles-alive", "each session-runtime role's bound session exists, is not archived, and is listening (registered in coord/tempo/agents and on the roster)", "SESSION <role> archived / trigger fires into a dead conversation / <role> registered but NOT on the roster — its listener lapsed / <role>: bound session not among the rows read — fetch it with get_session before reading it as dead", check_sessions_alive, needs_facts=("triggers", "sessions")),
    Check(5, "on-org-account", "this session can see the manifest's triggers", "sees 0 of N declared triggers — wrong account", check_on_org_account, needs_facts=("triggers",)),
    Check(6, "ports-reachable", "each port answers from this runtime", "UNREACHABLE <port>: <why>", check_ports),
    Check(7, "store-files-drift", "work store vs files: files mode validates and the generated view is current; served mode `diff` with the credential, else the org's sync workflow's red streak", "DRIFT 18 row(s) between the store and the files / DRIFT per roadmap-sync.yml: red for 20 run(s), first red 3.1d ago / DRIFT files mode: ROADMAP.md stale", check_store_drift),
    Check(8, "stale-claims", "`ready` items a merged commit already worked (status never moved), and claims whose holder branch merged a PR, closed it unmerged, or held past roadmap-core's bar (3d; verifying 14d) — reported, never released or moved", "SHIPPED? <item> reads ready at origin/main: <sha> <date> \"<subject>\" changed 3 file(s) outside roadmap/ / STALE <item> held by <branch>: #n merged <date> / HELD <item> by <branch> for 5.2d (over 3d): no PR on that branch", check_stale_claims),
    Check(9, "board-keys-expiring", "role keys expiring within 24h that no run refreshed", "<key> expires in 3h and nothing refreshed it", check_board_expiring),
    Check(10, "guards-can-fail", "every guard's mutation self-test goes red", "GUARD <name> cannot fail", None, phase="P2"),
    Check(11, "budget", "session cost per role and total between gathers vs budget.daily_usd; sessions over the rotate line; sessions stuck on a permission prompt", "BUDGET numerotech: $1,823 in the 24.0h since the previous gather vs $500 (365%) / ROTATE Link — ceo: 538161 tokens > 250000 / BLOCKED Marshal — dispatcher: waiting 5.3h on `Approve or deny mcp__Supabase__execute_sql` / UNSEEN: 2 bound session(s) absent from the rows read — the persistent ones, which are the largest", check_budget, needs_facts=("sessions",)),
    Check(12, "knob-overrides", "active runtime knob overrides, and any outside their range", "<knob>=<v> OUTSIDE its declared range", check_knobs),
    Check(13, "own-ci-green", "the org's own workflows on the default branch: red streaks, queues nobody serves, and schedules that stopped firing", "<workflow> red for N runs — an alarm nobody answered / <workflow>: 2 run(s) queued, oldest 5.3h — no runner serves this repository / <workflow>: scheduled (`40 * * * *`) and last fired 31.0h ago per its own scheduled runs", check_own_ci),
    Check(14, "ceo-chair", "open SOUND PRs vs time since last merge vs the CEO's record age", "QUEUE 4 SOUND PRs, 3 past 4h; last merge 6h ago; CEO record 26h old", check_ceo_chair, needs_facts=("tempo",)),
    Check(15, "operator-queue", "what waits on a person, oldest first: the operator file's `Waiting on the operator` bullets (dated by their text or the commit that introduced them), the actuator's queue rows, the chair's blocked asks", "OPERATOR QUEUE: 5 item(s) … oldest 3.2d: Apply supabase/migrations/… / WAITING ON A PERSON 3.2d (file): …", check_operator_queue),
    Check(16, "operator-file-stamped", "every clock role's section in the operator file is stamped within cadence", "<role>: stamped 3 days ago / no section", check_operator_file),
    Check(17, "doctor-self-record", "the doctor's own previous record exists", "no previous doctor record — first run, or the last one died", check_self),
    Check(18, "checks-registry", "checks port: last run, ledger consistency, failing checks without an owner, vacuous passes, expiries", "<check> red 45 days, no owning item / 7 vacuous passes unflagged / registry not run for 3 days", check_checks_registry),
    Check(19, "tempo", "every edge of the chain against its target, handoffs nobody received, roles whose events are past target, open PRs red/conflicted/changes-requested with nobody acting (SPEC §13)", "SLOW verdict_to_merge: median 9h (target 4h) / WAITING handoff verifier → registrar 37h / UNWOKEN reviewer: 10 events past 0.5h / UNFORWARDED blocked verifier 3h / NEEDING ACTION #1533 (ci red: backend-tests): idle 44.1h", check_tempo, needs_facts=("tempo",)),
    Check(20, "actuator", "the actuator's heartbeat, chain, context and cost; fires nobody answered (SPEC §13.3)", "DEAD actuator: heartbeat absent / CHAIN: expected wake 09:40, 35 min late / ROTATE actuator: 429904 tokens > 250000 / FIRED-NO-RECEIVER reviewer", check_actuator, needs_facts=("tempo",)),
    Check(21, "suite-in-records", "every role's latest record names the org-core (and suite) its container ran, and it is the lock's (SPEC §18)", "<role>: record written by org-core 0.8.0 while the lock is 0.16.0 / <role>: record carries no `suite`", check_suite_in_records),
]


@dataclass
class Result:
    check: Check
    findings: list[Finding]

    @property
    def status(self) -> str:
        order = [DEAD, FAIL, UNREACHABLE, NEEDS_FACTS, NOT_IMPLEMENTED, BLOCKED, PASS]
        present = {f.status for f in self.findings}
        for s in order:
            if s in present:
                return s
        return PASS


def run(ctx: Ctx, only: set[int] | None = None) -> list[Result]:
    results: list[Result] = []
    for c in CHECKS:
        if only and c.n not in only:
            continue
        if c.impl is None:
            results.append(Result(c, [Finding(NOT_IMPLEMENTED, f"not implemented in org-core 0.1 — {c.phase}")]))
            continue
        try:
            findings = c.impl(ctx)
        except NeedsFacts as e:
            findings = [Finding(NEEDS_FACTS, f"needs `{e}` facts from a session holding the sessions port (pass --facts)")]
        except UnreachablePort as e:
            findings = [Finding(UNREACHABLE, str(e))]
        except Exception as e:  # noqa: BLE001 — a check that raises is a check that could not read, never a run that prints nothing (row 94)
            findings = [Finding(UNREACHABLE, f"check crashed: {type(e).__name__}: {str(e)[:200]} — one bad value in one record; the other checks still ran (Doc·lucille 2026-09-20 09:20Z: a traceback and zero checks)")]
        results.append(Result(c, findings))
    return results


def summarize(results: list[Result]) -> dict[str, Any]:
    ran = [r for r in results if r.status not in (NOT_IMPLEMENTED, NEEDS_FACTS, UNREACHABLE)]
    return {
        "checks_total": len(results),
        "ran": len(ran),
        "not_implemented": sum(1 for r in results if r.status == NOT_IMPLEMENTED),
        "needs_facts": sum(1 for r in results if r.status == NEEDS_FACTS),
        "unreachable": sum(1 for r in results if r.status == UNREACHABLE),
        "bad": sum(1 for r in results if r.status in BAD),
        "blocked": sum(1 for r in results if r.status == BLOCKED),
        "dead_roles": [f.text.split(":")[0] for r in results if r.check.n == 1 for f in r.findings if f.status == DEAD],
    }


def exit_code(results: list[Result]) -> int:
    s = summarize(results)
    if s["bad"]:
        return 1
    if s["unreachable"]:
        return 2
    return 0


def render_text(results: list[Result]) -> str:
    lines = []
    for r in results:
        lines.append(f"[{r.status:<15}] {r.check.n:>2} {r.check.id} — {r.check.title}")
        for f in r.findings:
            lines.append(f"      {f.status:<15} {f.text}")
        if r.status in BAD or r.status == NOT_IMPLEMENTED:
            lines.append(f"      broken looks like: {r.check.broken_looks_like}")
    s = summarize(results)
    lines.append("")
    lines.append(
        f"ran {s['ran']} of {s['checks_total']} checks; {s['not_implemented']} not implemented; "
        f"{s['needs_facts']} need facts; {s['unreachable']} unreachable; {s['bad']} bad; {s['blocked']} blocked"
    )
    if s["dead_roles"]:
        lines.append("DEAD: " + ", ".join(s["dead_roles"]))
    return "\n".join(lines)


def to_json(results: list[Result], ctx: Ctx) -> dict[str, Any]:
    return {
        "at": ctx.now.isoformat(timespec="seconds"),
        "org": ctx.manifest["org"]["id"],
        "summary": summarize(results),
        "drill": sorted(ctx.drill_absent) or None,
        "checks": [
            {"n": r.check.n, "id": r.check.id, "status": r.status, "findings": [{"status": f.status, "text": f.text} for f in r.findings]}
            for r in results
        ],
    }
