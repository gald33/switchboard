"""`org status` — what is stopped right now, read at call time (SPEC §13; Appendix A rows 61, 62, 65, 81).

**Live is one clock read over the sources as they stand. It is not fresh history.** Three of the four
sources keep history and one does not:

| tier | what it holds | history? |
|---|---|---|
| `git` | `.org/runs/<role>.jsonl`, committed | yes |
| `github` | pull requests, their comments, their merges | yes — GitHub keeps it |
| `board` | `roles/*`, `coord/*` | **no** — one record per key, overwritten every wake (row 62) |
| `sessions` | triggers, sessions | not reachable from a terminal at all |

So a `github` edge prints a median with its `n`, and a `board` edge prints the worst thing waiting now
and says why it has no median to print. A number with no history behind it must never appear in the same
grammar as one that has it: that is what let a 0.87 h median read as health on the morning eight
verdicted pull requests stood, the oldest at 36.8 h (row 61). `org status --store` widens the board tier
by replaying snapshots the store kept; the tier line then says so.

**One fact, one line, with the date it started.** Findings that share a cause collapse into one line naming
the cause, its members and the oldest member's own timestamp; `GROUP_AT` is 2, because collapsing a pair only
hides which pair. No fact is printed in two tiles — the chain keeps the edge, the tile that owns the detail
keeps the detail. Lucille's reading on 2026-09-22 was 116 lines carrying 95 facts, 49 of them in two tiles at
once and 46 of 50 handoffs naming one receiver with one cause; a reader stops reading long before 116 (row 118).

Pure — `status(facts, now)` is a function of the facts and the clock and reaches nothing. The gathering is
`tempo.gather` (live) or `store.facts_since` (replayed); both hand it the same shape. Only the replayed one
carries `first_seen`, which is how a role with no record reads "it ran before and stopped" rather than row 65's
own unresolved sentence.
"""

from __future__ import annotations

import datetime as dt
from typing import Any

from . import tempo as tp

#: what a tier can and cannot answer — printed on every tile, because it is the tile's epistemic weight
GIT, GITHUB, BOARD, SESSIONS = "git", "github", "board", "sessions"
TIERS = {
    GIT: "committed — history survives",
    GITHUB: "GitHub's own history — medians are real",
    BOARD: "present only — one record per key, overwritten each wake (row 62)",
    SESSIONS: "needs a session holding the sessions port — unreachable from a terminal",
}

#: which source each edge's two timestamps come from (`tempo.item_flow`). A board-ended edge has a median
#: only as far as the records still on the board reach, which after one wake is nothing.
EDGE_TIER = {"finding_to_dispatch": BOARD, "dispatch_to_pr": BOARD, "merge_to_verified": BOARD,
             "open_to_verdict": GITHUB, "verdict_to_merge": GITHUB, "unsound_open": GITHUB}
EDGE_OWNER = {"finding_to_dispatch": "dispatcher", "dispatch_to_pr": "builder", "open_to_verdict": "reviewer",
              "verdict_to_merge": "ceo", "merge_to_verified": "verifier", "unsound_open": "builder"}
#: edges whose median is unbuildable in the tool as it ships — named, never printed as a blank that reads as fast
NO_MEDIAN = {"unsound_open": "n is 0 by construction (tempo.py:711) — the SLOW half is unreachable; WAITING is real"}

RED, CLEAR, DARK = "RED", "CLEAR", "DARK"
#: how a finding opens, in headline priority order — one list, so the headline and the page agree on what
#: counts as a finding, and the question the command asks ("what is stopped RIGHT NOW") decides which wins.
#: A thing stuck now outranks a median: `SLOW` is last because a slow median is a trend, not a blockage.
#: A live session holding a permission prompt is both stopped and still being paid for, so it sits above every
#: edge; a person who has been the blocker for days outranks an edge past target, because no role can move it.
#: A kind that starts with another (`BLOCKED ON A PROMPT`, `WAITING ON A PERSON`) must come first, or the
#: shorter one claims its lines — the match is `line.startswith(kind)`.
FINDING = ("DEAD", "UNREACHABLE", "BLOCKED ON A PROMPT", "WAITING ON A PERSON", "WAITING", "NOT RECEIVED",
           "NEEDING ACTION", "BLOCKED", "QUEUE", "NO OPERATOR SURFACE", "CEO record ABSENT", "SKEWED",
           "UNFORWARDED", "FIRED-NO-RECEIVER", "SUPPRESSED", "NOT LISTENING", "NEVER REGISTERED",
           "BEHIND", "NO SUITE", "ROTATE", "ABSENT", "SLOW")
DEFAULT_TOLERANCE = 1.5


def tier_unread(unread: list[str]) -> dict[str, str]:
    """Which tier could not be read, and why — decided once. The terminal reading and the page's edge table
    both ask here, because they disagreed: on a 403 the terminal said `not judged — prs: … (HTTP 403)` while
    the table printed `— | 0 | 0`, which reads as "nothing is waiting for a verdict" on an org with 33 review
    handoffs open. Row 65's lie, in the file whose docstring exists to prevent it (Lucille, 2026-09-22)."""
    return {BOARD: next((c for c in unread if c.startswith("board:")), ""),
            "agents": next((c for c in unread if c.startswith("agents:")), ""),
            GIT: next((c for c in unread if c.startswith("runs:")), ""),
            GITHUB: next((c for c in unread if c.startswith("prs:")), "")}


def _tile(tid: str, title: str, tier: str, state: str, lines: list[str], broken: str) -> dict[str, Any]:
    """A tile is its lines plus the sentence that says what broken looks like. A tile with no reachable
    red state is a defect (CLAUDE.md rule 2), so `broken` is required and never empty."""
    assert broken, f"tile {tid} has no broken-state line"
    return {"id": tid, "title": title, "tier": tier, "state": state, "lines": lines, "broken_looks_like": broken}


def _period(meta: dict[str, Any], now: dt.datetime) -> float | None:
    if meta.get("period_hours"):
        return float(meta["period_hours"])
    return tp.cron_period_hours(str(meta.get("cadence") or ""), now)


def roles_overdue(facts: dict[str, Any], rep: dict[str, Any], now: dt.datetime) -> list[dict[str, Any]]:
    """Every enabled role against its own clock. A role with no cadence is aged by nothing, so its absence is
    a presence finding and not a DEAD line — row 81, where the CEO's missing record printed inside a PASS."""
    by_role = {b["role"]: b for b in rep.get("blocked") or []}
    out = []
    for role, meta in sorted((facts.get("roles") or {}).items()):
        b = by_role.get(role) or {}
        period = _period(meta, now)
        tol = float(meta.get("tolerance") or DEFAULT_TOLERANCE)
        age = b.get("record_age_hours")
        row = {"role": role, "cadence": meta.get("cadence"), "period_hours": period, "tolerance": tol,
               "record_at": b.get("record_at"), "age_hours": age, "state": "ok", "why": ""}
        key = meta.get("report_key") or f"roles/{role}/last-run"
        row["key"] = key
        if b.get("record_at") is None:
            row["state"] = "dead" if period else "absent"
            cad = str(meta.get("cadence") or "none")
            # row 65's own sentence — "never ran, or ran and could not report" — is the ambiguity the store exists
            # to settle: a key the store has never held has never reported, not once.
            hist = facts.get("first_seen")
            h = hist.get(key) if isinstance(hist, dict) else None
            row["history"] = ("" if not isinstance(hist, dict) else
                              (f"the store holds {h['records']} record(s) for this key, {h['first_record_at']} to "
                               f"{h['last_record_at']} — it ran before and stopped" if h else
                               "the store has never held a record for this key — it has never reported, not once"))
            row["why"] = (f"no record at {key} — {row['history'] or 'never ran, or ran and could not report'}"
                          if period else
                          f"no record, and cadence `{cad}` is not a clock — nothing ages it, so this is presence only (row 81)")
        elif period is not None and age is not None and age > period * tol:
            row["state"] = "dead"
            row["why"] = f"last record {b['record_at']} is {age}h old; expected within {round(period * tol, 2)}h ({meta.get('cadence')} x {tol})"
        out.append(row)
    return out


def ask_key(text: Any) -> str:
    """The identity of one ask, for deciding that two records carry the same one. A normalized prefix, because
    every reader cuts the text at its own length and the full strings then differ where the ask does not."""
    return " ".join(str(text or "").split())[:120]


#: a group this size or larger prints as one line naming its cause; below it, each member prints its own
#: line, because two facts are not a pattern and collapsing them only hides which two.
GROUP_AT = 2


def role_lines(bad: list[dict[str, Any]]) -> list[str]:
    """The overdue roles, with the ones that share a cause on one line. A role whose record is merely stale keeps
    its own line: its date IS the finding. Roles that never wrote at all share one, because they share one cause
    and one fix, and ten identical lines are how a reader stops reading (2026-09-22: 95 of 116 lines were one fact)."""
    stale = [r for r in bad if r.get("record_at")]
    never = [r for r in bad if not r.get("record_at") and r["state"] == "dead"]
    ageless = [r for r in bad if not r.get("record_at") and r["state"] == "absent"]
    out = [f"{r['state'].upper()} {r['role']}: {r['why']}" for r in stale]
    for group, kind, what in ((never, "DEAD", "no record at all"), (ageless, "ABSENT", "no record, and no cadence to age it by")):
        if len(group) < GROUP_AT:
            out += [f"{r['state'].upper()} {r['role']}: {r['why']}" for r in group]
            continue
        hist = sorted({r.get("history") or "" for r in group})
        out.append(f"{kind} {len(group)} roles ({', '.join(r['role'] for r in group)}): {what}"
                   + (f" — {hist[0]}" if len(hist) == 1 and hist[0] else
                      ("; " + "; ".join(f"{r['role']}: {r['history']}" for r in group if r.get("history")) if any(r.get("history") for r in group)
                       else " — never ran, or ran and could not report")))
    return out


def handoff_group_rows(unreceived: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """(groups, unjudged) as data. One group per (receiver, cause), oldest first — the shape both the terminal
    line and the plain sentence are written from, so neither has to parse the other."""
    unjudged = [e for e in unreceived if e.get("unjudged_why")]
    groups: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for e in unreceived:
        if e.get("unjudged_why"):
            continue
        groups.setdefault((e["to"], e.get("unreachable_why") or ""), []).append(e)
    rows = []
    for (to, why), es in sorted(groups.items(), key=lambda kv: -max(x.get("waiting_hours") or 0 for x in kv[1])):
        es.sort(key=lambda x: -(x.get("waiting_hours") or 0))
        rows.append({"to": to, "why": why, "n": len(es), "senders": sorted({x["from"] for x in es}),
                     "oldest": es[0], "newest": es[-1], "items": es})
    return rows, unjudged


def handoff_groups(unreceived: list[dict[str, Any]]) -> tuple[list[str], list[str]]:
    """(findings, not-judged lines). Unreceived handoffs grouped by receiver and cause, oldest group first. On
    Lucille 2026-09-20, 46 of 50 open handoffs named one receiver: fifty lines, one cause, one fix. Each group
    carries the date the oldest was written, because "waiting 31h" alone never says whether this is today's
    problem or last week's.

    A handoff that names a pull request is judged by what the receiver did on it (row 105), so when the PR half
    was unread it is not judged here at all — it is counted, and the count says why."""
    rows, unjudged = handoff_group_rows(unreceived)
    note = []
    if unjudged:
        why = unjudged[0]["unjudged_why"].split(" — ", 1)[-1]
        note = [f"not judged — {len(unjudged)} of {len(unreceived)} name a pull request, and receipt is what the "
                f"receiver did on it (row 105): {why}"]
    out = []
    for g in rows:
        to, why, es = g["to"], g["why"], g["items"]
        kind = "UNREACHABLE" if why else "NOT RECEIVED"
        if g["n"] < GROUP_AT:
            e = es[0]
            out.append(f"{kind} {e['from']} -> {to} [{e['item']}] written {e['written_at']} — "
                       f"waiting {e['waiting_hours']}h" + (f"; {why}" if why else ""))
            continue
        out.append(f"{kind} {g['n']} handoff(s) to {to} from {', '.join(g['senders'])} — "
                   f"oldest [{es[0]['item']}] written {es[0]['written_at']}, waiting {es[0]['waiting_hours']}h; "
                   f"newest waiting {es[-1]['waiting_hours']}h"
                   + (f"; {why}" if why else " — the receiver is reachable and has not acted"))
    return out, note


def collapse_handoffs(slow: list[str], rep: dict[str, Any]) -> list[str]:
    """`slow_edges` writes one line per unreceived handoff, and the handoffs tile writes the same facts again:
    on Lucille 2026-09-22 that was 49 of the reading's lines printed twice. The chain keeps the edge — a count,
    the worst, the target — and the handoffs tile keeps the detail. `OVERTAKEN` is already one aggregate line."""
    out, per_handoff = [], []
    for line in slow:
        (per_handoff if ("handoff_received" in line and not line.startswith("OVERTAKEN")) else out).append(line)
    if not per_handoff:
        return out
    hu = [e for e in (rep.get("handoffs_unreceived") or []) if not e.get("unjudged_why")]
    if not hu:
        return out
    t = (rep.get("targets") or {}).get("handoff_received")
    worst = max(hu, key=lambda e: e.get("waiting_hours") or 0, default=None)
    unreach = sum(1 for e in hu if e.get("unreachable_why"))
    out.append(f"WAITING handoff_received: {len(hu)} not received"
               + (f" ({unreach} of them unreachable)" if unreach else "")
               + (f", worst {worst['from']} -> {worst['to']} [{worst['item']}] {worst['waiting_hours']}h "
                  f"written {worst['written_at']}" if worst else "")
               + (f" (target {t}h)" if t is not None else "")
               + " — grouped by receiver in the handoffs tile, not repeated here")
    return out


def status(facts: dict[str, Any], now: dt.datetime | None = None, *, tiers: dict[str, str] | None = None) -> dict[str, Any]:
    """The live reading, as tiles. One clock read; every tile carries its tier and its broken-state line."""
    now = now or dt.datetime.now(dt.timezone.utc)
    rep = tp.report(facts, now)
    tier_notes = dict(TIERS)
    if facts.get("sessions"):
        tier_notes[SESSIONS] = ("read from the facts — a dump taken by a session holding the sessions port, "
                                "as old as the gather that carried it")
    tier_notes.update(tiers or {})
    unread = list(rep.get("could_not_read") or [])
    board_unread = any(c.startswith("board:") for c in unread)
    prs_unread = any(c.startswith("prs:") for c in unread)
    facts_age = tp.hours(facts.get("gathered_at"), now.isoformat()) if facts.get("gathered_at") else None

    tiles: list[dict[str, Any]] = []
    # the roster is a separate read from the board: a store replay has the board and not the roster, so
    # folding them into one reason darkened every board tile over a missing `switchboard agents` call.
    un = tier_unread(unread)
    board_why, agents_why, prs_why, runs_why = un[BOARD], un["agents"], un[GITHUB], un[GIT]

    def state_of(red: bool, unread: bool) -> str:
        """RED outranks DARK, always. A finding the reading DID make must never be downgraded because some
        other source was unreachable — that is how a real queue hides behind partial coverage. The doctor
        orders its statuses the same way (doctor.py: DEAD/FAIL above UNREACHABLE/NEEDS_FACTS)."""
        return RED if red else (DARK if unread else CLEAR)

    def unjudged(why: str, limit: int = 96) -> str:
        """A source that could not be read produces no findings — only the sentence saying so. An absent record
        means 'nobody looked' here, and printing it as DEAD is row 65's lie in a new costume.

        The cut is for an exception's repr, which a tile cannot hold. A reason this file composed is already the
        length it needs to be and passes `limit=0`, because a truncated explanation is how a dark tile stops
        explaining itself."""
        return "not judged — " + (why[:limit] + "…" if limit and len(why) > limit else why)

    # --- the chain ---------------------------------------------------------
    lines, skew = [], []
    for name, e in rep["edges"].items():
        tier = EDGE_TIER.get(name, BOARD)
        why = board_why if tier == BOARD else prs_why
        t = rep["targets"].get(name)
        head = f"{name:<20} [{tier:<7}] owner {EDGE_OWNER.get(name, '?'):<11} "
        if why:
            lines.append(head + unjudged(why))
            continue
        if e.get("median_hours") is not None and e["median_hours"] < 0:
            # a duration cannot be negative: the two ends are out of order (a record overwritten by a later
            # wake, or two clocks). It is a finding about the reading, never a number to print beside real ones.
            skew.append(f"SKEWED {name}: median {e['median_hours']}h — a duration cannot be negative; "
                        f"the two ends are out of order over n {e['n']}")
            lines.append(head + f"median — (negative over n {e['n']}: timestamps out of order)")
            continue
        med = (f"median {e['median_hours']}h over n {e['n']}" if e["median_hours"] is not None
               else (f"no median — {NO_MEDIAN[name]}" if name in NO_MEDIAN
                     else f"no median over n {e['n']}" + (" — the board kept no earlier record (row 62)" if tier == BOARD else "")))
        worst = f"  worst {e['worst_waiting_item']} {e['worst_waiting_hours']}h" if e["worst_waiting_item"] else ""
        lines.append(head + f"{med}; waiting {e['waiting']}{worst}" + (f"  (target {t}h)" if t is not None else ""))
    slow = list(rep.get("slow") or []) if not (board_why and prs_why) else []
    red = collapse_handoffs(slow, rep) + skew
    tiles.append(_tile("chain", "the chain — finding to verified", "mixed",
                       state_of(bool(red), bool(board_why or prs_why)), lines + red,
                       "SLOW <edge>: median <h> over n <n> (target <h>) / WAITING <edge>: <item> for <h>h (target <h>)"))

    # --- the chair ---------------------------------------------------------
    c = rep["cycle"]
    ve = rep["edges"].get("verdict_to_merge") or {}
    ceo = next((b for b in rep.get("blocked") or [] if b["role"] == "ceo"), None)
    if prs_why:
        chair, chair_red = [unjudged(prs_why)], False
    else:
        chair = [f"open SOUND pull requests {ve.get('waiting', 0)}"
                 + (f", worst {ve['worst_waiting_item']} {ve['worst_waiting_hours']}h" if ve.get("worst_waiting_item") else ""),
                 (f"last merge {c['last_merge_at']} — {c['hours_since_last_merge']}h ago" if c.get("last_merge_at")
                  else f"no merge in the window since {facts.get('since')}")]
        ceo_absent = ceo is not None and ceo.get("record_at") is None and not board_why
        chair.append(unjudged(board_why) + " (CEO record)" if board_why else
                     ("CEO record ABSENT — the chair has never written, or its record expired" if ceo_absent else
                      (f"CEO record {ceo['record_at']} ({ceo.get('record_age_hours')}h old)" if ceo else "no ceo role declared")))
        # a PR red, conflicted or changes-requested is not waiting on a verdict — it is waiting on an act, and
        # the verdict clock above says nothing about it. Lucille 2026-09-19: 66 unwatched PR-hours, all of them here.
        na = c.get("needing_action") or []
        na_t = rep["targets"].get("pr_needing_action")
        stale = sorted((x for x in na if na_t is not None and (x.get("idle_hours") or 0) > na_t),
                       key=lambda x: -(x.get("idle_hours") or 0))
        chair.append(f"{len(na)} open pull request(s) need an act (ci red, conflicted or changes requested)"
                     + (f", {len(stale)} idle past {na_t}h" if na_t is not None else "")
                     if na else "no open pull request is red, conflicted or changes-requested")
        chair += [f"NEEDING ACTION #{x['number']} ({'; '.join(x['why'])}) idle {x['idle_hours']}h "
                  f"since {str(x.get('updated_at'))[:16]}"
                  + (f" — target {na_t}h, and nothing re-wakes a spawned builder for it" if na_t is not None else "")
                  for x in stale[:6]]
        tgt = rep["targets"].get("verdict_to_merge")
        chair_red = bool(ceo_absent or stale or (ve.get("worst_waiting_hours") is not None and tgt is not None and ve["worst_waiting_hours"] > tgt))
    tiles.append(_tile("chair", "the chair — is anything merging", GITHUB,
                       state_of(bool(chair_red), bool(prs_why or board_why)), chair,
                       "QUEUE <n> SOUND PR(s) open, <m> past <h>h (#<n> <h>h); last merge <h>h ago; CEO record ABSENT; "
                       "NEEDING ACTION #<n> (ci red: <check>) idle <h>h"))

    # --- what waits on a person --------------------------------------------
    # The org cannot move this queue at all: every other tile names a role that could act. Both halves are read —
    # the board's `coord/tempo/operator-queue` rows and the chair's own blocked field, plus the bullets under the
    # operator file's heading, which the gather carries because they are the surface a person actually opens.
    from . import actuator as ac
    from .doctor import OPERATOR_QUEUE_ALARM_DAYS
    acfg = ac.org_tempo({"tempo": facts.get("tempo_cfg") or {}})
    ow = facts.get("operator_waiting")
    queue: list[dict[str, Any]] = []
    if not board_why:
        for row in ac.operator_queue(facts.get("board") or [], acfg):
            queue.append({"source": acfg["operator_queue_key"], "since": row.get("event_at") or row.get("forwarded_at"),
                          "head": f"{row.get('role') or '?'}: {row.get('ask') or row.get('what') or ''}"[:90]})
        chb = next((b for b in rep.get("blocked") or [] if b["role"] == "ceo" and b.get("blocked")), None)
        if chb:
            queue.append({"source": "the chair's blocked field", "since": chb.get("record_at"),
                          "head": "chair: " + str(chb["blocked"])[:80]})
    if isinstance(ow, dict):
        queue += [{"source": it.get("source") or ow["file"], "since": it.get("since"), "head": it["head"],
                   "body": it.get("body", "")} for it in ow.get("items") or []]
    for q in queue:
        h = tp.hours(q["since"], now.isoformat()) if q.get("since") else None
        q["age_days"] = round(h / 24, 1) if h is not None else None
    queue.sort(key=lambda q: -(q["age_days"] or 0))
    stuck = [q for q in queue if (q["age_days"] or 0) >= OPERATOR_QUEUE_ALARM_DAYS]
    ppl = [f"WAITING ON A PERSON {q['age_days']}d ({q['source']}): {q['head']} — since {str(q['since'])[:16]}"
           for q in stuck[:6]]
    if isinstance(ow, dict) and not ow["has_section"]:
        ppl.append(f"NO OPERATOR SURFACE: no item in {ow['arc_dir']} carries the `{ow['arc']}` arc the manifest names"
                   + (f", and {ow['file']} has no `Waiting on the operator` section" if ow.get("file_read") else "")
                   + " — the queue has no surface a person reads" if ow.get("arc") else
                   f"NO OPERATOR SURFACE: {ow['file']} has no `Waiting on the operator` section — "
                   "the queue has no surface a person reads")
    if isinstance(ow, dict) and ow.get("arc_unparsed"):
        ppl.append(unjudged(f"{len(ow['arc_unparsed'])} item file(s) in {ow['arc_dir']} did not parse, so whether they "
                            f"carry the `{ow['arc']}` arc is unknown: {', '.join(ow['arc_unparsed'][:3])}", limit=0))
    half = [n for n, got in (("the board's queue and the chair's blocked field", not board_why),
                             ((ow or {}).get("label") or "the operator file", isinstance(ow, dict))) if got]
    if queue:
        oldest = f", oldest {queue[0]['age_days']}d ({queue[0]['source']})" if queue[0]["age_days"] is not None else ""
        ppl.append(f"{len(queue)} item(s) wait on a person{oldest}")
    elif len(half) == 2:
        ppl.append("nothing waits on a person: no queue row, no bullet, the chair's blocked field empty")
    elif half:
        # "nothing waits on a person" over one unread half is row 65 in its most reassuring costume
        ppl.append(f"nothing waits on a person in {half[0]} — the other half was not read, not read as empty")
    undated = [q for q in queue if q["age_days"] is None]
    if undated:
        ppl.append(f"{len(undated)} of them carry no date and no commit this checkout can see introduced them — age unknown")
    if board_why:
        ppl.append(unjudged(board_why) + f" ({acfg['operator_queue_key']} and the chair's blocked field)")
    if ow is None:
        ppl.append(unjudged("the operator file was not read — no `operator_surface` port, no such file, "
                            "or these facts were gathered before 0.26.0", limit=0))
    tiles.append(_tile("people", "what waits on a person", "mixed",
                       state_of(bool(stuck or (isinstance(ow, dict) and not ow["has_section"])), bool(board_why or ow is None)),
                       ppl,
                       "WAITING ON A PERSON <d>d (<source>): <ask> / NO OPERATOR SURFACE: <file> has no "
                       "`Waiting on the operator` section"))

    # --- roles against their own clocks ------------------------------------
    overdue = [] if board_why else roles_overdue(facts, rep, now)
    bad = [r for r in overdue if r["state"] != "ok"]
    tiles.append(_tile("roles", "roles against their own clocks", BOARD, DARK if board_why else (RED if bad else CLEAR),
                       [unjudged(board_why)] if board_why else
                       (role_lines(bad)
                        or [f"{len(overdue)} enabled role(s), every record within cadence x tolerance"]),
                       "DEAD <role>: last record <at> is <h>h old; expected within <h>h / ABSENT <role>: no record, and no cadence to age it by"))

    # --- blocked, and blocked nobody forwarded -----------------------------
    blocked = [b for b in rep.get("blocked") or [] if b.get("blocked")]
    unforwarded = (rep.get("actuator") or {}).get("orphans", {}).get("unforwarded") or []
    # NumeroTech 2026-09-20: one migration question carried by five roles' records read as five findings.
    # The identity is a normalized prefix, not the string: the record and the unforwarded row carry the same ask
    # cut at different lengths by different readers, and comparing the strings made them two asks again
    # (Lucille 2026-09-22, where only the one short enough to survive both cuts was recognised).
    same: dict[str, dict[str, Any]] = {}
    for b in blocked:
        g = same.setdefault(ask_key(b["blocked"]), {"text": "", "roles": []})
        g["roles"].append(b["role"])
        if len(str(b["blocked"])) > len(g["text"]):
            g["text"] = str(b["blocked"])
    bl = [f"BLOCKED {g['roles'][0]}: {g['text']}" if len(g["roles"]) == 1 else
          f"BLOCKED {len(g['roles'])} roles ({', '.join(g['roles'])}) carry one ask: {g['text']}"
          for g in sorted(same.values(), key=lambda g: -len(g["roles"]))]
    unf: dict[str, list[dict[str, Any]]] = {}
    for u in unforwarded:
        if isinstance(u, dict):
            unf.setdefault(ask_key(u.get("text")), []).append(u)
        else:
            bl.append(f"UNFORWARDED {u}")
    unf_rows: list[dict[str, Any]] = []
    for text, us in sorted(unf.items(), key=lambda kv: -len(kv[1])):
        ages = sorted(float(u.get("age_hours") or 0) for u in us)
        unf_rows.append({"roles": [str(u.get("role")) for u in us], "hours": ages, "text": text,
                         "same_as_blocked": text in same})
        # the text is already on a BLOCKED line when the same ask is what nobody forwarded — say which, do not reprint it
        bl.append(f"UNFORWARDED {', '.join(str(u.get('role')) for u in us)} blocked "
                  + (f"{ages[0]}h" if len(ages) == 1 else f"{ages[0]}–{ages[-1]}h")
                  + " — " + ("the same ask as the BLOCKED line above" if text in same else text)
                  + "; it never reached the operator queue")
    tiles.append(_tile("blocked", "blocked now, and what never reached the queue", BOARD,
                       DARK if board_why else (RED if bl else CLEAR),
                       [unjudged(board_why)] if board_why else (bl or ["no role's record carries a blocker"]),
                       "BLOCKED <role>: <text> / UNFORWARDED blocked <role> <h>h"))

    # --- handoffs written and never received -------------------------------
    hu = rep.get("handoffs_unreceived") or []
    hand_red, hand_note = handoff_groups(hu)
    tiles.append(_tile("handoffs", "handoffs written and never received", BOARD,
                       DARK if board_why else state_of(bool(hand_red), bool(hand_note)),
                       [unjudged(board_why)] if board_why else
                       (hand_red + hand_note
                        or [f"{len(rep.get('handoffs') or [])} handoff key(s) on the board, all acked"]),
                       "NOT RECEIVED <n> handoff(s) to <role>, oldest [<item>] written <at> — waiting <h>h / "
                       "UNREACHABLE <n> to <role>: it wakes on <events> and is not listening"))

    # --- the actuator, and fires nobody answered ---------------------------
    a = rep.get("actuator") or {}
    hb = a.get("heartbeat")
    orph = a.get("orphans") or {}
    fnr, sup = orph.get("fired_no_receiver") or [], orph.get("suppressed") or []
    # What the manifest asks of an actuator (0.31.4; absent from facts gathered before it, which read as before).
    # An org that enables neither the actuator nor a role routed through it has nothing for one to do, and needs no
    # board to know it (org-core 2026-09-23: "DEAD actuator" was the headline of a one-role org); an org that routes
    # roles to an actuator it never enabled has nothing that will ever start them.
    duty = facts.get("actuator_duty") or None
    idle = bool(duty) and not duty.get("enabled") and not duty.get("routed")
    orphaned = bool(duty) and not duty.get("enabled") and bool(duty.get("routed"))
    if idle:
        act, act_state = [f"no actuator here, and none needed: `{duty['role']}` is not enabled and no enabled role is "
                          "started through it — every role wakes on its own clock or its own listener"], CLEAR
    elif orphaned:
        who = ", ".join(duty["routed"])
        act, act_state = [f"NO ACTUATOR: {who} {'is' if len(duty['routed']) == 1 else 'are'} started only through "
                          f"`{duty['role']}`, which is not enabled — nothing will spawn or fire "
                          f"{'it' if len(duty['routed']) == 1 else 'them'}"], RED
    elif board_why:
        act, act_state = [unjudged(board_why)], DARK
    else:
        if hb:
            act = [f"heartbeat {hb.get('at')} ({a.get('heartbeat_age_hours')}h ago), next wake {hb.get('next_wake_at')}, "
                   f"{hb.get('context_tokens')} tokens, session {hb.get('session_id')}",
                   f"wakes {a.get('wakes')} ({a.get('wakes_idle')} idle), spawns {a.get('spawns')}, fires {a.get('fires')}, refused {a.get('refused')}"]
        else:
            act = ["DEAD actuator: no heartbeat at coord/tempo/actuator"
                   + (f"; {a.get('wakes')} ledger row(s) exist — the chain died or the session ended" if a.get("wakes")
                      else " and no ledger row ever — the four-call wake is not running")]
        # a fire is echoed by the receiver's board record or by its committed run file; with the git tier
        # unread the second half reads as silence, and silence is what this finding is made of (row 122)
        if runs_why and (fnr or sup):
            act.append(unjudged(f"{len(fnr)} fire(s) and {len(sup)} suppression(s) are not judged — "
                                f"a receiver echoes a fire in its record OR its run file, and {runs_why}", limit=0))
        else:
            act += [f"FIRED-NO-RECEIVER {f}" for f in fnr] + [f"SUPPRESSED {s}" for s in sup]
        act_state = state_of(bool(not hb or ((fnr or sup) and not runs_why)), bool(runs_why and (fnr or sup)))
    # a tile's tier is its evidence's (rows 121, 122): "none needed" and "none enabled" are read off the committed manifest
    tiles.append(_tile("actuator", "the wake chain that moves everything else", GIT if (idle or orphaned) else BOARD, act_state, act,
                       "DEAD actuator: no heartbeat / NO ACTUATOR: <roles> are started only through <role>, which is not "
                       "enabled / FIRED-NO-RECEIVER <role> <run_id> <h>h / SUPPRESSED <role>"))

    # --- listeners ---------------------------------------------------------
    ls = rep.get("listeners") or []
    roster_dark = board_why or any(not l.get("roster_read") for l in ls)
    lapsed = [l for l in ls if not l["listening"] and l.get("roster_read") and l.get("agent_id")]
    never = [l for l in ls if not l.get("agent_id")]
    tiles.append(_tile("listeners", "persistent roles: registered, and on the roster now", BOARD,
                       DARK if roster_dark else (RED if (lapsed or never) else CLEAR),
                       [unjudged(board_why or agents_why or "the roster was not read — `switchboard agents` returned nothing")] if roster_dark else
                       ([f"NOT LISTENING {l['role']}: registered {l['registered_age_hours']}h ago, not on the roster — its listener lapsed" for l in lapsed]
                        # one `org tempo register` missing from three sessions is one cause and one fix; a lapsed
                        # listener keeps its own line, because the age it lapsed at is the finding
                        + ([f"NEVER REGISTERED {len(never)} persistent roles ({', '.join(l['role'] for l in never)}): "
                            "no `org tempo register` from their sessions yet"] if len(never) >= GROUP_AT else
                           [f"NEVER REGISTERED {l['role']}: no `org tempo register` from its session yet" for l in never])
                        or [f"{len(ls)} persistent role(s), all on the roster"]),
                       "NOT LISTENING <role> — its listener lapsed / NEVER REGISTERED <role>"))

    # --- what the org is spending, and what is stopped holding a prompt ----
    # The only tier a terminal cannot reach, so this tile is dark far more often than it is clear — and it must be:
    # a $0 printed from rows that carry no cost is the shape, not the spend (NumeroTech #226, 2026-09-20).
    sessions = facts.get("sessions") or []
    rot = int(acfg["rotate_at_tokens"])
    if not sessions:
        spend, spend_state = [unjudged("the sessions tier was not read — pass a `list_sessions` dump to "
                                       "`org status --extra <file>`; a $0 here would be the shape, not the spend", limit=0)], DARK
        spend_rows: dict[str, Any] = {"read": False}
    else:
        from .doctor import BLOCKED_ALARM_HOURS, _role_of, _session_row, _this_org   # one way to read a session row
        mani = {"roles": facts.get("roles") or {}, "org": {"id": facts.get("org"), "repo": facts.get("repo")}}
        rows = [_session_row(x) for x in sessions]
        mine = [r for r in rows if _this_org(r, mani)]
        if rows and not mine:
            # every row belongs to some org; none matching this one means the match failed, not that the org is idle
            spend, spend_state = [unjudged(f"none of the {len(rows)} session row(s) read names a source ending "
                                           f"`{facts.get('repo') or '<no repo in the facts>'}` or carries an "
                                           f"`org:{facts.get('org')}` tag — this dump cannot be attributed to this org", limit=0)], DARK
            spend_rows = {"read": False, "rows": len(rows)}
        elif mine and not any(r["cost_known"] for r in mine):
            spend, spend_state = [unjudged(f"none of the {len(mine)} session row(s) of this org carries a cost "
                                           "(`usage.cost_usd`) — a $0 here would be the shape, not the spend", limit=0)], DARK
            spend_rows = {"read": False, "rows": len(rows), "mine": len(mine)}
        else:
            by_role: dict[str, list[dict[str, Any]]] = {}
            for r in mine:
                by_role.setdefault(_role_of(r, mani), []).append(r)
            table = ", ".join(f"{role} {len(rs)}x ${sum(x['cost'] for x in rs):.0f}"
                              for role, rs in sorted(by_role.items(), key=lambda kv: -sum(x["cost"] for x in kv[1])))
            ceiling = (facts.get("budget") or {}).get("daily_usd")
            spend = [f"${sum(r['cost'] for r in mine):.0f} cumulative across {len(mine)} session(s) of this org"
                     + (f" — {table}" if table else ""),
                     "cumulative, not a window: one clock read cannot difference two gathers, so no percentage of a "
                     "daily ceiling is printed here — that is `org doctor` check 11"
                     + (f" (budget.daily_usd {ceiling!r})" if ceiling is not None else "; no budget.daily_usd is set"),
                     ] + ([f"{len(rows) - len(mine)} of the {len(rows)} row(s) read belong to another org or no repository"]
                          if len(rows) != len(mine) else [])
            for r in sorted(mine, key=lambda r: -r["cost"]):
                age = tp.hours(r["updated_at"], now.isoformat())
                if r["status"].endswith("ARCHIVED") or age is None:
                    continue
                if r["status"].endswith("REQUIRES_ACTION") and age >= BLOCKED_ALARM_HOURS:
                    spend.append(f"BLOCKED ON A PROMPT {r['title'][:60]}: waiting {age}h on "
                                 f"`{r['needs'] or 'a permission prompt'}` (${r['cost']:.0f} cumulative) — "
                                 "nobody unattended can answer it; a person stops it or answers it")
                if r["tokens"] > rot and age <= 24:     # untouched for a day is not paying for its context
                    spend.append(f"ROTATE {r['title'][:60]}: {r['tokens']} tokens > {rot} (${r['cost']:.0f} cumulative) "
                                 "— every wake now costs its whole context; rebind to a fresh session")
            spend_state = RED if any(l.startswith(("BLOCKED ON A PROMPT", "ROTATE")) for l in spend) else CLEAR
            spend_rows = {"read": True, "total": sum(r["cost"] for r in mine), "sessions": len(mine),
                          "by_role": {role: {"n": len(rs), "cost": sum(x["cost"] for x in rs)} for role, rs in by_role.items()},
                          "ceiling": ceiling, "others": len(rows) - len(mine),
                          "stopped": [{"title": r["title"], "hours": tp.hours(r["updated_at"], now.isoformat()),
                                       "needs": r["needs"], "cost": r["cost"]}
                                      for r in mine if r["status"].endswith("REQUIRES_ACTION")
                                      and (tp.hours(r["updated_at"], now.isoformat()) or 0) >= BLOCKED_ALARM_HOURS]}
    tiles.append(_tile("spend", "what the org is paying for right now", SESSIONS, spend_state, spend,
                       "BLOCKED ON A PROMPT <session>: waiting <h>h on `<prompt>` / ROTATE <session>: <n> tokens > <n>"))

    # --- which org-core wrote each record ----------------------------------
    # A role's record is the only place its container's version is visible: both restarted NumeroTech sessions sat on
    # 0.8.0 for a day while the tree said otherwise (rows 87, 88). The lock is git's; the records are the board's.
    lock = facts.get("lock") or {}
    want, lock_at = lock.get("org_core"), tp.parse_ts(lock.get("generated_at"))
    latest = tp._latest_records(facts.get("board") or [])
    if board_why:
        ver, ver_state = [unjudged(board_why)], DARK
    elif not want:
        ver, ver_state = [unjudged("the facts carry no `.org/lock.yaml` with an org_core version — this repo was "
                                   "never applied, or these facts were gathered before 0.26.0", limit=0)], DARK
    else:
        behind, ok = [], []
        for role, meta in sorted((facts.get("roles") or {}).items()):
            row = latest.get(meta.get("report_key") or f"roles/{role}/last-run")
            if row is None:
                continue                      # absence is the roles tile's finding, not this one's
            v = tp._value(row)
            rec_at = tp.parse_ts(v.get("at") or row.get("updated_at"))
            predates = bool(lock_at and rec_at and rec_at < lock_at)   # written before the apply: the next run says
            suite = v.get("suite")
            got = suite.get("org_core") if isinstance(suite, dict) else None
            if isinstance(suite, dict) and suite and suite.get("report") != "absent" and got == want:
                ok.append(role)
            elif predates:
                ok.append(role)
            elif not isinstance(suite, dict):
                behind.append({"role": role, "kind": "NO SUITE", "got": None, "cause": "no-field",
                               "line": f"NO SUITE {role}: its record carries no `suite` field — written by a skill "
                                       "rendered before 0.16.0, or the field was dropped"})
            elif not suite:
                behind.append({"role": role, "kind": "NO SUITE", "got": None, "cause": "capture-failed",
                               "line": f"NO SUITE {role}: its record carries `suite: {{}}` — the capture line failed "
                                       "in that container (row 112); the record says nothing about what it ran, and "
                                       "no restart changes that"})
            elif suite.get("report") == "absent":
                behind.append({"role": role, "kind": "NO SUITE", "got": None, "cause": "setup-never-ran",
                               "line": f"NO SUITE {role}: its record says the setup never ran in its container "
                                       "(`suite.report: absent`) — the hook is not wired there"})
            else:
                behind.append({"role": role, "kind": "BEHIND", "got": got, "cause": "behind",
                               "line": f"BEHIND {role}: record written by org-core {got or 'none'} while the lock is "
                                       f"{want} — its container's hook did not install the tree's wheel (rows 87, 88); "
                                       "a restart alone does not fix a branch whose hook is behind"})
        n = len(ok) + len(behind)
        ver = [b["line"] for b in behind] + ([f"{len(ok)} of {n} role record(s) say org-core {want}, the applied lock"
                         + (f" (lock written {lock.get('generated_at')})" if lock.get("generated_at") else "")]
                        if n else ["no role record on the board to read a version from"])
        ver_state = RED if behind else CLEAR
    tiles.append(_tile("versions", "which org-core each container is running", "mixed", ver_state, ver,
                       "BEHIND <role>: record written by org-core <v> while the lock is <v> / NO SUITE <role>"))

    # --- the same reading, as data rather than as sentences -----------------
    # `brief.py` writes the plain-language page from this and never from the lines above: a surface that parses
    # another surface's prose is two readings that drift, and this file has already paid for that twice.
    hand_rows, hand_unjudged = handoff_group_rows(hu)
    subjects = {
        "chair": {"read": not prs_why, "last_merge_at": c.get("last_merge_at"),
                  "hours_since_last_merge": c.get("hours_since_last_merge"), "merged": c.get("merged"),
                  "open_sound": ve.get("waiting", 0), "worst_sound_hours": ve.get("worst_waiting_hours"),
                  "needing_action": (c.get("needing_action") or []), "stale": (stale if not prs_why else []),
                  "target_hours": rep["targets"].get("pr_needing_action")},
        "names": {r: (m.get("name") or r) for r, m in (facts.get("roles") or {}).items()},
        # the four timestamps a pull request keeps, for the one stretch of the chain with real per-item
        # history. The board's stages are not here because the board does not keep them (row 62).
        "prs": [] if prs_why else [{k: p.get(k) for k in ("number", "kind", "author_role", "state", "draft",
                                                          "opened_at", "first_verdict_at", "merged_at", "closed_at")}
                                   for p in (facts.get("prs") or []) if p.get("opened_at") and not p.get("draft")],
        # which halves of the queue were read — the tile's state cannot answer this, because a real finding
        # outranks partial coverage by design, so a RED people tile may still be counting from one source
        "queue": queue, "queue_alarm_days": OPERATOR_QUEUE_ALARM_DAYS, "operator_file": ow, "queue_halves": half,
        "roles": [] if board_why else [r for r in overdue if r["state"] != "ok"],
        "roles_total": len(overdue),
        "blocked": [] if board_why else sorted(same.values(), key=lambda g: -len(g["roles"])),
        "unforwarded": [] if board_why else unf_rows,
        "handoffs": {"groups": hand_rows, "unjudged": len(hand_unjudged), "total": len(rep.get("handoffs") or [])},
        "actuator": {"read": (not board_why) or idle or orphaned, "heartbeat": hb, "age_hours": a.get("heartbeat_age_hours"),
                     "wakes": a.get("wakes"), "fired_no_receiver": [] if (runs_why or idle or orphaned) else fnr,
                     "suppressed": [] if (runs_why or idle or orphaned) else sup, "runs_unread": bool(runs_why),
                     # False only when the manifest asks nothing of one; None when these facts predate the question
                     "needed": (not idle) if duty else None, "role": (duty or {}).get("role"),
                     "missing": orphaned, "routed": list((duty or {}).get("routed") or [])},
        "listeners": {"read": not roster_dark, "lapsed": lapsed, "never": never, "total": len(ls)},
        "versions": {"read": bool(want) and not board_why, "lock": want, "lock_at": lock.get("generated_at"),
                     "ok": ok if (want and not board_why) else [], "behind": behind if (want and not board_why) else []},
        "spend": spend_rows,
    }

    # --- what this reading could not see -----------------------------------
    dark = [t["id"] for t in tiles if t["state"] == DARK]
    reds = [t for t in tiles if t["state"] == RED]
    cover = {"tiles": len(tiles), "measured": len(tiles) - len(dark), "dark": dark,
             "facts_gathered_at": facts.get("gathered_at"), "facts_age_hours": facts_age,
             "sessions_tier": (f"{len(sessions)} session row(s) read from the facts" if sessions else
                               "not read — triggers and sessions need a session holding the sessions port"),
             "could_not_read": unread}
    if unread and len(dark) == len(tiles):
        headline = "NOT MEASURED — could not read: " + "; ".join(unread)
    elif reds:
        first = next((l for kind in FINDING for t in reds for l in t["lines"] if l.startswith(kind)),
                     reds[0]["title"])
        headline = f"{first}  [{len(reds)} of {len(tiles)} tiles red, {len(dark)} dark]"
    else:
        headline = (f"no tile past target; {cover['measured']} of {cover['tiles']} tiles measured"
                    + (f", {len(dark)} dark ({', '.join(dark)})" if dark else "")
                    + (f"; facts {facts_age}h old" if facts_age is not None else ""))
    return {"kind": "org-status", "org": facts.get("org"), "at": now.isoformat(timespec="seconds"),
            "headline": headline, "tiles": tiles, "coverage": cover, "tiers": tier_notes,
            "subjects": subjects, "could_not_read": unread, "report": rep}


def exit_code(st: dict[str, Any]) -> int:
    """0 every tile measured and clear; 2 a tile is red; 3 nothing red but coverage is partial; 1 nothing readable.
    Each code is reachable: 3 is today's normal reading from a terminal, which cannot see the sessions tier."""
    states = [t["state"] for t in st["tiles"]]
    if all(s == DARK for s in states):
        return 1
    if RED in states:
        return 2
    return 3 if DARK in states else 0


def render(st: dict[str, Any]) -> str:
    c = st["coverage"]
    L = [f"status — {st['org']} at {st['at']}", f"  {st['headline']}", ""]
    for t in st["tiles"]:
        L.append(f"[{t['state']:<5}] {t['title']}  ({t['tier']}: {st['tiers'].get(t['tier'], 'several sources')})")
        for line in t["lines"]:
            L.append(f"        {line}")
        if t["state"] != RED:
            L.append(f"        broken looks like: {t['broken_looks_like']}")
        L.append("")
    L.append(f"read {c['measured']} of {c['tiles']} tiles"
             + (f"; dark: {', '.join(c['dark'])}" if c["dark"] else "")
             + (f"; facts {c['facts_gathered_at']} ({c['facts_age_hours']}h old)" if c["facts_gathered_at"] else "; gathered live"))
    L.append(f"sessions tier: {c['sessions_tier']}")
    if c["could_not_read"]:
        L.append("could not read: " + "; ".join(c["could_not_read"]))
    return "\n".join(L) + "\n"
