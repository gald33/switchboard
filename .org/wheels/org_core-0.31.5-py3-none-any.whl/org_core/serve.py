"""`org status --serve` — the reading, re-taken per request (SPEC §13).

A process that can reach the org serves the page. Nothing is pushed, stored or sent (rule 6), and the
measurement stays the single implementation in Python: the page renders what this reader computed and does
none of its own arithmetic, so there is nothing to drift.

Modelled on switchboard's own viewer (`gald33/switchboard`, `extras/viewer`, read 2026-09-20 against hub
2.4.1): a small read-only server, polled by the page it serves.

**The reader throttles, and says so.** A live gather is 1 + 3N `gh` calls, so re-reading on every request
would make a polling page cost a fan-out per poll. `interval` is the floor between reads; the page may poll
faster and simply sees the same reading. The age on screen is always the age of the READING, never the poll
rate — a dashboard whose refresh rate is mistaken for its freshness is the failure this file exists to avoid.

**A read that fails does not take the page down.** The last good reading stays on screen, stamped with what
went wrong and how long ago it was taken, because a blank page and a stale page are not the same finding.
"""

from __future__ import annotations

import datetime as dt
import json
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable

from . import dashboard as dash

#: how often the reader may re-read, in seconds. Below this a request is answered from the last reading.
DEFAULT_INTERVAL = 30.0
DEFAULT_PORT = 8799          # switchboard-viewer's port + 1, so both can run side by side
DEFAULT_HOST = "127.0.0.1"   # local by default: the reader holds the org's credentials, the page holds none


class Reader:
    """Takes a reading at most every `interval` seconds and renders it once per reading, not per request."""

    def __init__(self, take: Callable[[dt.datetime], dict[str, Any]], *, interval: float = DEFAULT_INTERVAL,
                 poll_ms: int = 5000, source: str = "org status --serve", clock: Callable[[], dt.datetime] | None = None):
        self._take, self._interval, self._poll_ms, self._source = take, interval, poll_ms, source
        self._clock = clock or (lambda: dt.datetime.now(dt.timezone.utc))
        self._lock = threading.Lock()
        self._doc: dict[str, Any] | None = None
        self._html: str = ""
        self._taken: dt.datetime | None = None
        self._error: str = ""
        self.reads = 0          # how many times the org was actually read, not how many requests were served

    def _stale(self, now: dt.datetime) -> bool:
        return self._taken is None or (now - self._taken).total_seconds() >= self._interval

    def current(self) -> tuple[dict[str, Any], str]:
        """The reading, re-taken only if the floor has passed. One read at a time; the rest wait for it."""
        with self._lock:
            now = self._clock()
            if self._stale(now):
                try:
                    st = self._take(now)
                    src = self._source + (f" · read {self.reads + 1}" if self.reads else "")
                    self._doc = dash.reading_doc(st, source=src)
                    self._html = dash.render_html(st, live=True, poll="/status.json", poll_ms=self._poll_ms,
                                                  source=src)
                    self._taken, self._error = now, ""
                    self.reads += 1
                except Exception as e:                      # a failed read keeps the last good one on screen
                    self._error = f"{type(e).__name__}: {e}"[:300]
                    if self._doc is None:
                        raise
            if self._error and self._doc is not None:
                doc = dict(self._doc)
                doc["could_not_read"] = list(doc.get("could_not_read") or []) + [
                    f"the reader's last attempt failed ({self._error}) — this reading was taken at {doc.get('at')}"]
                return doc, self._html
            return self._doc or {}, self._html


def handler_for(reader: Reader) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def _send(self, code: int, body: bytes, ctype: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:                            # noqa: N802 — the stdlib's spelling
            path = self.path.split("?", 1)[0]
            try:
                doc, html = reader.current()
            except Exception as e:
                self._send(503, f"the reader could not take a reading: {e}".encode(), "text/plain; charset=utf-8")
                return
            if path in ("/", "/index.html"):
                self._send(200, html.encode(), "text/html; charset=utf-8")
            elif path == "/status.json":
                self._send(200, json.dumps(doc, ensure_ascii=False).encode(), "application/json; charset=utf-8")
            else:
                self._send(404, b"not found\n", "text/plain; charset=utf-8")

        def log_message(self, fmt: str, *args: Any) -> None:
            pass                                             # the reading is the output; requests are not

    return Handler


def make_server(reader: Reader, *, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> ThreadingHTTPServer:
    """Bound but not yet serving, so a test can drive it and shut it down; `serve` is the thin wrapper."""
    httpd = ThreadingHTTPServer((host, port), handler_for(reader))
    httpd.daemon_threads = True
    return httpd


def url_of(httpd: ThreadingHTTPServer, host: str = DEFAULT_HOST) -> str:
    return f"http://{host}:{httpd.server_address[1]}/"


def serve(reader: Reader, *, host: str = DEFAULT_HOST, port: int = DEFAULT_PORT,
          ready: Callable[[str], None] | None = None) -> None:
    """Serve until interrupted. `ready` is called with the URL once the socket is bound."""
    httpd = make_server(reader, host=host, port=port)
    if ready:
        ready(url_of(httpd, host))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
