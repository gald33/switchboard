"""`org init`: what an existing repository already has (SPEC.md §6 detection matrix)."""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any

import yaml

from . import ROLE_IDS
from .render import parse_managed


def _git_remote(repo: Path) -> str | None:
    try:
        url = subprocess.run(["git", "-C", str(repo), "remote", "get-url", "origin"], capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        return None
    m = re.search(r"github\.com[:/]([^/]+/[^/.]+?)(?:\.git)?$", url)
    return m.group(1) if m else None


def detect(repo: Path) -> dict[str, Any]:
    d: dict[str, Any] = {"repo": _git_remote(repo)}
    d["claude_md"] = (repo / "CLAUDE.md").exists()
    agents: dict[str, str] = {}
    for p in sorted((repo / ".claude/agents").glob("*.md")) if (repo / ".claude/agents").is_dir() else []:
        try:
            managed = parse_managed(p.read_text())
        except ValueError:
            managed = None
        agents[p.stem] = "managed" if managed else "unmanaged"
    d["agents"] = agents
    skills = sorted(p.parent.name for p in (repo / ".claude/skills").glob("*/SKILL.md")) if (repo / ".claude/skills").is_dir() else []
    d["skills"] = skills
    d["roles_present"] = [r for r in ROLE_IDS if r in agents or r in skills]
    settings = repo / ".claude/settings.json"
    hooks = 0
    mcp_from_settings: list[str] = []
    if settings.exists():
        try:
            s = json.loads(settings.read_text())
            hooks = sum(len(h.get("hooks", [])) for h in s.get("hooks", {}).get("SessionStart", []))
            mcp_from_settings = list(s.get("enabledMcpjsonServers", []))
        except json.JSONDecodeError:
            hooks = -1
    d["session_start_hooks"] = hooks
    mcp = repo / ".mcp.json"
    d["mcp_servers"] = sorted(json.loads(mcp.read_text()).get("mcpServers", {}).keys()) if mcp.exists() else []
    d["enabled_mcp_servers"] = mcp_from_settings
    rm = repo / "roadmap"
    d["roadmap"] = {
        "present": rm.is_dir(),
        "items": len(list((rm / "items").glob("*.yaml"))) if (rm / "items").is_dir() else 0,
        "arcs": len(list((rm / "arcs").glob("*.yaml"))) if (rm / "arcs").is_dir() else 0,
        "cli_script": (repo / "scripts/roadmap.py").exists(),
    }
    d["checks"] = {
        "in_app_runner": (repo / "backend/app/services/post_merge_checks.py").exists(),
        "checks_dir": (repo / "checks").is_dir(),
    }
    d["tickets"] = {"ticket_flow": (repo / "scripts/ticket_flow.py").exists()}
    wf = repo / ".github/workflows"
    d["workflows"] = sorted(p.name for p in wf.glob("*.yml")) if wf.is_dir() else []
    d["operator_surface"] = (repo / "docs/human/state-of-the-org.md").exists()
    d["watchlist"] = (repo / "docs/ai/ceo-watchlist.md").exists()
    d["cloud_setup"] = sorted(str(p.relative_to(repo)) for p in list(repo.glob("scripts/cloud_*.sh")) + list(repo.glob(".claude/hooks/session-start.sh")))
    d["org_yaml"] = (repo / "org.yaml").exists()
    d["lock"] = (repo / ".org/lock.yaml").exists()
    return d


def draft_manifest(repo: Path, d: dict[str, Any], role_defaults: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """A manifest with every placeholder visible as <...>, never a silent guess."""
    repo_name = d.get("repo") or "<owner/repo>"
    org_id = re.sub(r"[^a-z0-9-]", "-", repo_name.split("/")[-1].lower()) if "/" in repo_name else "<org-id>"
    m: dict[str, Any] = {
        "schema_version": 1,
        "manifest_version": 1,
        "org": {
            "id": org_id,
            "repo": repo_name,
            "default_branch": "main",
            "checkout": str(repo),
            "operator": {"name": "<operator name>"},
            "account": "<the claude.ai account that owns the routines>",
            "paths": {"watchlist": "docs/ai/ceo-watchlist.md"},
        },
        "ports": {
            "work_store": {
                "tool": "roadmap-core",
                "mode": "files",
                "files": "roadmap/",
                "cli": "python scripts/roadmap.py" if d["roadmap"]["cli_script"] else "roadmap",
            },
            "coordination": {"tool": "switchboard", "url": "<hub url>", "workspace": repo_name.lower() if "/" in repo_name else "<owner/repo>"},
            "code_context": {"tool": "repoctx", "ranker": "lexical"},
            "checks": {"tool": "in-app", "runner": "backend/app/services/post_merge_checks.py"} if d["checks"]["in_app_runner"] else {"tool": "absent"},
            "tickets": {"tool": "in-app", "cli": "python scripts/ticket_flow.py", "user_visible_status": "handled"} if d["tickets"]["ticket_flow"] else {"tool": "github-issues", "label": "ticket"},
            "prod_read": {"method": "<how production is read, read-only>"},
            "vcs": {"tool": "github", "workflows_owned": [w for w in d["workflows"] if w in ("roadmap-validate.yml", "roadmap-sync.yml", "agent-docs-guards.yml")]},
            "sessions": {"tool": "claude-code-remote"},
            "operator_surface": "docs/human/state-of-the-org.md",
        },
        "operator_owns": {},
        "roles": {rid: {"name": role_defaults.get(rid, {}).get("name", rid)} for rid in ROLE_IDS},
        "budget": {"daily_usd": "<from the ledger>", "at_80_percent": "warn", "at_100_percent": "pause"},
        "knobs": {"dispatcher.cap": {"default": 3, "range": [0, 6]}},
        "fleet": {"report_to": "<org-core repo>/fleet/" + org_id, "sends": ["doctor_report", "run_ledger_delta", "knob_overrides", "install_log"]},
    }
    return m


def dump_manifest(m: dict[str, Any]) -> str:
    return yaml.safe_dump(m, sort_keys=False, allow_unicode=True)
